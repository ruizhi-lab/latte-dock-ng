from pathlib import Path
import subprocess, json, time
out=Path('/tmp/latte-modernization-t4a')
summary=[]
for preset in ('gcc-debug','clang-debug','gcc-release','clang-release'):
 for stage, cmd in [('configure',['cmake','--preset',preset]),('build',['cmake','--build','--preset',preset,'--parallel','8']),('ctest',['ctest','--preset',preset])]:
  start=time.monotonic()
  log=out/f'{preset}-{stage}.log'
  with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
  entry={'preset':preset,'stage':stage,'exit_code':r.returncode,'wall_seconds':round(time.monotonic()-start,3)}
  if stage=='build':
   lines=log.read_text().splitlines(); entry['compiler_warning_lines']=[s for s in lines if 'warning:' in s]
  summary.append(entry);print(json.dumps(entry),flush=True)
  (out/'validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
  if r.returncode or entry.get('compiler_warning_lines'):raise SystemExit(1)
 reg=subprocess.run(['ctest','--test-dir','build/modernization/'+preset,'--show-only=json-v1'],capture_output=True,text=True,check=True)
 (out/f'{preset}-registration-after.json').write_text(reg.stdout)
 before=json.loads((out/f'{preset}-registration-before.json').read_text());after=json.loads(reg.stdout)
 old={t['name'] for t in before['tests']};new={t['name'] for t in after['tests']}
 assert not old-new,(preset,old-new)
 print(json.dumps({'preset':preset,'registered':len(new),'added_tests':sorted(new-old),'removed_tests':sorted(old-new)}),flush=True)
print('All four configurations validated',flush=True)
