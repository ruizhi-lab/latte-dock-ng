from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();out=Path('/tmp/latte-modernization-wave2/mutations');out.mkdir(exist_ok=True)
header=root/'app/layout/containmentscreenresolver.h';adapter=root/'app/layout/genericlayout.cpp'
original={header:header.read_bytes(),adapter:adapter.read_bytes()};summary=[]
def run(label,cmd,expected=0):
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 summary.append({'label':label,'command':cmd,'exit_code':r.returncode,'expected':'zero' if expected==0 else 'nonzero'})
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 assert (r.returncode==0) if expected==0 else (r.returncode!=0),(label,r.returncode)
 if expected:assert 'FAIL!' in (out/(label+'.log')).read_text(),label
build=['cmake','--build','build/modernization/gcc-debug','--target','containmentscreenresolvertest','--parallel','8']
test=['ctest','--test-dir','build/modernization/gcc-debug','-R','^containmentscreenresolvertest$','--output-on-failure']
try:
 mutations=[('pending_precedence','if (pending) {','if (false && pending) {'),('primary_identity','primaryScreenId() : pending->screen','(primaryScreenId() - primaryScreenId()) : pending->screen'),('negative_and_zero','if (const auto screenId = viewScreenId()) {','if (const auto screenId = viewScreenId(); screenId && *screenId > 0) {')]
 for label,old,new in mutations:
  s=original[header].decode();assert s.count(old)==1,(label,old)
  header.write_text(s.replace(old,new));run(label+'-build',build);run(label+'-red',test,1);header.write_bytes(original[header])
 adapter_mutations=[('pending_adapter','PendingContainmentScreen{ update.onPrimary, update.screen }','PendingContainmentScreen{ false, update.screen }'),('primary_adapter','[this] { return m_corona->screenPool()->primaryScreenId(); }','[this] { return 0; }')]
 for label,old,new in adapter_mutations:
  s=original[adapter].decode();assert s.count(old)==1,(label,old)
  adapter.write_text(s.replace(old,new))
  run(label+'-red',['ctest','--test-dir','build/modernization/gcc-debug','-R','^sourcecontracttest$','--output-on-failure'],1)
  adapter.write_bytes(original[adapter])
finally:
 for p,b in original.items():p.write_bytes(b)
run('restored-build',build)
run('restored-green',['ctest','--test-dir','build/modernization/gcc-debug','-R','^(sourcecontracttest|containmentscreenresolvertest)$','--output-on-failure'])
print(json.dumps({'mutations':5,'all_rejected_by_tests':True,'restored_hashes':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in original}}),flush=True)
