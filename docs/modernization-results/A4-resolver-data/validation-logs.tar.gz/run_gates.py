from pathlib import Path
import subprocess,time,os,json
out=Path('/tmp/latte-modernization-wave2');results=[]
for label,prefix in [('22','/usr/lib/llvm/22/bin'),('18','/tmp/latte-llvm18/bin')]:
 env=dict(os.environ);env['PATH']=prefix+':'+env['PATH'];env['PYTHONDONTWRITEBYTECODE']='1'
 start=time.monotonic()
 with (out/f'tidy{label}-final.log').open('w') as f:
  r=subprocess.run(['python3','scripts/test-clang-tidy.py','--build-dir','build/modernization/clang-debug','--jobs','4'],env=env,stdout=f,stderr=subprocess.STDOUT)
 entry={'tool':label,'exit_code':r.returncode,'wall_seconds':round(time.monotonic()-start,3),'jobs':4,'note':'host LLVM22 / isolated LLVM18+GCC13 headers; not CI parity'}
 results.append(entry);(out/'tidy-timings.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(entry),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
