/*
    SPDX-FileCopyrightText: 2016 Smith AR <audoban@openmailbox.org>
    SPDX-FileCopyrightText: 2016 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import QtQuick.Layouts
import QtQuick.Effects

import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.extras as PlasmaExtras

import org.kde.latte.core as LatteCore

Item{
    id: wrapper
    required property var containmentRoot
    readonly property var root: containmentRoot
    required property var appletItem
    required property var applet
    required property var communicator
    required property var layoutsContainer
    required property var latteView
    required property var parabolic
    required property var metrics
    required property var isSeparator
    required property var isMarginsAreaSeparator
    required property var isInternalViewSplitter
    required property var isHorizontal
    required property var isVertical
    width: root.isHorizontal ? length : thickness
    height: root.isHorizontal ? thickness : length

    readonly property real length: {
        if (appletItem.isScheduledForDestruction) {
            return 0;
        }

        if (appletItem.isInternalViewSplitter) {
            return 0;
        }

        if ((isSeparator && appletItem.parabolic.isEnabled)
                || (isMarginsAreaSeparator && appletItem.parabolic.isEnabled)) {
            return -1;
        }

        if (appletItem.isAutoFillApplet) {
            if (appletItem.layouter.maxMetricsInHigherPriority) {
                return isInternalViewSplitter ? appletItem.maxAutoFillLength + 1 : appletItem.maxAutoFillLength;
            }

            // Guard against uninitialized auto-fill lengths (-1 default).
            // External C++ plasmoids (e.g. kweather_1x4) may request
            // fillWidth but never receive explicit min/max from the
            // layouter because they are not standard tasks or spacers.
            var effectiveMin = appletItem.minAutoFillLength > 0
                    ? appletItem.minAutoFillLength : appletItem.metrics.iconSize;
            var effectiveMax = appletItem.maxAutoFillLength > 0
                    ? appletItem.maxAutoFillLength : Math.max(appletPreferredLength, appletItem.metrics.iconSize);
            var result = Math.max(effectiveMin, Math.min(appletPreferredLength, effectiveMax));
            return isInternalViewSplitter? result + 1 : result;
        }

        return scaledLength;
    }

    readonly property real thickness: {
        if (appletItem.isInternalViewSplitter) {
            return 0;
        }

        return communicator.parabolicEffectIsSupported ? appletPreferredThickness : scaledThickness + appletItem.metrics.margin.screenEdge;
    }

    opacity: appletColorizer.mustBeShown && appletItem.environment.isGraphicsSystemAccelerated ? 0 : 1

    // Apply native hover feedback only to compact applets that expose an icon.
    // Text-only and custom-painted applets therefore keep their own visuals.
    readonly property bool supportsHoveredIconEffect: communicator.appletMainIconIsFound
                                                      || appletItem.pluginName === "org.kde.plasma.trash"

    // Compact applets can bind their icon directly to configuration even when
    // Latte discovers an IconItem (for example Kicker). The backend applet icon
    // is authoritative after the original-color override; discovery alone does
    // not prove the native representation follows it. Do not gate this path on
    // getter-backed icon properties: they have no notify signal and can retain
    // the initial symbolic name after the menu option changes.
    readonly property bool needsOriginalIconFallback: appletItem.userKeepsOriginalIconColors
                                                       && appletItem.backendAppletRef

    property bool disableLengthScale: false
    property bool disableThicknessScale: false

    property real appletWidth: applet ?  applet.width : -1
    property real appletHeight: applet ?  applet.height : -1

    property real appletMinimumWidth: applet && applet.Layout ?  applet.Layout.minimumWidth : -1
    property real appletMinimumHeight: applet && applet.Layout ? applet.Layout.minimumHeight : -1

    property real appletPreferredWidth: applet && applet.Layout ?  applet.Layout.preferredWidth : -1
    property int appletPreferredHeight: applet && applet.Layout ?  applet.Layout.preferredHeight : -1

    property real appletMaximumWidth: applet && applet.Layout ?  applet.Layout.maximumWidth : -1
    property real appletMaximumHeight: applet && applet.Layout ?  applet.Layout.maximumHeight : -1

    readonly property int proposedItemThickness: appletItem.inMarginsArea && !appletItem.canFillThickness ?
                                                     Math.max(16,appletItem.metrics.marginsArea.iconSize) :
                                                     appletItem.metrics.iconSize

    readonly property real appletLength: root.isHorizontal ? appletWidth : appletHeight
    readonly property real appletThickness: root.isHorizontal ? appletHeight : appletWidth

    readonly property int appletMinimumLength : {
        if (isInternalViewSplitter) {
            return root.maxJustifySplitterSize;
        }

        return root.isHorizontal ? appletMinimumWidth : appletMinimumHeight
    }

    readonly property real appletPreferredLength: {
        if (isInternalViewSplitter) {
            return appletMinimumLength;
        }
        return root.isHorizontal ? appletPreferredWidth : appletPreferredHeight;
    }

    readonly property real appletMaximumLength: {
        if (isInternalViewSplitter) {
            return Infinity;
        }

        root.isHorizontal ? appletMaximumWidth : appletMaximumHeight;
    }

    readonly property real appletMinimumThickness: root.isHorizontal ? appletMinimumHeight : appletMinimumWidth
    readonly property real appletPreferredThickness: root.isHorizontal ? appletPreferredHeight : appletPreferredWidth
    readonly property real appletMaximumThickness: root.isHorizontal ? appletMaximumHeight : appletMaximumWidth

    property int iconSize: appletItem.metrics.iconSize

    property int marginsThickness: {
        if (appletItem.inMarginsArea) {
            return appletItem.metrics.marginsArea.thicknessEdges;
        }

        return appletItem.metrics.totals.thicknessEdges;
    }

    property int marginsLength: 0   //Fitt's Law, through Binding to avoid Binding loops

    property int localLengthMargins: isSeparator
                                     || appletItem.isMarginsAreaSeparator
                                     || !communicator.requires.lengthMarginsEnabled
                                     || communicator.indexerIsSupported
                                     || isInternalViewSplitter
                                     ? 0 : appletItem.lengthAppletFullMargins

    property real scaledLength: zoomScaleLength * (layoutLength + marginsLength)
    property real scaledThickness: zoomScaleThickness * layoutThickness + (zoomMarginScale*marginsThickness)

    property real zoomScaleLength: disableLengthScale ? 1 : zoomScale
    property real zoomScaleThickness: disableThicknessScale ? 1 : zoomScale

    property real layoutLength: 0
    property real layoutThickness: 0

    property real zoomScale: 1
    readonly property real zoomMarginScale: 1 + (zoomScale - 1) * parabolic.factor.marginThicknessZoomInPercentage

    readonly property alias headThicknessMargin: _wrapperContainer.headThicknessMargin
    readonly property alias tailThicknessMargin: _wrapperContainer.tailThicknessMargin
    readonly property alias appletScreenMargin: _wrapperContainer.appliedEdgeMargin

    property int index: appletItem.index

    property Item wrapperContainer: _wrapperContainer
    property Item overlayIconLoader: _overlayIconLoader

    readonly property int internalSplitterComputedLength: {
        if (!appletItem.isInternalViewSplitter) {
            return 0;
        }

        var parentLayoutLength = 0;
        var parentTwinLayoutLength = 0;

        if (appletItem.parent === layoutsContainer.startLayout) {
            parentLayoutLength = appletItem.layouter.startLayout.lengthWithoutSplitters;
            parentTwinLayoutLength = appletItem.layouter.endLayout.lengthWithoutSplitters;
        } else if (appletItem.parent === layoutsContainer.endLayout) {
            parentLayoutLength = appletItem.layouter.endLayout.lengthWithoutSplitters;
            parentTwinLayoutLength = appletItem.layouter.startLayout.lengthWithoutSplitters;
        } else {
            return 0;
        }

        var parentLayoutCenter = (appletItem.layouter.maxLength - layoutsContainer.mainLayout.length)/2;
        var twinLayoutExceededCenter = Math.max(0, (parentTwinLayoutLength + root.maxJustifySplitterSize) - parentLayoutCenter);
        var availableLength = Math.max(0, parentLayoutCenter - twinLayoutExceededCenter) + 1; //add one pixel in order to not leave a gap inConfigureAppletsMode

        return Math.max(root.maxJustifySplitterSize, availableLength - parentLayoutLength);
    }

    Behavior on opacity {
        NumberAnimation {
            duration: 0.8 * appletItem.animations.duration.proposed
            easing.type: Easing.OutCubic
        }
    }

    // property int pHeight: applet ? applet.Layout.preferredHeight : -10

    /*function debugLayouts(){
        if(applet && applet.pluginName==="org.kde.plasma.systemtray"){
            console.log("---------- "+ applet.pluginName +" ----------");
            console.log("MinW "+applet.Layout.minimumWidth);
            console.log("PW "+applet.Layout.preferredWidth);
            console.log("MaxW "+applet.Layout.maximumWidth);
            console.log("FillW "+applet.Layout.fillWidth);
            console.log("-----");
            console.log("MinH "+applet.Layout.minimumHeight);
            console.log("PH "+applet.Layout.preferredHeight);
            console.log("MaxH "+applet.Layout.maximumHeight);
            console.log("FillH "+applet.Layout.fillHeight);
            console.log("-----");
            console.log("Real Applet Width: "+applet.width);
            console.log("Real Applet Height: "+applet.height);
            console.log("-----");
            console.log("Real Wrapper Width: "+wrapper.width);
            console.log("Real Wrapper Height: "+wrapper.height);
            console.log("-----");
            console.log("Can be hovered: " + parabolicEffectIsSupported);
            console.log("Icon size: " + appletItem.metrics.iconSize);
            console.log("Thick Margins: " + appletItem.metrics.totals.thicknessEdges);
            console.log("Intern. Margins: " + (appletItem.metrics.padding.length * 2));
            console.log("Intern. Margins: " + (appletItem.metrics.margin.length * 2));
            console.log("Max hovered criteria: " + (appletItem.metrics.iconSize + metrics.totals.thicknessEdges));
            console.log("-----");
            console.log("LayoutLength: " + layoutLength);
            console.log("LayoutThickness: " + layoutThickness);
        }
    }*/

    onAppletLengthChanged: {
        if(zoomScale === 1) {
            appletItem.updateParabolicEffectIsSupported();
        }
    }

    onAppletThicknessChanged: {
        if(zoomScale === 1) {
            appletItem.updateParabolicEffectIsSupported();
        }
    }

    onAppletMinimumLengthChanged: {
        if(zoomScale === 1) {
            appletItem.updateParabolicEffectIsSupported();
        }

        updateAutoFillLength();
    }

    onAppletMinimumThicknessChanged: {
        if(zoomScale === 1) {
            appletItem.updateParabolicEffectIsSupported();
        }
    }

    onAppletPreferredLengthChanged: {
        updateAutoFillLength();
    }

    onAppletMaximumLengthChanged: {
        updateAutoFillLength();
    }

    onZoomScaleChanged: {
        if ((zoomScale === appletItem.parabolic.factor.zoom) && !appletItem.parabolic.directRenderingEnabled) {
            appletItem.parabolic.setDirectRenderingEnabled(true);
        }

        if ((zoomScale > 1) && !appletItem.isZoomed) {
            appletItem.isZoomed = true;
            appletItem.animations.needBothAxis.addEvent(appletItem);
        } else if (zoomScale == 1) {
            appletItem.isZoomed = false;
            appletItem.animations.needBothAxis.removeEvent(appletItem);
        }
    }

    Binding {
        target: wrapper
        property: "layoutThickness"
        when: latteView
              && (wrapper.zoomScale === 1
                  || communicator.parabolicEffectIsSupported
                  || appletItem.externalAppletUsesFixedSlotSizing)
        value: {
            if (appletItem.isInternalViewSplitter){
                return 0;
            }

            if (appletItem.externalAppletUsesFixedSlotSizing) {
                return proposedItemThickness;
            }

            // avoid binding loops on startup
            if (communicator.parabolicEffectIsSupported && !communicator.inStartup) {
                return Math.min(appletPreferredThickness, appletItem.metrics.totals.thickness);
            }

            return proposedItemThickness;
        }
    }

    Binding {
        target: wrapper
        property: "layoutLength"
        when: latteView
              && !appletItem.isAutoFillApplet
              && (wrapper.zoomScale === 1 || appletItem.externalAppletUsesFixedSlotSizing)
        value: {
            //! Separators are a thin divider, not an icon-sized applet: keep
            //! the content container at the separator's preferred length so
            //! the 1px line stays tight at the boundary slot instead of
            //! overflowing a full icon-sized slot into the neighbours.
            if (isSeparator) {
                if (appletPreferredLength > 0) {
                    return appletPreferredLength;
                }

                return LatteCore.Environment.separatorLength;
            }

            if (appletItem.externalAppletUsesFixedSlotSizing) {
                // Text-based external applets (e.g. digital clock) whose
                // natural width was captured get that exact width instead
                // of a grid-cell multiple, so the slot hugs the content.
                if (appletItem.externalAppletNaturalWidth > appletItem.metrics.iconSize) {
                    return appletItem.externalAppletNaturalWidth;
                }
                return appletItem.metrics.iconSize;
            }

            if (applet && ( appletMaximumLength < appletItem.metrics.iconSize
                           || appletPreferredLength > appletItem.metrics.iconSize
                           || appletItem.originalAppletBehavior)) {

                //this way improves performance, probably because during animation the preferred sizes update a lot
                if (appletMaximumLength>=0 && appletMaximumLength < appletItem.metrics.iconSize){
                    return appletMaximumLength;
                } else if (appletMinimumLength > appletItem.metrics.iconSize){
                    return appletMinimumLength;
                } else if ((appletPreferredLength > appletItem.metrics.iconSize)
                           || (appletItem.originalAppletBehavior && appletPreferredLength > 0)){
                    return appletPreferredLength;
                }
            }

            return appletItem.metrics.iconSize;
        }
    }

    Binding {
        target: wrapper
        property: "disableThicknessScale"
        when: latteView
        value: appletItem.externalAppletUsesFixedSlotSizing
    }

    Binding {
        target: wrapper
        property: "disableLengthScale"
        when: latteView && !(appletItem.isAutoFillApplet || appletItem.indexerIsSupported)
        value: {
            var blockParabolicEffectInLength = false;

            if (appletItem.externalAppletUsesFixedSlotSizing) {
                return false;
            }

            if (communicator.parabolicEffectIsSupported) {
                return true;
            }

            if (appletItem.isInternalViewSplitter){
                return false;
            } else {
                if(applet && (appletMinimumLength > appletItem.metrics.iconSize) && !appletItem.parabolicEffectIsSupported){
                    return (wrapper.zoomScale === 1);
                } //it is used for plasmoids that need to scale only one axis... e.g. the Weather Plasmoid
                else if(applet
                        && ( appletMaximumLength < appletItem.metrics.iconSize
                            || appletPreferredLength > appletItem.metrics.iconSize
                            || appletItem.originalAppletBehavior)) {

                    //this way improves performance, probably because during animation the preferred sizes update a lot
                    if (appletMaximumLength>0 && appletMaximumLength < appletItem.metrics.iconSize){
                        return false;
                    } else if (appletMinimumLength > appletItem.metrics.iconSize){
                        return (wrapper.zoomScale === 1);
                    } else if ((appletPreferredLength > appletItem.metrics.iconSize)
                               || (appletItem.originalAppletBehavior && appletPreferredLength > 0 )){
                        return (wrapper.zoomScale === 1);
                    }
                }
            }

            return false;
        }
    }

    Binding {
        target: wrapper
        property: "marginsLength"
        when: latteView && (!root.inStartup || visibilityManager.inRelocationHiding)
        value: localLengthMargins
    }

    function updateAutoFillLength() {
        if (appletItem.isAutoFillApplet) {
            appletItem.layouter.updateSizeForAppletsInFill();
        }
    }

    //! Applet Highlight when requested
    Loader {
        id: visualIndicator
        anchors.fill: parent
        active: showVisualIndicatorRequested

        property bool showVisualIndicatorRequested: false

        Connections {
            target: root.latteView ? root.latteView.extendedInterface : null
            function onAppletRequestedVisualIndicator() {
                if (plasmoidId === appletItem.applet.id) {
                    visualIndicator.showVisualIndicatorRequested = true;
                }
            }
        }

        sourceComponent: PlasmaExtras.Highlight {
            id: visualIndicatorRectangle
            opacity: 0

            Component.onCompleted: showVisualIndicatorAnimation.running = true;

            SequentialAnimation{
                id: showVisualIndicatorAnimation
                alwaysRunToEnd: true

                PropertyAnimation {
                    target: visualIndicatorRectangle
                    property: "opacity"
                    to: 1
                    duration: 3*appletItem.animations.duration.large
                    easing.type: Easing.OutQuad
                }

                PauseAnimation {
                    duration: 1500
                }

                PropertyAnimation {
                    target: visualIndicatorRectangle
                    property: "opacity"
                    to: 0
                    duration: 3*appletItem.animations.duration.large
                    easing.type: Easing.OutQuad
                }

                ScriptAction {
                    script: {
                        visualIndicator.showVisualIndicatorRequested = false;
                    }
                }
            }
        }
    }

    ///Shadow in applets
    Loader{
        id: appletShadow
        anchors.fill: _wrapperContainer

        active: appletItem.applet
                && appletItem.environment.isGraphicsSystemAccelerated
                && !appletColorizer.mustBeShown
                && (appletItem.myView.itemShadow.isEnabled && !appletItem.communicator.indexerIsSupported)

        //! Qt6 MultiEffect always composites a full-color copy of its source
        //! together with the shadow. Its internal ShaderEffectSource captures
        //! the applet at its logical (unscaled) size, so while fixed-slot
        //! applets (Kickoff, Application Menu, Trash, …) zoom via a scale
        //! transform the effect keeps rendering the original-size colored
        //! copy + shadow behind the scaled applet. That duplicate is only
        //! hidden by opaque icons; transparent icons (e.g. the Colloid theme)
        //! show it through as ghosting (issue #38). Fading the shadow out
        //! while those zoom keeps the transition fluid instead of popping,
        //! and the duplicate only lingers for the short fade.
        //! Layout-grown applets (with a discoverable icon) re-render their
        //! content at the zoomed size, so their texture always matches and
        //! the shadow stays active even during the zoom.
        sourceComponent: MultiEffect{
            anchors.fill: parent
            shadowEnabled: true
            shadowColor: appletItem.myView.itemShadow.shadowColor
            source: _wrapperContainer
            shadowBlur: 0.5
            shadowVerticalOffset: root.forceTransparentPanel || root.forcePanelForBusyBackground ? 0 : 2
            opacity: (wrapper.zoomScale === 1 || !appletItem.externalAppletUsesFixedSlotSizing) ? 1 : 0

            Behavior on opacity {
                NumberAnimation {
                    duration: 2 * appletItem.animationTime
                    easing.type: Easing.OutCubic
                }
            }
        }
    }

    // The shell CompactApplet is not used by every Plasma widget.  Rendering
    // from this wrapper guarantees the same hover brightness for both shell
    // and native compact representations, including Trash.
    MultiEffect {
        id: hoveredAppletEffect
        anchors.fill: _wrapperContainer
        source: _wrapperContainer
        z: 1000
        // Fixed-slot widgets (such as Trash) scale their native compact
        // representation during the parabolic wave. Mirror that transform so
        // the hover copy remains exactly aligned with the icon.
        scale: _wrapperContainer.scale
        transformOrigin: _wrapperContainer.transformOrigin
        visible: wrapper.supportsHoveredIconEffect
                 && appletItem.indicators
                 && !appletItem.indicators.info.providesHoveredAnimation
        // Reuse Latte's existing parabolic hover state.  Adding an input item
        // above applets would steal the wave from neighbouring task icons.
        opacity: visible && appletItem.containsMouse ? 1 : 0
        brightness: 0.30
        contrast: 0.1

        Behavior on opacity {
            NumberAnimation { duration: appletItem.animations.duration.large }
        }
    }

    // Use the resolved theme file only for the explicit opt-in. Symbolic-only
    // or unresolved icons keep their native representation. Keep polling while
    // opted in, including when hidden, so a later usable icon can activate it.
    Item {
        id: originalIconFallback
        anchors.fill: _wrapperContainer
        z: 1100
        scale: _wrapperContainer.scale
        transformOrigin: _wrapperContainer.transformOrigin
        visible: wrapper.needsOriginalIconFallback && iconPath !== ""
        property string iconPath: ""

        function refreshIconPath() {
            const iconName = wrapper.needsOriginalIconFallback ? appletItem.currentBackendAppletIcon() : "";
            const nextPath = iconName && !iconName.endsWith("-symbolic")
                           ? appletItem.currentBackendAppletIconPath() : "";

            if (iconPath !== nextPath) {
                iconPath = nextPath;
            }
        }

        Component.onCompleted: refreshIconPath()
        Connections {
            target: wrapper
            function onNeedsOriginalIconFallbackChanged() { originalIconFallback.refreshIconPath(); }
        }

        // Some applets expose their state through iconChanged without a QML
        // property notification on the resolved backend object. Poll only
        // while this fallback is opted in so dynamic widgets such as
        // volume and brightness keep their current state.
        Timer {
            interval: 100
            repeat: true
            running: wrapper.needsOriginalIconFallback
            onTriggered: originalIconFallback.refreshIconPath()
        }

        Binding {
            target: appletItem.applet
            property: "opacity"
            when: originalIconFallback.visible && appletItem.applet
            value: 0
        }

        Image {
            anchors.centerIn: parent
            width: appletItem.metrics.iconSize
            height: appletItem.metrics.iconSize
            source: originalIconFallback.iconPath
            sourceSize.width: width
            sourceSize.height: height
            fillMode: Image.PreserveAspectFit
            asynchronous: true
        }
    }

    // The fallback image is above the native hover copy, so apply the same
    // brightness effect to it when the generic original-color path is active.
    MultiEffect {
        id: hoveredOriginalIconEffect
        anchors.fill: originalIconFallback
        z: 1200
        source: originalIconFallback
        scale: originalIconFallback.scale
        transformOrigin: originalIconFallback.transformOrigin
        visible: originalIconFallback.visible
                 && appletItem.indicators
                 && !appletItem.indicators.info.providesHoveredAnimation
        opacity: visible && appletItem.containsMouse ? 1 : 0
        brightness: 0.30
        contrast: 0.1

        Behavior on opacity {
            NumberAnimation { duration: appletItem.animations.duration.large }
        }
    }

    //! Applet Main Container
    Item{
        id:_wrapperContainer
        width: root.isHorizontal ? _length : _thickness
        height: root.isHorizontal ? _thickness : _length
        scale: appletItem.externalAppletUsesFixedSlotSizing ? wrapper.zoomScale : 1
        transformOrigin: {
            if (!appletItem.externalAppletUsesFixedSlotSizing) {
                return Item.Center;
            }

            if (plasmoid.location === PlasmaCore.Types.BottomEdge) {
                return Item.Bottom;
            } else if (plasmoid.location === PlasmaCore.Types.TopEdge) {
                return Item.Top;
            } else if (plasmoid.location === PlasmaCore.Types.LeftEdge) {
                return Item.Left;
            } else if (plasmoid.location === PlasmaCore.Types.RightEdge) {
                return Item.Right;
            }

            return Item.Center;
        }

        property int _length:0 // through Binding to avoid binding loops
        property int _thickness:0 // through Binding to avoid binding loops

        readonly property int appliedEdgeMargin: appletItem.canFillScreenEdge ? 0 : appletItem.metrics.margin.screenEdge
        readonly property int tailThicknessMargin: {
            if (appletItem.canFillScreenEdge) {
                return 0;
            } else if (appletItem.canFillThickness) {
                return appliedEdgeMargin;
            } else if (appletItem.inMarginsArea) {
                return appliedEdgeMargin + (wrapper.zoomMarginScale * appletItem.metrics.marginsArea.tailThickness);
            }

            return appliedEdgeMargin + (wrapper.zoomMarginScale * appletItem.metrics.margin.tailThickness);
        }

        readonly property int headThicknessMargin: {
            if (appletItem.canFillThickness || appletItem.canFillScreenEdge) {
                return 0;
            } else if (appletItem.inMarginsArea) {
                return (wrapper.zoomMarginScale * appletItem.metrics.marginsArea.headThickness);
            }

            return wrapper.zoomMarginScale * appletItem.metrics.margin.headThickness;
        }

        readonly property real zoomScaleThickness: wrapper.zoomScaleThickness

        Binding {
            target: _wrapperContainer
            property: "_thickness"
            when: !visibilityManager.inRelocationHiding
            value: {
                if (appletItem.isInternalViewSplitter) {
                    return wrapper.layoutThickness;
                }

                var canfillthickness = (appletItem.canFillScreenEdge || appletItem.canFillThickness);
                var wrapperContainerThickness =  canfillthickness ? appletItem.metrics.totals.thickness : wrapper.zoomScaleThickness * wrapper.proposedItemThickness;
                return appletItem.canFillScreenEdge ? wrapperContainerThickness + appletItem.metrics.margin.screenEdge : wrapperContainerThickness;
            }
        }

        Binding {
            target: _wrapperContainer
            property: "_length"
            when: !visibilityManager.inRelocationHiding
            value: {
                if (appletItem.isAutoFillApplet) {
                    return wrapper.length;
                }

                if (appletItem.externalAppletUsesFixedSlotSizing) {
                    return wrapper.layoutLength;
                }

                return wrapper.zoomScaleLength * wrapper.layoutLength;
            }
        }

        Loader{
            anchors.fill: parent
            active: appletItem.debug.graphicsEnabled && !isInternalViewSplitter
            sourceComponent: Rectangle{
                width: 30
                height: 30
                color: "transparent"
                border.width: 1
                border.color: "yellow"
            }
        }

        Loader{
            id: _overlayIconLoader
            anchors.fill: parent
            active: communicator.appletMainIconIsFound && indicators.info.needsIconColors

            property color backgroundColor: "transparent"
            property color glowColor: "transparent"

            //! Plasma Applets RoundToIconSize should be ALWAYS false when Latte has discovered
            //! the iconitem for these applets. This way we can be sure that applets and latte
            //! tasks will follow the same icon size if it is possible; in any other case
            //! the plasma applets might look to small
            readonly property bool isRoundToIconSizeEnabled: !communicator.appletIconItem

            onIsRoundToIconSizeEnabledChanged: {
                if (!communicator.appletIconItem) {
                    return;
                }

                communicator.appletIconItem.roundToIconSize = isRoundToIconSizeEnabled;
            }

            sourceComponent: LatteCore.IconItem{
                id: overlayIconItem
                anchors.fill: parent
                visible: false

                source: {
                    if (communicator.appletIconItem) {
                        return communicator.appletIconItem.source;
                    } else if (communicator.appletImageItem) {
                        return communicator.appletImageItem.source;
                    }

                    return "";
                }

                providesColors: source != ""
                usesPlasmaTheme: communicator.appletIconItem && communicator.appletIconItem.visible ? communicator.appletIconItem.usesPlasmaTheme : false

                Binding{
                    target: _overlayIconLoader
                    property: "backgroundColor"
                    when: overlayIconItem.providesColors
                    value: overlayIconItem.backgroundColor
                }

                Binding{
                    target: _overlayIconLoader
                    property: "glowColor"
                    when: overlayIconItem.providesColors
                    value: overlayIconItem.glowColor
                }

                Loader{
                    anchors.centerIn: parent
                    active: appletItem.debug.overloadedIconsEnabled && !isInternalViewSplitter
                    sourceComponent: Rectangle{
                        width: 30
                        height: 30
                        color: "green"
                        opacity: 0.65
                    }
                }
            }
        }

        //! WrapperContainer States
        states:[
            State{
                name: "bottom"
                when: plasmoid.location === PlasmaCore.Types.BottomEdge

                AnchorChanges{
                    target: _wrapperContainer;
                    anchors.horizontalCenter: parent.horizontalCenter; anchors.verticalCenter: undefined;
                    anchors.right: undefined; anchors.left: undefined; anchors.top: undefined; anchors.bottom: parent.bottom;
                }
                PropertyChanges{
                    _wrapperContainer.anchors.leftMargin: 0;    _wrapperContainer.anchors.rightMargin: 0;     _wrapperContainer.anchors.topMargin:0;    _wrapperContainer.anchors.bottomMargin: _wrapperContainer.tailThicknessMargin
                    _wrapperContainer.anchors.horizontalCenterOffset: 0; _wrapperContainer.anchors.verticalCenterOffset: 0;
                }
            },
            State{
                name: "top"
                when: plasmoid.location === PlasmaCore.Types.TopEdge

                AnchorChanges{
                    target:_wrapperContainer;
                    anchors.horizontalCenter: parent.horizontalCenter; anchors.verticalCenter: undefined;
                    anchors.right: undefined; anchors.left: undefined; anchors.top: parent.top; anchors.bottom: undefined;
                }
                PropertyChanges{
                    _wrapperContainer.anchors.leftMargin: 0;    _wrapperContainer.anchors.rightMargin: 0;     _wrapperContainer.anchors.topMargin: _wrapperContainer.tailThicknessMargin;    _wrapperContainer.anchors.bottomMargin: 0;
                    _wrapperContainer.anchors.horizontalCenterOffset: 0; _wrapperContainer.anchors.verticalCenterOffset: 0;
                }
            },
            State{
                name: "left"
                when: plasmoid.location === PlasmaCore.Types.LeftEdge

                AnchorChanges{
                    target: _wrapperContainer;
                    anchors.horizontalCenter: undefined; anchors.verticalCenter: parent.verticalCenter;
                    anchors.right: undefined; anchors.left: parent.left; anchors.top: undefined; anchors.bottom: undefined;
                }
                PropertyChanges{
                    _wrapperContainer.anchors.leftMargin: _wrapperContainer.tailThicknessMargin;    _wrapperContainer.anchors.rightMargin: 0;     _wrapperContainer.anchors.topMargin:0;    _wrapperContainer.anchors.bottomMargin: 0;
                    _wrapperContainer.anchors.horizontalCenterOffset: 0; _wrapperContainer.anchors.verticalCenterOffset: 0;
                }
            },
            State{
                name: "right"
                when: plasmoid.location === PlasmaCore.Types.RightEdge

                AnchorChanges{
                    target: _wrapperContainer;
                    anchors.horizontalCenter: undefined; anchors.verticalCenter: parent.verticalCenter;
                    anchors.right: parent.right; anchors.left: undefined; anchors.top: undefined; anchors.bottom: undefined;
                }
                PropertyChanges{
                    _wrapperContainer.anchors.leftMargin: 0;    _wrapperContainer.anchors.rightMargin: _wrapperContainer.tailThicknessMargin;     _wrapperContainer.anchors.topMargin:0;    _wrapperContainer.anchors.bottomMargin: 0;
                    _wrapperContainer.anchors.horizontalCenterOffset: 0; _wrapperContainer.anchors.verticalCenterOffset: 0;
                }
            }
        ]
    }

    //! EventsSink
    Loader {
        id: eventsSinkLoader
        anchors.fill: _wrapperContainer
        active: !communicator.parabolicEffectIsSupported && !isSeparator && !isSpacer && !isHidden && !isInternalViewSplitter
        //! The following can be added in case EventsSink creates slaginess with parabolic effect
        //!(appletItem.lockZoom || !appletItem.parabolic.isEnabled || !appletItem.parabolicEffectIsSupported)

        sourceComponent: EventsSink {
            destination: _wrapperContainer
        }
    }

    Loader{
        anchors.fill: parent
        active: appletItem.debug.graphicsEnabled

        sourceComponent: Rectangle{
            anchors.fill: parent
            color: "transparent"
            //! red visualizer, in debug mode for the applets that use fillWidth or fillHeight
            //! green, for the rest
            border.color:  (appletItem.isAutoFillApplet && (appletItem.maxAutoFillLength>-1) && root.isHorizontal) ? "red" : "green"
            border.width: 1
        }
    }

    Behavior on zoomScale {
        NumberAnimation {
            duration: (!appletItem.parabolic.directRenderingEnabled || restoreAnimation.running)
                      ? 3 * appletItem.animationTime : 0
            easing.type: Easing.OutCubic
        }
    }
}// Main task area // id:wrapper
