/*
    SPDX-FileCopyrightText: 2016 Smith AR <audoban@openmailbox.org>
    SPDX-FileCopyrightText: 2016 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/


import QtQuick

import org.kde.draganddrop

import org.kde.taskmanager as TaskManager

import "../../code/tools.js" as TaskTools

Item {
    // signal urlDropped(url url)
    id: dArea
    signal urlsDropped(var urls)

    property Item target
    property Item ignoredItem
    property Item dragParabolicItem
    property bool moved: false
    property bool containsDrag: false
    property Item pendingPinnedSource: null
    property int pendingPinnedTargetIndex: -1
    property string pendingPinnedLauncherUrl: ""
    property int pendingPinnedAttempts: 0
    // Hysteresis: prevent the insertion indicator from jittering between
    // adjacent positions during drag.  Reorder only commits when the pointer
    // has moved at least this many pixels (Manhattan) from the last commit.
    property int lastReorderIndex: -1
    property real lastReorderX: 0
    property real lastReorderY: 0
    readonly property int minReorderDistance: 12

    property alias hoveredItem: dropHandler.hoveredItem

    readonly property alias isMovingTask: dropHandler.inMovingTask
    readonly property alias isDroppingFiles: dropHandler.inDroppingFiles
    readonly property alias isDroppingOnlyLaunchers: dropHandler.inDroppingOnlyLaunchers
    readonly property alias isDroppingSeparator: dropHandler.inDroppingSeparator

    function isLauncherTask(task) {
        return task && task.m && task.m.IsLauncher === true;
    }

    function launcherUrlForTask(task) {
        if (!task) {
            return "";
        }

        if (task.launcherUrl && task.launcherUrl.length > 0) {
            return task.launcherUrl;
        }

        if (task.launcherUrlWithIcon && task.launcherUrlWithIcon.length > 0) {
            return task.launcherUrlWithIcon;
        }

        return "";
    }

    function schedulePromoteToLauncherAndMove(sourceItem, targetIndex, launcherUrl) {
        pendingPinnedSource = sourceItem;
        pendingPinnedTargetIndex = Math.max(0, targetIndex);
        pendingPinnedLauncherUrl = launcherUrl;
        pendingPinnedAttempts = 0;
        promotePinnedTaskTimer.restart();
    }

    function clearPendingPromoteMove() {
        pendingPinnedSource = null;
        pendingPinnedTargetIndex = -1;
        pendingPinnedLauncherUrl = "";
        pendingPinnedAttempts = 0;
    }

    Timer {
        id: ignoreItemTimer

        repeat: false
        // Matches plasma-desktop's taskmanager: 750ms is enough to prevent the
        // launcher-vs-task oscillation case without globally throttling the
        // wave / reorder rate the rest of the time.
        interval: 750

        onTriggered: {
            ignoredItem = null;
        }
    }

    Timer {
        id: promotePinnedTaskTimer

        interval: 40
        repeat: true

        onTriggered: {
            if (!pendingPinnedSource || pendingPinnedTargetIndex < 0) {
                clearPendingPromoteMove();
                stop();
                return;
            }

            var sourceItem = pendingPinnedSource;
            var launcherReady = isLauncherTask(sourceItem)
                    || tasksModel.launcherPosition(pendingPinnedLauncherUrl) >= 0;

            if (launcherReady) {
                var from = sourceItem.itemIndex;
                var to = Math.max(0, Math.min(pendingPinnedTargetIndex, tasksModel.count - 1));

                if (from >= 0 && to >= 0 && from !== to) {
                    tasksModel.move(from, to);
                }

                clearPendingPromoteMove();
                stop();
                return;
            }

            pendingPinnedAttempts = pendingPinnedAttempts + 1;
            if (pendingPinnedAttempts > 25) {
                clearPendingPromoteMove();
                stop();
            }
        }
    }

    Connections {
        target: root
        function onDragSourceChanged() {
            if (!dragSource) {
                if (dragParabolicItem && dragParabolicItem.clearParabolicFromExternalPosition) {
                    dragParabolicItem.clearParabolicFromExternalPosition();
                }
                dragParabolicItem = null;
                ignoredItem = null;
                ignoreItemTimer.stop();
                clearPendingPromoteMove();
                promotePinnedTaskTimer.stop();
            }
        }
    }

    function updateDragParabolic(hoverItem, rootX, rootY) {
        // Atomic transition between items: let updateParabolicFromExternalPosition
        // call setCurrentParabolicItem(B) which replaces the previous current item
        // in place. Clearing the previous item first would briefly set
        // currentParabolicItem to null and arm restoreZoomTimer / disable
        // directRendering, producing a visible hiccup in the wave when drag
        // events are sparse (typical on Wayland).
        if (hoverItem && hoverItem.updateParabolicFromExternalPosition
                && hoverItem.updateParabolicFromExternalPosition(dArea, rootX, rootY)) {
            dragParabolicItem = hoverItem;
            return;
        }

        // Truly leaving any item — restore zoom on the previous target.
        if (dragParabolicItem && dragParabolicItem.clearParabolicFromExternalPosition) {
            dragParabolicItem.clearParabolicFromExternalPosition();
        }
        dragParabolicItem = null;
    }

    // Find the visible child nearest to (x,y) inside `container`, excluding
    // `excludeItem`. Used as a fallback when childAtPos returns null because
    // the pointer is in a gap between two delegates.
    // Recursively collect all TaskItem descendants from a container item.
    function collectTaskDescendants(item, excludeItem, result) {
        if (!item || !item.children) {
            return;
        }
        for (var i = 0; i < item.children.length; ++i) {
            var child = item.children[i];
            if (!child || child === excludeItem || child.visible === false) {
                continue;
            }
            if (child.objectName === "TaskItem") {
                result.push(child);
            }
            // Recurse into non-TaskItem children (they may contain TaskItems)
            if (child.objectName !== "TaskItem" && child.children && child.children.length > 0) {
                collectTaskDescendants(child, excludeItem, result);
            }
        }
    }

    // Find the visible TaskItem child (or descendant) nearest to (x,y),
    // excluding `excludeItem`.
    function nearestChildInContainer(container, x, y, excludeItem) {
        var bestItem = null;
        var bestDistSq = Number.POSITIVE_INFINITY;

        // Collect all TaskItem descendants (not just direct children)
        var candidates = [];
        collectTaskDescendants(container, excludeItem, candidates);

        for (var i = 0; i < candidates.length; ++i) {
            var child = candidates[i];
            var cx = child.x + child.width / 2;
            var cy = child.y + child.height / 2;
            var dx = x - cx;
            var dy = y - cy;
            var distSq = dx * dx + dy * dy;

            if (distSq < bestDistSq) {
                bestDistSq = distSq;
                bestItem = child;
            }
        }

        return bestItem;
    }

    // Public entry point used by task delegates while dragging. Keep this on
    // the MouseHandler root item so callers can reliably access it.
    function reorderFromDragPosition(sourceItem, rootX, rootY) {
        if (!sourceItem || !target || tasksModel.sortMode !== TaskManager.TasksModel.SortManual) {
            return;
        }

        if (target.animating) {
            return;
        }

        // Suppress jitter: only commit a new insertion position when the
        // pointer has moved at least minReorderDistance from the last commit.
        if (lastReorderIndex >= 0) {
            var dx = rootX - lastReorderX;
            var dy = rootY - lastReorderY;
            if (Math.abs(dx) + Math.abs(dy) < minReorderDistance) {
                return;
            }
        }

        var eventToTarget = mapToItem(target, rootX, rootY);
        var above = target.childAtPos(eventToTarget.x, eventToTarget.y, sourceItem);

        // When the pointer lands in a gap between two delegates childAtPos
        // returns null. Find the nearest visible child instead so the
        // placeholder indicator tracks the correct insertion slot.
        if (!above) {
            above = nearestChildInContainer(target, eventToTarget.x, eventToTarget.y, sourceItem);
        }

        updateDragParabolic(above, rootX, rootY);
        var insertAt = TaskTools.insertIndexAt(above, eventToTarget.x, eventToTarget.y);

        // insertIndexAt defaults to "before" (above.itemIndex). Determine
        // whether to insert before or after based on mouse position relative
        // to the found item's center. This is needed both for gap fallback
        // and for the common case where childAtPos hits an item near its edge.
        if (above && insertAt >= 0 && insertAt < tasksModel.count) {
            var mainPos = root.vertical ? eventToTarget.y : eventToTarget.x;
            var aboveCenter = root.vertical ? (above.y + above.height / 2) : (above.x + above.width / 2);
            if (mainPos > aboveCenter) {
                insertAt = Math.min(tasksModel.count - 1, insertAt + 1);
            }
        }

        if (insertAt < 0 || insertAt >= tasksModel.count) {
            return;
        }

        if (sourceItem === above || sourceItem.itemIndex === insertAt) {
            return;
        }

        var sourceIsLauncher = isLauncherTask(sourceItem);
        var targetTask = above ? above : (target.childAtIndex ? target.childAtIndex(insertAt) : null);
        var targetIsLauncher = isLauncherTask(targetTask);

        // Auto-pin: dragging a non-pinned task into the launcher area
        // promotes it to a launcher first, then moves it.
        if (!sourceIsLauncher && targetTask && targetIsLauncher) {
            var launcherUrl = launcherUrlForTask(sourceItem);
            if (launcherUrl.length > 0) {
                if (tasksModel.launcherPosition(launcherUrl) === -1) {
                    appletAbilities.launchers.addLauncher(launcherUrl);
                }
                schedulePromoteToLauncherAndMove(sourceItem, insertAt, launcherUrl);
                ignoredItem = targetTask;
                ignoreItemTimer.restart();
                return;
            }
        }

        sourceItem.z = 100;
        ignoredItem = above;

        var from = sourceItem.itemIndex;
        tasksModel.move(from, insertAt);

        // Record the commit position so subsequent drag-move events
        // must move at least minReorderDistance before the next reorder.
        lastReorderIndex = insertAt;
        lastReorderX = rootX;
        lastReorderY = rootY;

        ignoreItemTimer.restart();
    }

    DropArea {
        id: dropHandler
        anchors.fill: parent
        preventStealing: true

        property bool inDroppingOnlyLaunchers: false
        property bool inDroppingSeparator: false
        property bool inMovingTask: false
        property bool inDroppingFiles: false

        readonly property bool eventIsAccepted: inMovingTask || inDroppingSeparator || inDroppingOnlyLaunchers || inDroppingFiles

        property int droppedPosition: -1;
        property Item hoveredItem

        function isDroppingSeparator(event) {
            var appletName = String(event.mimeData.getDataAsByteArray("text/x-plasmoidservicename"));
            var isSeparator = (appletName === "audoban.applet.separator" || appletName === "org.kde.latte.separator");

            return ((event.mimeData.formats.indexOf("text/x-plasmoidservicename") === 0) && isSeparator);
        }

        function isDroppingOnlyLaunchers(event) {
            if (event.mimeData.hasUrls || (event.mimeData.formats.indexOf("text/x-plasmoidservicename") !== 0)) {
                var onlyLaunchers = event.mimeData.urls.every(function (item) {
                    return backend.isApplication(item)
                });

                return onlyLaunchers;
            }

            return false;
        }

        function isMovingTask(event) {
            if (root.dragSource) {
                return true;
            }

            if (!event || !event.mimeData) {
                return false;
            }

            var source = event.mimeData.source;

            while (source) {
                if (source.objectName === "TaskItem") {
                    return true;
                }

                source = source.parent;
            }

            if (event.mimeData.formats === undefined) {
                return false;
            }

            for (var i = 0; i < event.mimeData.formats.length; ++i) {
                var format = String(event.mimeData.formats[i]);

                if (format === "application/x-orgkdeplasmataskmanager_taskbuttonitem"
                        || format.indexOf("plasmataskmanager") >= 0) {
                    return true;
                }
            }

            return false;
        }

        function clearDroppingFlags() {
            inDroppingFiles = false;
            inDroppingOnlyLaunchers = false;
            inDroppingSeparator = false;
            inMovingTask = false;
        }

        onHoveredItemChanged: {
            if (hoveredItem && windowsPreviewDlg.activeItem && hoveredItem !== windowsPreviewDlg.activeItem ) {
                windowsPreviewDlg.hide(6.7);
            }
        }

        onDragEnter: (event) => {
            dArea.lastReorderIndex = -1;
            inMovingTask = isMovingTask(event);
            inDroppingOnlyLaunchers = !inMovingTask && isDroppingOnlyLaunchers(event);
            inDroppingSeparator = !inMovingTask && isDroppingSeparator(event);
            inDroppingFiles = !inDroppingOnlyLaunchers && event.mimeData.hasUrls;

            /*console.warn(" tasks moving task :: " + inMovingTask);
            console.warn(" tasks only launchers :: " + inDroppingOnlyLaunchers);
            console.warn(" tasks separator :: " + inDroppingSeparator);
            console.warn(" tasks only files :: " + inDroppingFiles);
            console.warn(" tasks event accepted :: " + eventIsAccepted);*/

            if (!eventIsAccepted) {
                clearDroppingFlags();
                event.ignore();
                return;
            }

            dArea.containsDrag = true;
        }

        onDragMove: (event) => {
            if (!eventIsAccepted) {
                clearDroppingFlags();
                event.ignore();
                return;
            }

            dArea.containsDrag = true;

            if (target.animating) {
                return;
            }

            var eventToTarget = mapToItem(target, event.x, event.y);

            var above = target.childAtPos(eventToTarget.x, eventToTarget.y, root.dragSource);

            // Always drive the parabolic wave from the latest pointer position,
            // independently of the reorder cooldown below. This is the
            // mitigation for sparse Wayland drag-motion events: every event we
            // do receive needs to update the wave, even when the same item is
            // the current reorder target (cooldown active).
            if (root.dragSource) {
                dArea.updateDragParabolic(above, event.x, event.y);
            }

            // Per-item cooldown (matches plasma-desktop's MouseHandler.qml):
            // only the *specific* item we just moved past is blocked for the
            // cooldown window, so cursor sweeps across multiple delegates
            // continue to reorder smoothly. The previous global gate
            // (ignoredItem == null) caused 200 ms-1 reorder updates regardless
            // of where the pointer went next.
            if (root.dragSource == null && above === ignoredItem) {
                return;
            }

            if (root.dragSource != null
                    && root.dragSource.m.IsLauncher === true && above != null
                    && above.m != null
                    && above.m.IsLauncher !== true && above === ignoredItem) {
                return;
            }

            if (tasksModel.sortMode == TaskManager.TasksModel.SortManual
                    && root.dragSource
                    && (above === null || above !== ignoredItem)) {
                // When above is null the pointer is in a gap between delegates;
                // always allow reorder so the nearest-child fallback can run.
                dArea.reorderFromDragPosition(root.dragSource, event.x, event.y);
            }
             else if (!root.dragSource && above && hoveredItem != above) {
                hoveredItem = above;
                activationTimer.restart();
            } else if (!above) {
                hoveredItem = null;
                activationTimer.stop();
            }

            if (hoveredItem && windowsPreviewDlg.visible && toolTipDelegate
                    && toolTipDelegate.rootIndex !== hoveredItem.modelIndex() ) {
                windowsPreviewDlg.hide(6);
            }
        }

        onDragLeave: {
            dArea.lastReorderIndex = -1;
            dArea.containsDrag = false;
            if (dragParabolicItem && dragParabolicItem.clearParabolicFromExternalPosition) {
                dragParabolicItem.clearParabolicFromExternalPosition();
            }
            dragParabolicItem = null;
            hoveredItem = null;
            clearDroppingFlags();

            activationTimer.stop();
        }

        onDrop: (event) => {
            if (!eventIsAccepted) {
                clearDroppingFlags();
                event.ignore();
                return;
            }

            // Reject internal drops.
            dArea.lastReorderIndex = -1;
            dArea.containsDrag = false;
            if (dragParabolicItem && dragParabolicItem.clearParabolicFromExternalPosition) {
                dragParabolicItem.clearParabolicFromExternalPosition();
            }
            dragParabolicItem = null;

            if (inDroppingSeparator) {
                if (hoveredItem && hoveredItem.itemIndex >=0){
                    appletAbilities.launchers.addInternalSeparatorAtPos(hoveredItem.itemIndex);
                } else {
                    appletAbilities.launchers.addInternalSeparatorAtPos(0);
                }
            } else if (inDroppingOnlyLaunchers || inDroppingFiles) {
                parent.urlsDropped(event.mimeData.urls);
            }

            clearDroppingFlags();
        }

        Timer {
            id: activationTimer

            interval: 250
            repeat: false

            onTriggered: {
                if (dropHandler.inDroppingOnlyLaunchers || dropHandler.inDroppingSeparator) {
                    return;
                }

                if (parent.hoveredItem.m.IsGroupParent === true) {
                    root.showPreviewForTasks(parent.hoveredItem);
                    // groupDialog.visualParent = parent.hoveredItem;
                    // groupDialog.visible = true;
                } else if (parent.hoveredItem.m.IsLauncher !== true) {
                    if(windowsPreviewDlg.visible && toolTipDelegate
                            && toolTipDelegate.currentItem !==parent.hoveredItem.itemIndex ) {
                        windowsPreviewDlg.hide(5);
                        toolTipDelegate.currentItem=-1;
                    }

                    tasksModel.requestActivate(parent.hoveredItem.modelIndex());
                }
            }
        }
    }
    MouseArea {
        id: wheelHandler

        anchors.fill: parent
        property int wheelDelta: 0;
        readonly property bool canScroll: {
            var c = plasmoid.containment;
            if (!c || !c.configuration) return false;
            var sa = c.configuration.scrollAction;
            return sa === 3 || sa === 4;
        }

        // Explicit task cycling also applies when the list overflows. The
        // activated delegate reveals itself through ScrollableList.focusOn().
        enabled: canScroll

        onWheel: (wheel) => {
            wheelDelta = TaskTools.wheelActivateNextPrevTask(wheelDelta, wheel.angleDelta.y);
        }
    }
}
