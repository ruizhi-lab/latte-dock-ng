/*
    SPDX-FileCopyrightText: 2019 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import org.kde.plasma.core as PlasmaCore

import org.kde.latte.core as LatteCore
import org.kde.latte.components as LatteComponents

LatteComponents.IndicatorItem{
    id: root
    extraMaskThickness: reversedEnabled && glowEnabled ? 1.7 * (factor * indicator.maxIconSize) : 0

    enabledForApplets: indicator && indicator.configuration ? indicator.configuration.enabledForApplets : true
    lengthPadding: indicator && indicator.configuration ? indicator.configuration.lengthPadding : 0.08

    readonly property real factor: 0.08
    readonly property int modernDockDotSize: Math.max(3, Math.round(indicator.currentIconSize * 0.055))
    readonly property int size: modernDockStyle ? modernDockDotSize : factor * indicator.currentIconSize

    readonly property int screenEdgeMargin: modernDockStyle ? indicator.screenEdgeMargin
                                                            : (plasmoid.location === PlasmaCore.Types.Floating || reversedEnabled ? 0 : indicator.screenEdgeMargin)

    property color textColorSafe: theme && theme.textColor !== undefined ? theme.textColor : "#ffffff"
    property color backgroundColorSafe: theme && theme.backgroundColor !== undefined ? theme.backgroundColor : "#202020"
    property real backgroundColorBrightness: colorBrightness(backgroundColorSafe)

    property color isActiveColor: oppositeToBackgroundColor(textColorSafe)
    property color minimizedColor: {
        if (minimizedTaskColoredDifferently) {
            return tonedDownOppositeColor(isActiveColor);
        }

        return isActiveColor;
    }

    property color notActiveColor: indicator.isMinimized ? minimizedColor : isActiveColor
    property color stateDotColor: indicator.isActive || (indicator.isGroup && indicator.hasShown) ? isActiveColor : notActiveColor

    //! Common Options
    readonly property bool reversedEnabled: indicator.configuration.reversed

    //! Configuration Options
    readonly property bool extraDotOnActive: indicator.configuration.extraDotOnActive
    readonly property bool minimizedTaskColoredDifferently: indicator.configuration.minimizedTaskColoredDifferently
    readonly property int activeStyle: indicator.configuration.activeStyle
    readonly property bool modernDockStyle: indicator && indicator.isModernDockStyle === true
    readonly property int effectiveActiveStyle: modernDockStyle ? 1 /*Dot*/ : activeStyle
    readonly property real modernDockIconEdgeGap: modernDockStyle
                                                 ? Math.max(0, indicator.tailThickness !== undefined ? indicator.tailThickness : 0)
                                                 : 0
    readonly property real modernDockIndicatorMargin: modernDockStyle
                                                       ? screenEdgeMargin + Math.max(0, Math.round((modernDockIconEdgeGap - size) / 2))
                                                       : screenEdgeMargin
    readonly property real effectiveScreenEdgeMargin: modernDockStyle ? modernDockIndicatorMargin : screenEdgeMargin
    //!glow options
    readonly property bool glowEnabled: indicator.configuration.glowEnabled
    readonly property bool glow3D: indicator.configuration.glow3D
    readonly property int glowApplyTo: indicator.configuration.glowApplyTo
    readonly property real glowOpacity: indicator.configuration.glowOpacity

    /*Rectangle{
        anchors.fill: parent
        border.width: 1
        border.color: "yellow"
        color: "transparent"
        opacity:0.6
    }*/

    function colorBrightness(color) {
        return colorBrightnessFromRGB(color.r * 255, color.g * 255, color.b * 255);
    }

    function hasOppositeBrightness(foregroundColor, baseBackgroundColor) {
        var foregroundBrightness = colorBrightness(foregroundColor);
        var baseBrightness = colorBrightness(baseBackgroundColor);

        return (baseBrightness > 127.5 && foregroundBrightness < 127.5)
                || (baseBrightness <= 127.5 && foregroundBrightness >= 127.5);
    }

    function oppositeToBackgroundColor(candidateColor) {
        if (hasOppositeBrightness(candidateColor, backgroundColorSafe)) {
            return candidateColor;
        }

        return backgroundColorBrightness > 127.5 ? Qt.darker(candidateColor, 1.8) : Qt.lighter(candidateColor, 1.8);
    }

    function tonedDownOppositeColor(baseColor) {
        var tonedColor = backgroundColorBrightness > 127.5 ? Qt.lighter(baseColor, 1.28) : Qt.darker(baseColor, 1.28);
        return oppositeToBackgroundColor(tonedColor);
    }

    // formula for brightness according to:
    // https://www.w3.org/TR/AERT/#color-contrast
    function colorBrightnessFromRGB(r, g, b) {
        return (r * 299 + g * 587 + b * 114) / 1000
    }

    Item{
        id: mainIndicatorElement

        width: flowItem.width
        height: flowItem.height

        Flow{
            id: flowItem
            flow: plasmoid.formFactor === PlasmaCore.Types.Vertical ? Flow.TopToBottom : Flow.LeftToRight

            LatteComponents.GlowPoint{
                id:firstPoint
                opacity: {
                    if (indicator.isEmptySpace) {
                        return 0;
                    }

                    if (indicator.isTask) {
                        return indicator.isLauncher || (indicator.inRemoving && !activeAndReverseAnimation.running) ? 0 : 1
                    }

                    if (indicator.isApplet) {
                        return (indicator.isActive || activeAndReverseAnimation.running) ? 1 : 0
                    }
                }

                basicColor: root.stateDotColor

                size: root.size
                glow3D: glow3D
                animation: Math.max(1.65*3*LatteCore.Environment.longDuration,indicator.durationTime*3*LatteCore.Environment.longDuration)
                location: plasmoid.location
                glowOpacity: root.modernDockStyle ? 1 : root.glowOpacity
                contrastColor: indicator.shadowColor
                attentionColor: theme.negativeTextColor

                roundCorners: true
                showAttention: indicator.inAttention
                showGlow: {
                    if (root.modernDockStyle) {
                        return false;
                    }

                    if (glowEnabled && (glowApplyTo === 2 /*All*/ || showAttention ))
                        return true;
                    else if (glowEnabled && glowApplyTo === 1 /*OnActive*/ && indicator.hasActive)
                        return true;
                    else
                        return false;
                }
                showBorder: !root.modernDockStyle && glowEnabled && glow3D

                property int stateWidth: indicator.isGroup ? root.width - secondPoint.width : root.width - spacer.width
                property int stateHeight: indicator.isGroup ? root.height - secondPoint.height : root.height - spacer.height

                property int animationTime: indicator.durationTime* (0.7*LatteCore.Environment.longDuration)

                property bool isActive: indicator.hasActive || indicator.isActive

                property bool vertical: plasmoid.formFactor === PlasmaCore.Types.Vertical

                property real scaleFactor: indicator.scaleFactor

                function updateInitialSizes(){
                    if(root){
                        if(vertical)
                            width = root.size;
                        else
                            height = root.size;

                        if(vertical && isActive && root.effectiveActiveStyle === 0 /*Line*/)
                            height = stateHeight;
                        else
                            height = root.size;

                        if(!vertical && isActive && root.effectiveActiveStyle === 0 /*Line*/)
                            width = stateWidth;
                        else
                            width = root.size;
                    }
                }


                onIsActiveChanged: {
                    if (root.effectiveActiveStyle === 0 /*Line*/)
                        activeAndReverseAnimation.start();
                }

                onScaleFactorChanged: {
                    if(!activeAndReverseAnimation.running && !vertical && isActive && root.effectiveActiveStyle === 0 /*Line*/){
                        width = stateWidth;
                    }
                    else if (!activeAndReverseAnimation.running && vertical && isActive && root.effectiveActiveStyle === 0 /*Line*/){
                        height = stateHeight;
                    }
                }

                onStateWidthChanged:{
                    if(!activeAndReverseAnimation.running && !vertical && isActive && root.effectiveActiveStyle === 0 /*Line*/)
                        width = stateWidth;
                }

                onStateHeightChanged:{
                    if(!activeAndReverseAnimation.running && vertical && isActive && root.effectiveActiveStyle === 0 /*Line*/)
                        height = stateHeight;
                }

                onVerticalChanged: updateInitialSizes();

                Component.onCompleted: {
                    updateInitialSizes();

                    if (indicator) {
                        indicator.onCurrentIconSizeChanged.connect(updateInitialSizes);
                    }
                }

                Component.onDestruction: {
                    if (indicator) {
                        indicator.onCurrentIconSizeChanged.disconnect(updateInitialSizes);
                    }
                }

                NumberAnimation{
                    id: activeAndReverseAnimation
                    target: firstPoint
                    property: plasmoid.formFactor === PlasmaCore.Types.Vertical ? "height" : "width"
                    to: indicator.hasActive && root.effectiveActiveStyle === 0 /*Line*/
                        ? (plasmoid.formFactor === PlasmaCore.Types.Vertical ? firstPoint.stateHeight : firstPoint.stateWidth) : root.size
                    duration: firstPoint.animationTime
                    easing.type: Easing.InQuad

                    onStopped: firstPoint.updateInitialSizes()
                }
            }

            Item{
                id:spacer
                width: secondPoint.visible ? 0.5*root.size : 0
                height: secondPoint.visible ? 0.5*root.size : 0
            }

            LatteComponents.GlowPoint{
                id:secondPoint
                width: visible ? root.size : 0
                height: width

                size: root.size
                glow3D: glow3D
                animation: Math.max(1.65*3*LatteCore.Environment.longDuration,indicator.durationTime*3*LatteCore.Environment.longDuration)
                location: plasmoid.location
                glowOpacity: root.glowOpacity
                contrastColor: indicator.shadowColor
                showBorder: glowEnabled && glow3D

                basicColor: state2Color
                roundCorners: true
                showGlow: glowEnabled  && glowApplyTo === 2 /*All*/
                visible: !root.modernDockStyle
                         && ( indicator.isGroup && ((extraDotOnActive && root.effectiveActiveStyle === 0) /*Line*/
                                                  || root.effectiveActiveStyle === 1 /*Dot*/
                                                  || !indicator.hasActive) ) ? true: false

                //when there is no active window
                property color state1Color: indicator.hasShown ? root.isActiveColor : root.minimizedColor
                //when there is active window
                property color state2Color: indicator.hasMinimized ? root.minimizedColor : root.isActiveColor
            }
        }

        states: [
            State {
                name: "left"
                when: ((plasmoid.location === PlasmaCore.Types.LeftEdge && !reversedEnabled) ||
                       (plasmoid.location === PlasmaCore.Types.RightEdge && reversedEnabled))

                AnchorChanges {
                    target: mainIndicatorElement
                    anchors{ verticalCenter:parent.verticalCenter; horizontalCenter:undefined;
                        top:undefined; bottom:undefined; left:parent.left; right:undefined;}
                }
                PropertyChanges{
                    mainIndicatorElement.anchors.leftMargin: root.effectiveScreenEdgeMargin;    mainIndicatorElement.anchors.rightMargin: 0;     mainIndicatorElement.anchors.topMargin:0;    mainIndicatorElement.anchors.bottomMargin:0;
                    mainIndicatorElement.anchors.horizontalCenterOffset: 0; mainIndicatorElement.anchors.verticalCenterOffset: 0;
                }
            },
            State {
                name: "bottom"
                when: (plasmoid.location === PlasmaCore.Types.Floating ||
                       (plasmoid.location === PlasmaCore.Types.BottomEdge && !reversedEnabled) ||
                       (plasmoid.location === PlasmaCore.Types.TopEdge && reversedEnabled))

                AnchorChanges {
                    target: mainIndicatorElement
                    anchors{ verticalCenter:undefined; horizontalCenter:parent.horizontalCenter;
                        top:undefined; bottom:parent.bottom; left:undefined; right:undefined;}
                }
                PropertyChanges{
                    mainIndicatorElement.anchors.leftMargin: 0;    mainIndicatorElement.anchors.rightMargin: 0;     mainIndicatorElement.anchors.topMargin:0;    mainIndicatorElement.anchors.bottomMargin: root.effectiveScreenEdgeMargin;
                    mainIndicatorElement.anchors.horizontalCenterOffset: 0; mainIndicatorElement.anchors.verticalCenterOffset: 0;
                }
            },
            State {
                name: "top"
                when: ((plasmoid.location === PlasmaCore.Types.TopEdge && !reversedEnabled) ||
                       (plasmoid.location === PlasmaCore.Types.BottomEdge && reversedEnabled))

                AnchorChanges {
                    target: mainIndicatorElement
                    anchors{ verticalCenter:undefined; horizontalCenter:parent.horizontalCenter;
                        top:parent.top; bottom:undefined; left:undefined; right:undefined;}
                }
                PropertyChanges{
                    mainIndicatorElement.anchors.leftMargin: 0;    mainIndicatorElement.anchors.rightMargin: 0;     mainIndicatorElement.anchors.topMargin: root.effectiveScreenEdgeMargin;    mainIndicatorElement.anchors.bottomMargin:0;
                    mainIndicatorElement.anchors.horizontalCenterOffset: 0; mainIndicatorElement.anchors.verticalCenterOffset: 0;
                }
            },
            State {
                name: "right"
                when: ((plasmoid.location === PlasmaCore.Types.RightEdge && !reversedEnabled) ||
                       (plasmoid.location === PlasmaCore.Types.LeftEdge && reversedEnabled))

                AnchorChanges {
                    target: mainIndicatorElement
                    anchors{ verticalCenter:parent.verticalCenter; horizontalCenter:undefined;
                        top:undefined; bottom:undefined; left:undefined; right:parent.right;}
                }
                PropertyChanges{
                    mainIndicatorElement.anchors.leftMargin: 0;    mainIndicatorElement.anchors.rightMargin: root.effectiveScreenEdgeMargin;     mainIndicatorElement.anchors.topMargin:0;    mainIndicatorElement.anchors.bottomMargin:0;
                    mainIndicatorElement.anchors.horizontalCenterOffset: 0; mainIndicatorElement.anchors.verticalCenterOffset: 0;
                }
            }
        ]
    }
}// number of windows indicator
