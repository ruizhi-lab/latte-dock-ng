/*
    SPDX-FileCopyrightText: 2021 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import org.kde.latte.abilities.client as AbilityClient

import "abilities" as Ability

AbilityClient.AppletAbilities {
    id: _abilityContainer
    property QtObject tasksModel: null

    readonly property alias launchers: _launchers

    Ability.Launchers {
        id: _launchers
        bridge: _abilityContainer.bridge
        layout: _abilityContainer.layout
        tasksModel: _abilityContainer.tasksModel
        view: _abilityContainer.myView
    }

    //! local properties
    readonly property int maxIconSizeInPlasma: Math.max(plasmoid.configuration.iconSize, 16)
    readonly property int panelThickness: (root.vertical ? root.width : root.height)

    //! Connections
    Connections {
        target: _abilityContainer.shortcuts
        function onDisabledIsStealingGlobalPositionShortcuts() {
            plasmoid.configuration.isPreferredForPositionShortcuts = false;
        }
    }

    Connections {
        target: _abilityContainer.launchers
        function onDisabledIsStealingDroppedLaunchers() {
            plasmoid.configuration.isPreferredForDroppedLaunchers = false;
        }
    }
}
