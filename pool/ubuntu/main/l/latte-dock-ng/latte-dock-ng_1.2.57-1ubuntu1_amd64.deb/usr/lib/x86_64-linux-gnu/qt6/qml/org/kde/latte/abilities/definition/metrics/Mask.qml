/*
    SPDX-FileCopyrightText: 2020 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import "./mask" as MaskTypes

Item {
    property int screenEdge: 0
    property int maxScreenEdge: 0

    property MaskTypes.Thickness thickness: MaskTypes.Thickness{}
}
