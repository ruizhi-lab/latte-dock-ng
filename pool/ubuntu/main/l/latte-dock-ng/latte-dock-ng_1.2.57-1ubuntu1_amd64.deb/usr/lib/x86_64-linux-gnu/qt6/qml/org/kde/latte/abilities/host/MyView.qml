/*
    SPDX-FileCopyrightText: 2021 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import org.kde.latte.abilities.definition as AbilityDefinition

AbilityDefinition.MyView {
    id: apis

    property QtObject view: null

    function inCurrentLayout() {
        return view && view.layout && view.layout.isCurrent();
    }

    function action(name) {
        return view ? view.action(name) : null;
    }

    function appletIdForVisualIndex(index) {
        if (!view || !view.extendedInterface || typeof index !== "number") {
            return -1;
        }

        return view.extendedInterface.appletIdForVisualIndex(index);
    }

    function appletIdForAppletIndex(index) {
        if (!view || !view.extendedInterface || typeof index !== "number") {
            return -1;
        }

        return view.extendedInterface.appletIdForAppletIndex(index);
    }

    function addInternalSeparatorBeforeApplet(appletId) {
        if (!view || !view.extendedInterface || typeof appletId !== "number") {
            return false;
        }

        return view.extendedInterface.addInternalSeparatorBeforeApplet(appletId);
    }

    function addInternalSeparatorAtLeftBoundaryOfApplet(appletId) {
        if (!view || !view.extendedInterface || typeof appletId !== "number") {
            return false;
        }

        return view.extendedInterface.addInternalSeparatorAtLeftBoundaryOfApplet(appletId);
    }

    function addInternalSeparatorAtRightBoundaryOfApplet(appletId) {
        if (!view || !view.extendedInterface || typeof appletId !== "number") {
            return false;
        }

        return view.extendedInterface.addInternalSeparatorAtRightBoundaryOfApplet(appletId);
    }

    function removeInternalSeparatorAtLeftBoundaryOfApplet(appletId) {
        if (!view || !view.extendedInterface || typeof appletId !== "number") {
            return false;
        }

        return view.extendedInterface.removeInternalSeparatorAtLeftBoundaryOfApplet(appletId);
    }

    function removeInternalSeparatorAtRightBoundaryOfApplet(appletId) {
        if (!view || !view.extendedInterface || typeof appletId !== "number") {
            return false;
        }

        return view.extendedInterface.removeInternalSeparatorAtRightBoundaryOfApplet(appletId);
    }

    readonly property Item publicApi: Item {
        readonly property alias isReady: apis.isReady
        readonly property alias groupId: apis.groupId

        readonly property alias inNormalState: apis.inNormalState

        readonly property alias isHidden: apis.isHidden
        readonly property alias isShownPartially: apis.isShownPartially
        readonly property alias isShownFully: apis.isShownFully
        readonly property alias isHidingBlocked: apis.isHidingBlocked

        readonly property alias inEditMode: apis.inEditMode
        readonly property alias inConfigureAppletsMode: apis.inConfigureAppletsMode

        readonly property alias inSlidingIn: apis.inSlidingIn
        readonly property alias inSlidingOut: apis.inSlidingOut
        readonly property alias inRelocationAnimation: apis.inRelocationAnimation
        readonly property alias inRelocationHiding: apis.inRelocationHiding

        readonly property alias badgesIn3DStyle: apis.badgesIn3DStyle

        readonly property alias alignment: apis.alignment
        readonly property alias visibilityMode: apis.visibilityMode

        readonly property alias backgroundOpacity: apis.backgroundOpacity

        readonly property alias lastUsedActivity: apis.lastUsedActivity

        readonly property alias appletsLayoutGeometry: apis.appletsLayoutGeometry
        readonly property alias screenGeometry: apis.screenGeometry

        readonly property alias containmentActions: apis.containmentActions

        readonly property alias itemShadow: apis.itemShadow

        // Preserve the public view API name from the definition layer.
        // qmllint disable property-override
        readonly property alias palette: apis.palette
        // qmllint enable property-override

        function action(name) {
            return apis.action(name);
        }

        function inCurrentLayout() {
            return apis.inCurrentLayout();
        }

        function appletIdForVisualIndex(index) {
            return apis.appletIdForVisualIndex(index);
        }

        function appletIdForAppletIndex(index) {
            return apis.appletIdForAppletIndex(index);
        }

        function addInternalSeparatorBeforeApplet(appletId) {
            return apis.addInternalSeparatorBeforeApplet(appletId);
        }

        function addInternalSeparatorAtLeftBoundaryOfApplet(appletId) {
            return apis.addInternalSeparatorAtLeftBoundaryOfApplet(appletId);
        }

        function addInternalSeparatorAtRightBoundaryOfApplet(appletId) {
            return apis.addInternalSeparatorAtRightBoundaryOfApplet(appletId);
        }

        function removeInternalSeparatorAtLeftBoundaryOfApplet(appletId) {
            return apis.removeInternalSeparatorAtLeftBoundaryOfApplet(appletId);
        }

        function removeInternalSeparatorAtRightBoundaryOfApplet(appletId) {
            return apis.removeInternalSeparatorAtRightBoundaryOfApplet(appletId);
        }
    }
}
