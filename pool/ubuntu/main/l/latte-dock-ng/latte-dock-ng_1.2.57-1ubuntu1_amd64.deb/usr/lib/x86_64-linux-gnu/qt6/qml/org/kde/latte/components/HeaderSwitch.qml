/*
    SPDX-FileCopyrightText: 2019 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import QtQuick.Layouts
import QtQuick.Controls as QQC2

import org.kde.plasma.components as PlasmaComponents
import org.kde.kirigami as Kirigami

import "." as LatteExtraControls

Item {
    id: item
    readonly property var units: Kirigami.Units
    Kirigami.Theme.inherit: true
    Kirigami.Theme.colorSet: Kirigami.Theme.Window

    Layout.rightMargin: {
        if (level === 1) {
            return Qt.application.layoutDirection === Qt.RightToLeft ? 0 : 2 * units.smallSpacing
        }

        return 0;
    }
    Layout.leftMargin: {
        if (level === 1) {
            return Qt.application.layoutDirection === Qt.RightToLeft ? 2 * units.smallSpacing : 0
        }

        return 0;
    }

    property int level:1
    property bool checked: false
    property bool isFirstSubCategory: false

    // These implicit sizes intentionally define the switch component's content size.
    // qmllint disable property-override
    readonly property int implicitWidth: row.width

    readonly property int implicitHeight: {
        if (level === 1) {
            return Math.max(headerText.implicitHeight, itemSwitch.implicitHeight);
        } else if (level === 2) {
            return Math.max(subHeaderText.implicitHeight, itemSwitch.implicitHeight)
        }

        return Math.max(labelText.implicitHeight, itemSwitch.implicitHeight);
    }
    // qmllint enable property-override

    property string text:""
    property string tooltip:""

    signal pressed();

    Item {
        id: row
        width: parent.width
        height: textElement.height
        anchors.verticalCenter: parent.verticalCenter

        RowLayout {
            id: textElement
            anchors.left: level !== 2 ? parent.left : undefined
            anchors.horizontalCenter: level === 2 ? parent.horizontalCenter : undefined
            anchors.verticalCenter: parent.verticalCenter

            LatteExtraControls.Header {
                id: headerText
                text: item.text
                enabled: item.checked && item.enabled
                visible: level === 1
                Kirigami.Theme.inherit: true
                Kirigami.Theme.colorSet: Kirigami.Theme.Window
            }

            LatteExtraControls.SubHeader {
                id: subHeaderText
                text: item.text
                enabled: item.checked && item.enabled
                visible: level === 2
                isFirstSubCategory: item.isFirstSubCategory
                Kirigami.Theme.inherit: true
                Kirigami.Theme.colorSet: Kirigami.Theme.Window
            }

            PlasmaComponents.Label {
                id: labelText
                text: item.text
                enabled: item.checked && item.enabled
                visible: level > 2
                Kirigami.Theme.inherit: true
                Kirigami.Theme.colorSet: Kirigami.Theme.Window
            }
        }

        PlasmaComponents.Button {
            //tooltip ghost
            anchors.fill: textElement
            opacity: 0
            Kirigami.Theme.inherit: true
            Kirigami.Theme.colorSet: Kirigami.Theme.Button
            hoverEnabled: true

            QQC2.ToolTip.delay: Kirigami.Units.toolTipDelay
            QQC2.ToolTip.visible: hovered && item.tooltip !== ""
            QQC2.ToolTip.text: item.tooltip

            onPressedChanged: {
                if (pressed) {
                    item.pressed();
                }
            }
        }
    }

    LatteExtraControls.Switch {
        id: itemSwitch
        anchors.verticalCenter: row.verticalCenter
        anchors.right: row.right
        checked: item.checked
        enabled: item.enabled
        Kirigami.Theme.inherit: true
        Kirigami.Theme.colorSet: Kirigami.Theme.Window

        PlasmaComponents.Button {
            //tooltip ghost
            anchors.fill: parent
            opacity: 0
            Kirigami.Theme.inherit: true
            Kirigami.Theme.colorSet: Kirigami.Theme.Button
            hoverEnabled: true

            QQC2.ToolTip.delay: Kirigami.Units.toolTipDelay
            QQC2.ToolTip.visible: hovered && item.tooltip !== ""
            QQC2.ToolTip.text: item.tooltip

            onPressedChanged: {
                if (pressed) {
                    item.pressed();
                }
            }
        }
    }
}
