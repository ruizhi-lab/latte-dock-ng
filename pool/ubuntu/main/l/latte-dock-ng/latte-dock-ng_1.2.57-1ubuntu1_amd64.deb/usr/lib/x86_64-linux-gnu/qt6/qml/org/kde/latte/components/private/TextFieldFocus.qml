/*
    SPDX-FileCopyrightText: 2011 Daker Fernandes Pinheiro <dakerfp@gmail.com>
    SPDX-FileCopyrightText: 2011 Marco Martin <mart@kde.org>

    SPDX-License-Identifier: LGPL-2.0-or-later
*/

import QtQuick
import org.kde.ksvg as KSvg

Item {
    id: main
    state: parent.state

    KSvg.Svg {
        id: lineEditSvg
        imagePath: "widgets/lineedit"
        onRepaintNeeded: {
            if (lineEditSvg.hasElement("hint-focus-over-base")) {
                main.z = 800
            } else {
                main.z = 0
            }
        }
        Component.onCompleted: {
            if (lineEditSvg.hasElement("hint-focus-over-base")) {
                main.z = 800
            } else {
                main.z = 0
            }
        }
    }

    KSvg.FrameSvgItem {
        id: hover

        anchors {
            fill: parent
            leftMargin: -margins.left
            topMargin: -margins.top
            rightMargin: -margins.right
            bottomMargin: -margins.bottom
        }
        opacity: 0
        imagePath: "widgets/lineedit"
        prefix: "hover"
    }

    states: [
        State {
            name: "hover"
            PropertyChanges {
                hover.opacity: 1
                hover.prefix: "hover"
            }
        },
        State {
            name: "focus"
            PropertyChanges {
                hover.opacity: 1
                hover.prefix: "focus"
            }
        },
        State {
            name: "hidden"
            PropertyChanges {
                hover.opacity: 0
                hover.prefix: "hover"
            }
        }
    ]

    transitions: [
        Transition {
            PropertyAnimation {
                properties: "opacity"
                duration: units.longDuration
                easing.type: Easing.OutQuad
            }
        }
    ]
}
