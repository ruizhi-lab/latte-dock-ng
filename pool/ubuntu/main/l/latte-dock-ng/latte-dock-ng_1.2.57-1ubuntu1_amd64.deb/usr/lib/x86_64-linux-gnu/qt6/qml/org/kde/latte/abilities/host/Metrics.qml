/*
    SPDX-FileCopyrightText: 2020 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import org.kde.latte.abilities.definition as AbilityDefinition

AbilityDefinition.Metrics {
    id: apis

    readonly property Item publicApi: Item {
        readonly property alias iconSize: apis.iconSize
        readonly property alias maxIconSize: apis.maxIconSize
        readonly property alias backgroundThickness: apis.backgroundThickness

        readonly property alias margin: apis.margin
        readonly property alias marginsArea: apis.marginsArea
        readonly property alias mask: apis.mask
        readonly property alias padding: apis.padding
        readonly property alias totals: apis.totals
        readonly property bool modernDockStyle: apis.modernDockStyle !== undefined ? apis.modernDockStyle : false
    }
}
