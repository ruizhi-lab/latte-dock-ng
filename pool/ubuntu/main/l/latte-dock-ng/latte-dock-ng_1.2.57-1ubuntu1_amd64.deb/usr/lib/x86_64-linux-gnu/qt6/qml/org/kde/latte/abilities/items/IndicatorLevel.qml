/*
    SPDX-FileCopyrightText: 2021 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import "./indicators" as IndicatorItem

Loader {
    id: indicatorLevelLoader
    active: level.isDrawn
            && level.indicator
            && level.indicator.host.isEnabled
            && level.indicator.configuration
            && (level.isBackground || (level.isForeground && level.indicator.host.info.providesFrontLayer))

    sourceComponent: level.indicator.host ? level.indicator.host.indicatorComponent : null

    readonly property IndicatorItem.LevelOptions level: IndicatorItem.LevelOptions{}
}
