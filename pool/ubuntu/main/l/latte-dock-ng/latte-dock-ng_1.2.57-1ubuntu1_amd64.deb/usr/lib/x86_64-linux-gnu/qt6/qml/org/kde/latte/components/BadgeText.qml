/*
    SPDX-FileCopyrightText: 2019 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import org.kde.kirigami as Kirigami

Rectangle {
    id: badge
    readonly property var units: Kirigami.Units

    property double proportion: 0

    property double previousProportion: 0

    property bool style3d: true

    property int numberValue
    property string textValue

    property bool fullCircle: true
    property bool showNumber: true
    property bool showText: false
    property bool textWithBackgroundColor: false

    property int radiusPerCentage: 100
    property int minimumWidth: 0
    property int maximumWidth: 9999

    property double circleOpacity: 1
    property double fontPixelSize: partSize // * 0.55

    property double stdThickness: partSize < 0 ? 0 : partSize  //  "/2.1"
    property double circleThicknessAttr: fullCircle ? 0 : stdThickness * 0.9
    property double partSize: height / 2
    property double pi2: Math.PI * 2
    readonly property bool hasTheme: (typeof theme !== "undefined") && theme
    readonly property color fallbackBackgroundColor: "#2d2d2d"
    readonly property color fallbackTextColor: "#f3f3f3"
    readonly property color fallbackHighlightColor: "#3daee9"

    width: Math.max(minimumWidth, valueText.width + 4*units.smallSpacing)

    color: hasTheme && theme.backgroundColor !== undefined ? theme.backgroundColor : fallbackBackgroundColor
    radius: (radiusPerCentage / 100) * (height / 2)
    border.width: 0 //Math.max(1,width/64)

    property int borderWidth: 1
    property real borderOpacity: 1
    property color borderColor: hasTheme && theme.textColor !== undefined ? theme.textColor : fallbackTextColor
    property color textColor: hasTheme && theme.textColor !== undefined ? theme.textColor : fallbackTextColor
    property color highlightedColor: hasTheme && theme.buttonFocusColor !== undefined ? theme.buttonFocusColor : fallbackHighlightColor

    readonly property bool singleCharacter: (showNumber && numberValue<=9 && numberValue>=0)|| (showText && textValue.length===1)

    onProportionChanged: {
        if (proportion<0.03) {
            previousProportion = 0;
        }

        //console.log(previousProportion + " - "+proportion);
        var currentStep = (proportion - previousProportion);
        if ((currentStep >= 0.01) || (proportion>=1 && previousProportion !==1)) {
            //   console.log("request repaint...");
            previousProportion = proportion;
            repaint();
        }
    }

    function repaint() {
        canvas.requestPaint()
    }

    Canvas {
        id: canvas

        property int lineWidth: 1
        property bool fill: true
        property bool stroke: true
        property real alpha: 1.0

        // edge bleeding fix
        readonly property double filler: 0.01

        width: parent.width - 2 * parent.borderWidth
        height: parent.height - 2 * parent.borderWidth
        opacity: badge.proportion > 0 ? 1 : 0

        anchors.centerIn: parent

        property color drawColor: badge.highlightedColor

        onDrawColorChanged: requestPaint();

        onPaint: {
            var ctx = getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = drawColor;

            var startRadian = - Math.PI / 2;

            var radians = badge.pi2 * badge.proportion;

            ctx.beginPath();
            ctx.arc(width/2, height/2, badge.stdThickness, startRadian, startRadian + radians + filler, false);
            ctx.arc(width/2, height/2, badge.circleThicknessAttr, startRadian + radians + filler, startRadian, true);

            ctx.closePath();
            ctx.fill();
        }
    }

    Rectangle {
        id: badgerBackground
        anchors.fill: canvas
        color: canvas.drawColor

        visible: badge.proportion === 1 && badge.showNumber
        radius: parent.radius
    }

    Text {
        id: valueText
        anchors.centerIn: canvas

        width: Math.min(badge.maximumWidth - 4*badge.units.smallSpacing, implicitWidth)
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter

        elide: Text.ElideRight

        text: {
            if (badge.showNumber) {
                if (badge.numberValue > 9999) {
                    return i18nc("Over 9999 new messages, overlay, keep short", "9,999+");
                } else if (badge.numberValue > 0) {
                    return badge.numberValue.toLocaleString(Qt.locale(), 'f', 0);
                }
            }

            if (badge.showText) {
                return badge.textValue;
            }

            return "";
        }
        font.pixelSize: Math.round(0.62 * badge.height)
        font.bold: true
        color: badge.textWithBackgroundColor ? badge.color : badge.textColor
        visible: badge.showNumber || badge.showText
    }

    Rectangle{
        anchors.fill: parent
        anchors.topMargin: parent.borderWidth
        anchors.bottomMargin: parent.borderWidth
        anchors.leftMargin: parent.borderWidth
        anchors.rightMargin: parent.borderWidth
        color: "transparent"
        border.width: parent.borderWidth > 0 ? parent.borderWidth+1 : 0
        border.color: "black"
        radius: parent.radius
        opacity: 0.4

        visible: badge.style3d
    }

    Rectangle{
        anchors.fill: parent
        border.width: parent.borderWidth
        border.color: {
            if (badge.style3d) {
                return badge.borderColor
            }

            return badge.proportion === 1 ? badge.highlightedColor : badge.color
        }
        color: "transparent"
        radius: parent.radius
        opacity: parent.borderOpacity
    }
}
