/*
    SPDX-FileCopyrightText: 2021 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import org.kde.plasma.core as PlasmaCore

Item {
    Binding {
        target: _abilityContainer.layout.parent
        property: "width"
        value: plasmoid.formFactor !== PlasmaCore.Types.Vertical ? _abilityContainer.layout.parent.contentWidth :
                                                                   _abilityContainer.thickness
    }

    Binding {
        target: _abilityContainer.layout.parent
        property: "height"
        value: plasmoid.formFactor !== PlasmaCore.Types.Vertical ? _abilityContainer.thickness :
                                                                   _abilityContainer.layout.parent.contentHeight
    }

    Binding {
        target: _abilityContainer.layout.parent
        property: "boundsBehavior"
        value: Flickable.StopAtBounds
    }

    Binding {
        target: _abilityContainer.layout.parent
        property: "orientation"
        value: plasmoid.formFactor === PlasmaCore.Types.Vertical ? Qt.Vertical : Qt.Horizontal
    }
}
