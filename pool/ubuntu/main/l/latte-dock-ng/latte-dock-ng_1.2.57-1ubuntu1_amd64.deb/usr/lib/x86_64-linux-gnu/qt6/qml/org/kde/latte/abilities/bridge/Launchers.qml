/*
    SPDX-FileCopyrightText: 2021 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

BridgeItem {
    id: launchersBridge
    readonly property bool isConnected: host && client

    onClientChanged: {
        if (client) {
            if (host.appletIdStealingDroppedLaunchers !== launchersBridge.appletIndex) {
                client.disabledIsStealingDroppedLaunchers();
            }
        }
    }

    Connections {
        target: client
        function onIsStealingDroppedLaunchersChanged() {
            if (isConnected && client.isStealingDroppedLaunchers) {
                host.currentAppletStealingDroppedLaunchers(appletIndex);
            }
        }
    }

    Connections {
        target: host
        function onCurrentAppletStealingDroppedLaunchers() {
            if (appletIndex !== id && client) {
                client.disabledIsStealingDroppedLaunchers();
            }
        }
    }
}
