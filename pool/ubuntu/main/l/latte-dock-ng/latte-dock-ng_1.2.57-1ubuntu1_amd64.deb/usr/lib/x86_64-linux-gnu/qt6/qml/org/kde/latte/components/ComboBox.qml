/*
    SPDX-FileCopyrightText: 2016 Marco Martin <mart@kde.org>

    SPDX-License-Identifier: LGPL-2.0-or-later
*/

import QtQuick
import QtQuick.Window
import QtQuick.Templates as T
import QtQuick.Controls as Controls
import QtQuick.Layouts
import QtQuick.Effects
import org.kde.plasma.components as PlasmaComponents
import org.kde.kirigami as Kirigami
import org.kde.ksvg as KSvg
import "private" as Private

T.ComboBox {
    id: control
    Kirigami.Theme.inherit: true

    // Kirigami owns these objects; keep their dynamic QML type so
    // palette and metrics bindings follow host updates without conversion.
    readonly property var theme: Kirigami.Theme
    readonly property var units: Kirigami.Units
    SystemPalette {
        id: systemPalette
        colorGroup: SystemPalette.Active
    }

    readonly property color safeBackgroundColor: systemPalette.window
    readonly property color safeButtonColor: systemPalette.button
    readonly property color safePopupHighlightColor: systemPalette.highlight
    readonly property color safeTextColor: readableTextColor(safeBackgroundColor, systemPalette.windowText)
    readonly property color safeHighlightedTextColor: readableTextColor(safePopupHighlightColor, systemPalette.highlightedText)
    readonly property color safeButtonTextColor: readableTextColor(safeButtonColor, systemPalette.buttonText)
    readonly property color safePopupTextColor: readableTextColor(safeBackgroundColor, systemPalette.windowText)
    readonly property color safePopupHighlightedTextColor: readableTextColor(safePopupHighlightColor, systemPalette.highlightedText)
    readonly property color safeButtonBorderColor: Qt.rgba(safeTextColor.r, safeTextColor.g, safeTextColor.b, 0.35)
    readonly property color safePressedBorderColor: (theme && theme.highlightColor !== undefined)
                                                    ? theme.highlightColor
                                                    : safeButtonBorderColor
    readonly property int frameMargin: units.smallSpacing

    function modelItemAt(idx) {
        if (!model || idx < 0) {
            return null;
        }

        if (Array.isArray(model)) {
            return model[idx];
        }

        if (typeof model.get === "function") {
            return model.get(idx);
        }

        return model[idx];
    }

    function modelRoleAt(idx, role) {
        if (!role || role.length === 0) {
            return "";
        }

        var item = modelItemAt(idx);
        return item ? item[role] : "";
    }

    function colorBrightness(colorValue) {
        return ((colorValue.r * 255 * 299) + (colorValue.g * 255 * 587) + (colorValue.b * 255 * 114)) / 1000;
    }

    function readableTextColor(backgroundColor, preferredColor) {
        if (Math.abs(colorBrightness(backgroundColor) - colorBrightness(preferredColor)) >= 80) {
            return preferredColor;
        }

        return colorBrightness(backgroundColor) > 127.5
                ? Qt.rgba(0.12, 0.13, 0.15, 1)
                : Qt.rgba(0.95, 0.95, 0.95, 1);
    }

    implicitWidth: Math.max(background ? background.implicitWidth : 0,
                            contentItem.implicitWidth + leftPadding + rightPadding) + indicator.implicitWidth + rightPadding
    implicitHeight: units.gridUnit * 1.6
    baselineOffset: contentItem.y + contentItem.baselineOffset

    hoverEnabled: true
    topPadding: frameMargin
    leftPadding: frameMargin
    rightPadding: frameMargin + units.gridUnit * 2
    bottomPadding: frameMargin

    wheelEnabled: false

    property bool hideDisplayText: false
    property bool hideSelectedItemIcon: false

    property bool blankSpaceForEmptyIcons: false
    property bool forcePressed: false
    property bool popUpAlignRight: true
    property bool buttonIsTransparent: false
    property int minimumPopUpWidth: 150
    property int popUpItemHeight: Math.max(30, Math.round(units.gridUnit * 2.3))
    property int popUpRelativeX: 0
    property int popUpTextHorizontalAlignment: Text.AlignLeft

    property string enabledRole
    property string iconRole
    property string iconToolTipRole
    property string iconOnlyWhenHoveredRole
    property string isSeparatorRole
    property string toolTipRole

    signal iconClicked(int index);

    delegate: ItemDelegate {
        width: control.popup.width
        height: isSeparator ? 1 : control.popUpItemHeight
        enabled: !isSeparator && (!control.enabledRole.length || control.modelRoleAt(index, control.enabledRole))
        text: control.textRole.length ? control.modelRoleAt(index, control.textRole) : modelData
        iconName: control.iconRole.length ? control.modelRoleAt(index, control.iconRole) : ''
        iconToolTip: control.iconToolTipRole.length ? control.modelRoleAt(index, control.iconToolTipRole) : ''
        iconOnlyWhenHovered: control.iconOnlyWhenHoveredRole.length ? control.modelRoleAt(index, control.iconOnlyWhenHoveredRole) : ''
        isSeparator: control.isSeparatorRole.length ? control.modelRoleAt(index, control.isSeparatorRole) : false
        toolTip: control.toolTipRole.length ? control.modelRoleAt(index, control.toolTipRole) : ''
        textColor: control.safePopupTextColor
        highlightedTextColor: control.safePopupHighlightedTextColor
        highlightColor: control.safePopupHighlightColor

        highlighted: mouseArea.pressed ? listView.currentIndex == index : control.currentIndex == index
        blankSpaceForEmptyIcons: control.blankSpaceForEmptyIcons
        textHorizontalAlignment: control.popUpTextHorizontalAlignment

        property bool separatorVisible: false

        PlasmaComponents.Button {
            id: tooltipBtn
            anchors.fill: parent
            opacity: 0
            visible: parent.toolTip !== ''

            PlasmaComponents.ToolTip { text: tooltipBtn.parent ? tooltipBtn.parent.toolTip : "" }

            onPressedChanged: {
                if (!pressed) {
                    control.currentIndex = index;
                    control.down = false;
                    control.popup.visible = false;
                }
            }
        }
    }

    indicator: KSvg.SvgItem {
        implicitWidth: control.units.iconSizes.small
        implicitHeight: implicitWidth
        anchors {
            right: parent.right
            rightMargin: control.buttonIsTransparent ? 0 : frameMargin
            verticalCenter: parent.verticalCenter
        }
        svg: KSvg.Svg {
            imagePath: "widgets/arrows"
        }
        elementId: "down-arrow"
    }

    //     contentItem: Label {
    //         text: control.displayText
    //         font: control.font
    //         color: theme.buttonTextColor
    //         horizontalAlignment: Text.AlignLeft
    //         verticalAlignment: Text.AlignVCenter
    //         elide: Text.ElideRight
    //     }
    contentItem: MouseArea {
        id: mouseArea
        anchors.fill: parent
        acceptedButtons: Qt.LeftButton
        preventStealing: true
        property int indexUnderMouse: -1
        onWheel: function(wheel) {
            if (!control.wheelEnabled) {
                return;
            }

            if (wheel.pixelDelta.y < 0 || wheel.angleDelta.y < 0) {
                control.currentIndex = Math.min(control.currentIndex + 1, delegateModel.count -1);
            } else {
                control.currentIndex = Math.max(control.currentIndex - 1, 0);
            }
            control.activated(control.currentIndex);
        }
        onPressed: onGenericPressed()
        onReleased: onGenericReleased()
        onCanceled: {
            control.down = false;
        }
        onPositionChanged: (mouse) => {
            var pos = listView.mapFromItem(this, mouse.x, mouse.y);
            indexUnderMouse = listView.indexAt(pos.x, pos.y);
            listView.currentIndex = indexUnderMouse;
            control.activated(indexUnderMouse);
        }

        Connections {
            target: popup
            function onClosed() {
                control.down = false;
            }
        }

        function onGenericPressed() {
            indexUnderMouse = -1;
            listView.currentIndex = control.highlightedIndex;
            control.down = true;
            control.popup.visible = !control.popup.visible;
        }

        function onGenericReleased() {
            if (!containsMouse && !hiddenTooltipButton.hovered) {
                control.down = false;
                control.popup.visible = false;
            }
            if (indexUnderMouse > -1) {
                control.currentIndex = indexUnderMouse;
            }
        }

        PlasmaComponents.Button {
            id: hiddenTooltipButton
            anchors.fill: parent
            opacity: 0
            visible: control && control.currentIndex>=0 && control.toolTipRole.length>0

            property string computedTooltip: {
                if (!visible) return "";
                return control.modelRoleAt(control.currentIndex, control.toolTipRole);
            }

            PlasmaComponents.ToolTip { text: hiddenTooltipButton.computedTooltip }

            onPressedChanged: {
                if (pressed) {
                    mouseArea.onGenericPressed();
                } else {
                    mouseArea.onGenericReleased();
                }
            }
        }

        RowLayout {
            anchors.fill: parent
            spacing: 0

            anchors {
                leftMargin: control.leftPadding
                rightMargin: control.rightPadding
            }

            Kirigami.Icon {
                id: selectedIcon
                implicitWidth: textLabel.height
                implicitHeight: textLabel.height

                source: {
                    if (control
                            && control.currentIndex>=0
                            && control.iconRole.length>0) {
                        return control.modelRoleAt(control.currentIndex, control.iconRole);
                    }

                    return "";
                }

                visible: source !== '' && !control.hideSelectedItemIcon
            }

            Label {
                id: textLabel
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.leftMargin: !selectedIcon.visible && !control.mirrored ? control.units.smallSpacing : 0
                Layout.rightMargin: !selectedIcon.visible && control.mirrored ? control.units.smallSpacing : 0

                text: {
                    if (control.currentIndex < 0 || !control.textRole || control.textRole.length === 0) {
                        return control.displayText;
                    }
                    var item = control.modelItemAt(control.currentIndex);
                    return item ? (item[control.textRole] || "") : "";
                }
                font: control.font
                color: control.buttonIsTransparent ? control.safeTextColor : control.safeButtonTextColor
                horizontalAlignment: Text.AlignLeft
                verticalAlignment: Text.AlignVCenter
                opacity: control.enabled ? 1 : 0.6

                visible: !control.hideDisplayText
            }

         /*   T.TextField {
                id: textField
                padding: 0
                Layout.fillWidth: true
                Layout.fillHeight: true

                text: control.editable ? control.editText : control.displayText

                enabled: control.editable
                autoScroll: control.editable

                readOnly: control.down || !control.hasOwnProperty("editable") || !control.editable
                inputMethodHints: control.inputMethodHints
                validator: control.validator

                // Work around Qt bug where NativeRendering breaks for non-integer scale factors
                // https://bugreports.qt.io/browse/QTBUG-67007
                renderType: Screen.devicePixelRatio % 1 !== 0 ? Text.QtRendering : Text.NativeRendering
                color: theme.buttonTextColor //control.enabled ? theme.textColor : theme.disabledTextColor
                selectionColor: Kirigami.Theme.highlightColor
                selectedTextColor: Kirigami.Theme.highlightedTextColor

                selectByMouse: !Kirigami.Settings.tabletMode
                cursorDelegate: Kirigami.Settings.tabletMode ? mobileCursor : undefinedCursor

                font: control.font
                horizontalAlignment: Text.AlignLeft
                verticalAlignment: Text.AlignVCenter
                opacity: control.enabled ? 1 : 0.6
                onFocusChanged: {
                    if (focus) {
                        Private.MobileTextActionsToolBar.controlRoot = textField;
                    }
                }

                onPressAndHold: {
                    if (!Kirigami.Settings.tabletMode) {
                        return;
                    }
                    forceActiveFocus();
                    cursorPosition = positionAt(event.x, event.y);
                    selectWord();
                }
            }*/
        }
    }

  /*  Component {
        id: mobileCursor
        Private.MobileCursor {
            target: textField
        }
    }*/

    Component {
        id: undefinedCursor
        Item{}
    }

 /*   Private.MobileCursor {
        target: textField
        selectionStartHandle: true
        property var rect: textField.positionToRectangle(textField.selectionStart)
        //FIXME: this magic values seem to be always valid, for every font,every dpi, every scaling
        x: rect.x + 5
        y: rect.y + 6
    }*/

    background: Rectangle {
        id: surfaceNormal
        implicitWidth: control.units.gridUnit * 6
        width: parent.width
        height: parent.height
        radius: Math.max(2, control.units.smallSpacing)
        color: control.safeButtonColor
        border.width: 1
        border.color: control.pressed || control.forcePressed
                      ? control.safePressedBorderColor
                      : control.safeButtonBorderColor

        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.rightMargin: control.buttonIsTransparent ? -control.frameMargin : 0
        opacity: control.buttonIsTransparent && !control.pressed && !control.popup.visible ? 0 : 1

        MouseArea {
            anchors {
                fill: parent
                leftMargin: control.leftPadding
                rightMargin: control.rightPadding
            }
            acceptedButtons: Qt.NoButton
            onWheel: function(wheel) {
                if (!control.wheelEnabled) {
                    return;
                }

                if (wheel.pixelDelta.y < 0 || wheel.angleDelta.y < 0) {
                    control.currentIndex = Math.min(control.currentIndex + 1, delegateModel.count -1);
                } else {
                    control.currentIndex = Math.max(control.currentIndex - 1, 0);
                }
                control.activated(control.currentIndex);
            }
        }
    }

    popup: T.Popup {
        Kirigami.Theme.inherit: false
        Kirigami.Theme.colorSet: Kirigami.Theme.Window

        x: {
            if (!control.mirrored) {
                return exceedsContent && control.popUpAlignRight ? control.width - width : control.popUpRelativeX;
            } else {
                //! mirrored case
                if (exceedsContent && control.popUpAlignRight) {
                    var adjustedX = width - control.width - control.popUpRelativeX;
                    return  -adjustedX;
                } else {
                    return 0;
                }
            }
        }
        y: control.height
        width: Math.max(control.width, control.minimumPopUpWidth)
        implicitHeight: contentItem.implicitHeight + topPadding + bottomPadding
        height: implicitHeight
        topPadding: 2
        bottomPadding: 2
        topMargin: 6
        bottomMargin: 6

        readonly property bool exceedsContent: control.width < width

        /*onVisibleChanged: {
            if (visible) {
                console.log("  mirrored:" + control.mirrored);
                console.log("  exceeds: " + exceedsContent);
                console.log("  popupAR: " + control.popUpAlignRight);
                console.log("  popupRX: " + popUpRelativeX);
            }
        }*/

        contentItem: ListView {
            id: listView
            clip: true
            implicitHeight: Math.max(contentHeight, control.count * control.popUpItemHeight)
            model: control.popup.visible ? control.delegateModel : null
            currentIndex: control.highlightedIndex
            highlightRangeMode: ListView.ApplyRange
            highlightMoveDuration: 0
            // HACK: When the ComboBox is not inside a top-level Window, it's Popup does not inherit
            // the LayoutMirroring options. This is a workaround to fix this by enforcing
            // the LayoutMirroring options properly.
            // QTBUG: https://bugreports.qt.io/browse/QTBUG-66446
            LayoutMirroring.enabled: Qt.application.layoutDirection === Qt.RightToLeft
            LayoutMirroring.childrenInherit: true
            T.ScrollBar.vertical: Controls.ScrollBar { }

            signal iconClicked(int index);

            onIconClicked: control.iconClicked(index);
        }
        background: Rectangle {
            anchors {
                fill: parent
                margins: -1
            }
            radius: 2
            color: control.safeBackgroundColor
            border.color: Qt.rgba(control.safeTextColor.r, control.safeTextColor.g, control.safeTextColor.b, 0.3)
            layer.enabled: true

            layer.effect: MultiEffect {
                shadowEnabled: true
                shadowColor: Qt.rgba(0, 0, 0, 0.3)
                shadowBlur: 0.125
                shadowHorizontalOffset: 2
                shadowVerticalOffset: 2
            }
        }
    }
}
