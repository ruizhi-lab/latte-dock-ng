/*
    SPDX-FileCopyrightText: 2019 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import QtQuick.Effects

import org.kde.kirigami as Kirigami
import org.kde.plasma.core as PlasmaCore

import "code/ColorizerTools.js" as ColorizerTools

Rectangle{
    id: addingArea
    readonly property var theme: Kirigami.Theme
    readonly property var units: Kirigami.Units
    color: Qt.rgba(theme.backgroundColor.r, theme.backgroundColor.g, theme.backgroundColor.b, backgroundOpacity)
    border.width: 1
    border.color: outlineColor

    property bool drawAddCross: true

    property int iconSize: 64

    readonly property color outlineColorBase: theme.backgroundColor
    readonly property real outlineColorBaseBrightness: ColorizerTools.colorBrightness(outlineColorBase)
    readonly property color outlineColor: {
        if (outlineColorBaseBrightness > 127.5) {
            return Qt.darker(outlineColorBase, 1.5);
        } else {
            return Qt.lighter(outlineColorBase, 2.2);
        }
    }

    property real backgroundOpacity: 0.75
    property real duration: 2
    property string title: ""

    Behavior on opacity{
        NumberAnimation { duration: 2*addingArea.duration*appletItem.animationTime }
    }


    Label {
        id: heading
        text: title       
        color: theme.textColor
        font.bold: true

        rotation: {
            if (plasmoid.location === PlasmaCore.Types.LeftEdge) {
                return 90;
            } else if (plasmoid.location === PlasmaCore.Types.RightEdge) {
                return -90;
            }

            return 0;
        }

        transformOrigin: {
            if (plasmoid.location === PlasmaCore.Types.LeftEdge) {
                return Item.TopLeft;
            } else if (plasmoid.location === PlasmaCore.Types.RightEdge) {
                return Item.TopRight;
            }

            return Item.Center;
        }

        readonly property int lengthEdge: addingArea.radius + units.smallSpacing

        layer.enabled: true
        layer.effect: MultiEffect {
            shadowEnabled: true
            shadowColor: "#020202"
            shadowBlur: 0.125
        }

        states: [
            ///Bottom Edge
            State {
                name: "left"
                when: plasmoid.location === PlasmaCore.Types.LeftEdge

                AnchorChanges {
                    target: heading
                    anchors{ top:parent.top; bottom:undefined; left:parent.right; right:undefined;}
                }

                PropertyChanges {
                    heading.anchors.topMargin: heading.lengthEdge; heading.anchors.bottomMargin:0; heading.anchors.leftMargin:-units.smallSpacing; heading.anchors.rightMargin:-0;
                }
            },
            State {
                name: "right"
                when: plasmoid.location === PlasmaCore.Types.RightEdge

                AnchorChanges {
                    target: heading
                    anchors{ top:parent.top; bottom:undefined; left:undefined; right:parent.left;}
                }

                PropertyChanges {
                    heading.anchors.topMargin:heading.lengthEdge; heading.anchors.bottomMargin:0; heading.anchors.leftMargin: 0; heading.anchors.rightMargin:-units.smallSpacing;
                }
            },
            State {
                name: "top"
                when:  plasmoid.location === PlasmaCore.Types.TopEdge

                AnchorChanges {
                    target: heading
                    anchors{ top:undefined; bottom:parent.bottom; left:parent.left; right:undefined;}
                }

                PropertyChanges {
                    heading.anchors.topMargin:0; heading.anchors.bottomMargin:units.smallSpacing; heading.anchors.leftMargin: heading.lengthEdge; heading.anchors.rightMargin:0;
                }
            },
            State {
                name: "bottom"
                when: plasmoid.location !== PlasmaCore.Types.TopEdge
                      && plasmoid.location !== PlasmaCore.Types.LeftEdge
                      && plasmoid.location !== PlasmaCore.Types.RightEdge

                AnchorChanges {
                    target: heading
                    anchors{ top:parent.top; bottom:undefined; left:parent.left; right:undefined;}
                }

                PropertyChanges {
                    heading.anchors.topMargin:units.smallSpacing; heading.anchors.bottomMargin:0; heading.anchors.leftMargin: heading.lengthEdge; heading.anchors.rightMargin:0;
                }
            }
        ]
    }

    AddItem {
        anchors.centerIn: parent
        visible: drawAddCross
        width: thickness
        height: thickness

        readonly property int thickness: Math.min(addingArea.iconSize,
                                                  plasmoid.formFactor === PlasmaCore.Types.Horizontal ? (parent.height - freeSpace):(parent.width - freeSpace))

        readonly property int freeSpace: Math.max(16, (heading.implicitHeight + units.smallSpacing*2))
    }
}
