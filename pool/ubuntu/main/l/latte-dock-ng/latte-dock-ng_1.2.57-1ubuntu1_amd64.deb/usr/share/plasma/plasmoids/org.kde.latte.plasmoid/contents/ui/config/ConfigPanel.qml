/*
    SPDX-FileCopyrightText: 2016 Smith AR <audoban@openmailbox.org>
    SPDX-FileCopyrightText: 2016 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.kde.plasma.core as PlasmaCore

Item {
    id: mainItem

    width: childrenRect.width
    height: childrenRect.height

    property bool vertical: (plasmoid.formFactor == PlasmaCore.Types.Vertical)

    property alias cfg_showBarLine: showBarLine.checked
    property alias cfg_useThemePanel: useThemePanel.checked
    property alias cfg_panelSize: panelSize.value
    property alias cfg_transparentPanel: transparentPanel.checked

    ColumnLayout {

        id:mainColumn
        spacing: 15
        Layout.fillWidth: true

        GridLayout{
            Layout.fillWidth: true
            columns: 3
            property bool panelConfigEnabled: showBarLine.checked && useThemePanel.checked

            Label{}

            CheckBox {
                id: showBarLine
                Layout.columnSpan: 3
                text: i18n("Show bar line for tasks")
                enabled: true
            }

            CheckBox {
                id: useThemePanel
                Layout.columnSpan: 3
                text: i18n("Use plasma theme panel")
                enabled: showBarLine.checked
            }

            CheckBox {
                id: transparentPanel
                Layout.columnSpan: 3
                text: i18n("Use transparency in the panel")
                enabled: parent.panelConfigEnabled
            }


            Label {
                id: panelLabel
                text: i18n("Size: ")
                enabled: parent.panelConfigEnabled
            }

            Slider {
                id: panelSize
                enabled: parent.panelConfigEnabled
                Layout.fillWidth: true
                from: 0
                to: 256
                stepSize: 2
            }

            Label {
                enabled: parent.panelConfigEnabled
                Layout.minimumWidth: metricsLabel.width
                Layout.maximumWidth: metricsLabel.width
                Layout.alignment: Qt.AlignRight
                horizontalAlignment: Text.AlignRight

                text: ( panelSize.value + " px." )

                Label{
                    id:metricsLabel
                    visible: false
                    text: panelSize.to + " px."
                }
            }

            /*    Label{
                Layout.columnSpan: 3
                Layout.fillWidth: false
                Layout.alignment: Qt.AlignRight
                Layout.maximumWidth: zoomLevel.width + zoomLevelText.width + panelLabel.width
                horizontalAlignment: Text.AlignRight
                text: i18n("in panel placement, themes that have set a <b>specific</b> panel transparent work better")
                wrapMode: Text.WordWrap
                font.italic: true
                enabled: parent.panelConfigEnabled
            }*/

            /////
            //spacer to set a minimumWidth for sliders
            //Layout.minimumWidth didn't work
            Label{}
            Label{Layout.minimumWidth: 280}
            Label{}

        }
    }

}
