/*
    SPDX-FileCopyrightText: 2016 Smith AR <audoban@openmailbox.org>
    SPDX-FileCopyrightText: 2016 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import QtQuick.Layouts
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PlasmaComponents

import org.kde.latte.core as LatteCore
import org.kde.latte.components as LatteComponents
import org.kde.latte.private.containment as LatteContainment

import "../../controls" as LatteExtraControls

PlasmaComponents.Page {
    id: page
    required property var dialog
    required property var latteView
    required property var universalSettings
    required property var viewConfig
    readonly property var units: page.dialog.units
    width: content.width + content.Layout.leftMargin * 2
    height: content.height + units.smallSpacing * 2

    ColumnLayout {
        id: content       
        width: (page.dialog.appliedWidth - units.smallSpacing * 2) - Layout.leftMargin * 2
        spacing: page.dialog.subGroupSpacing
        anchors.horizontalCenter: parent.horizontalCenter
        Layout.leftMargin: units.smallSpacing * 2

        //! BEGIN: Location
        ColumnLayout {
            Layout.fillWidth: true
            spacing: units.smallSpacing
            Layout.topMargin: units.smallSpacing

            LatteComponents.Header {
                text: screenRow.visible ? i18n("Screen") : i18n("Location")
            }

            Connections {
                target: page.universalSettings
                function onScreensCountChanged() { screenRow.updateScreens() }
            }

            RowLayout {
                id: screenRow
                Layout.fillWidth: true
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 3
                spacing: 2
                visible: screensCount > 1 || page.dialog.advancedLevel

                property int screensCount: 1

                function updateScreens() {
                    screensCount = page.universalSettings.screens.length;
                    screensModel.clear();

                    var primary = {name: i18n("On Primary Screen"), icon: 'favorite'};
                    screensModel.append(primary);

                    var allscreens = {name: i18n("On All Screens"), icon: 'favorite'};
                    screensModel.append(allscreens);

                    var allsecscreens = {name: i18n("On All Secondary Screens"), icon: 'favorite'};
                    screensModel.append(allsecscreens);

                    //check if the screen exists, it is used in cases Latte is moving
                    //the view automatically to primaryScreen in order for the user
                    //to has always a view with tasks shown
                    var screenExists = false
                    for (var i = 0; i < page.universalSettings.screens.length; i++) {
                        if (page.universalSettings.screens[i].name === page.latteView.positioner.currentScreenName) {
                            screenExists = true;
                        }
                    }

                    if (!screenExists && !page.latteView.onPrimary) {
                        var scr = {name: page.latteView.positioner.currentScreenName, icon: 'view-fullscreen'};
                        screensModel.append(scr);
                    }

                    for (var i = 0; i < page.universalSettings.screens.length; i++) {
                        var scr = {name: page.universalSettings.screens[i].name, icon: 'view-fullscreen'};
                        screensModel.append(scr);
                    }

                    if (page.latteView.onPrimary && page.latteView.screensGroup === LatteCore.types.SingleScreenGroup) {
                        screenCmb.currentIndex = 0;
                    } else if (page.latteView.screensGroup === LatteCore.types.AllScreensGroup) {
                        screenCmb.currentIndex = 1;
                    } else if (page.latteView.screensGroup === LatteCore.types.AllSecondaryScreensGroup) {
                        screenCmb.currentIndex = 2;
                    } else {
                        screenCmb.currentIndex = screenCmb.findScreen(page.latteView.positioner.currentScreenName);
                    }

                }

                Connections{
                    target: page.viewConfig
                    function onShowSignal() { screenRow.updateScreens(); }
                }

                ListModel {
                    id: screensModel
                }

                LatteComponents.ComboBox {
                    id: screenCmb
                    Layout.fillWidth: true
                    model: screensModel
                    textRole: "name"
                    iconRole: "icon"

                    Component.onCompleted: screenRow.updateScreens();

                    onActivated: function(index) {
                        if (index === 0) { // primary
                            page.latteView.positioner.setNextLocation("", LatteCore.types.SingleScreenGroup, "{primary-screen}", PlasmaCore.Types.Floating, LatteCore.types.NoneAlignment);
                        } else if (index === 1) { // all screens
                            page.latteView.positioner.setNextLocation("", LatteCore.types.AllScreensGroup, "{primary-screen}", PlasmaCore.Types.Floating, LatteCore.types.NoneAlignment);
                        } else if (index === 2) { // all secondary screens
                            page.latteView.positioner.setNextLocation("", LatteCore.types.AllSecondaryScreensGroup, "", PlasmaCore.Types.Floating, LatteCore.types.NoneAlignment);
                        } else if (index>2 && (index !== findScreen(page.latteView.positioner.currentScreenName) || page.latteView.onPrimary)) {// explicit screen
                            page.latteView.positioner.setNextLocation("", LatteCore.types.SingleScreenGroup, textAt(index), PlasmaCore.Types.Floating, LatteCore.types.NoneAlignment);
                        }
                    }

                    function findScreen(scrName) {                        
                        for(var i=0; i<screensModel.count; ++i) {
                            if (screensModel.get(i).name === scrName) {
                                return i;
                            }
                        }

                        return 0;
                    }
                }
            }

            RowLayout {
                id: locationLayout
                Layout.fillWidth: true
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2
                Layout.topMargin: screenRow.visible ? units.smallSpacing : 0
                LayoutMirroring.enabled: false
                spacing: 2

                readonly property int buttonSize: (page.dialog.optionsWidth - (spacing * 3)) / 4

                LatteComponents.Button {
                    id: bottomEdgeBtn
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: i18nc("bottom location", "Bottom")
                    icon.name: "arrow-down"
                    checked: plasmoid.location === edge
                    checkable: true

                    readonly property int edge: PlasmaCore.Types.BottomEdge

                    onClicked: {
                        if (page.viewConfig.isReady && plasmoid.location !== edge) {
                            page.latteView.positioner.setNextLocation("", page.latteView.screensGroup, "", edge, LatteCore.types.NoneAlignment);
                        }
                        checked = Qt.binding(function() { return plasmoid.location === edge })
                    }
                }
                LatteComponents.Button {
                    id: leftEdgeBtn
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: i18nc("left location", "Left")
                    icon.name: "arrow-left"
                    checked: plasmoid.location === edge
                    checkable: true

                    readonly property int edge: PlasmaCore.Types.LeftEdge

                    onClicked: {
                        if (page.viewConfig.isReady && plasmoid.location !== edge) {
                            page.latteView.positioner.setNextLocation("", page.latteView.screensGroup, "", edge, LatteCore.types.NoneAlignment);
                        }
                        checked = Qt.binding(function() { return plasmoid.location === edge })
                    }
                }
                LatteComponents.Button {
                    id: topEdgeBtn
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: i18nc("top location", "Top")
                    icon.name: "arrow-up"
                    checked: plasmoid.location === edge
                    checkable: true

                    readonly property int edge: PlasmaCore.Types.TopEdge

                    onClicked: {
                        if (page.viewConfig.isReady && plasmoid.location !== edge) {
                            page.latteView.positioner.setNextLocation("", page.latteView.screensGroup, "", edge, LatteCore.types.NoneAlignment);
                        }
                        checked = Qt.binding(function() { return plasmoid.location === edge })
                    }
                }
                LatteComponents.Button {
                    id: rightEdgeBtn
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: i18nc("right location", "Right")
                    icon.name: "arrow-right"
                    checked: plasmoid.location === edge
                    checkable: true

                    readonly property int edge: PlasmaCore.Types.RightEdge

                    onClicked: {
                        if (page.viewConfig.isReady && plasmoid.location !== edge) {
                            page.latteView.positioner.setNextLocation("", page.latteView.screensGroup, "", edge, LatteCore.types.NoneAlignment);
                        }
                        checked = Qt.binding(function() { return plasmoid.location === edge })
                    }
                }
            }
        }
        //! END: Location

        //! BEGIN: Alignment
        ColumnLayout {
            Layout.fillWidth: true
            spacing: units.smallSpacing

            LatteComponents.Header {
                text: i18n("Alignment")
            }

            RowLayout {
                id: alignmentRow
                Layout.fillWidth: true
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2
                LayoutMirroring.enabled: false
                spacing: 2

                readonly property int currentAlignment: page.latteView && page.latteView.alignment !== LatteCore.types.NoneAlignment ? page.latteView.alignment : plasmoid.configuration.alignment
                readonly property int buttonSize: (page.dialog.optionsWidth - (spacing * 3)) / 4
                function applyAlignment(alignment) {
                    if (plasmoid.configuration.alignment !== alignment) {
                        plasmoid.configuration.alignment = alignment;
                    }

                    if (page.latteView && page.latteView.alignment !== alignment) {
                        page.latteView.alignment = alignment;
                    }

                    page.latteView.positioner.setNextLocation("", page.latteView.screensGroup, "", PlasmaCore.Types.Floating, alignment);
                }

                LatteComponents.Button {
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: panelIsVertical ? i18nc("top alignment", "Top") : i18nc("left alignment", "Left")
                    icon.name: panelIsVertical ? "format-align-vertical-top" : "format-justify-left"
                    checked: parent.currentAlignment === alignment
                    checkable: true

                    property int alignment: panelIsVertical ? LatteCore.types.Top : LatteCore.types.Left

                    onClicked: {
                        parent.applyAlignment(alignment)
                        checked = Qt.binding(function() { return parent.currentAlignment === alignment })
                    }
                }
                LatteComponents.Button {
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: i18nc("center alignment", "Center")
                    icon.name: panelIsVertical ? "format-align-vertical-center" : "format-justify-center"
                    checked: parent.currentAlignment === alignment
                    checkable: true

                    property int alignment: LatteCore.types.Center

                    onClicked: {
                        parent.applyAlignment(alignment)
                        checked = Qt.binding(function() { return parent.currentAlignment === alignment })
                    }
                }
                LatteComponents.Button {
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: panelIsVertical ? i18nc("bottom alignment", "Bottom") : i18nc("right alignment", "Right")
                    icon.name: panelIsVertical ? "format-align-vertical-bottom" : "format-justify-right"
                    checked: parent.currentAlignment === alignment
                    checkable: true

                    property int alignment: panelIsVertical ? LatteCore.types.Bottom : LatteCore.types.Right

                    onClicked: {
                        parent.applyAlignment(alignment)
                        checked = Qt.binding(function() { return parent.currentAlignment === alignment })
                    }
                }

                LatteComponents.Button {
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: i18nc("justify alignment", "Justify")
                    icon.name: "format-justify-fill"
                    checked: parent.currentAlignment === alignment
                    checkable: true

                    property int alignment: LatteCore.types.Justify

                    onClicked: {
                        parent.applyAlignment(alignment)
                        checked = Qt.binding(function() { return parent.currentAlignment === alignment })
                    }
                }
            }
        }
        //! END: Alignment

        //! BEGIN: Items Alignment
        ColumnLayout {
            Layout.fillWidth: true
            enabled: alignmentRow.currentAlignment === LatteCore.types.Justify
            opacity: enabled ? 1 : 0.45
            spacing: units.smallSpacing

            LatteComponents.Header {
                text: i18nc("dock items alignment", "Items alignment")
            }

            RowLayout {
                id: itemsAlignmentRow
                Layout.fillWidth: true
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2
                LayoutMirroring.enabled: false
                spacing: 2

                readonly property int currentItemsAlignment: normalizedItemsAlignment(plasmoid.configuration.itemsAlignment)
                readonly property int buttonSize: (page.dialog.optionsWidth - (spacing * 2)) / 3

                function normalizedItemsAlignment(alignment) {
                    if (alignment === LatteCore.types.Center) {
                        return alignment;
                    }

                    if (panelIsVertical) {
                        return alignment === LatteCore.types.Top || alignment === LatteCore.types.Bottom ? alignment : LatteCore.types.Center;
                    }

                    return alignment === LatteCore.types.Left || alignment === LatteCore.types.Right ? alignment : LatteCore.types.Center;
                }

                function applyItemsAlignment(alignment) {
                    if (plasmoid.configuration.itemsAlignment !== alignment) {
                        plasmoid.configuration.itemsAlignment = alignment;
                    }
                }

                LatteComponents.Button {
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: panelIsVertical ? i18nc("top items alignment", "Top") : i18nc("left items alignment", "Left")
                    icon.name: panelIsVertical ? "format-align-vertical-top" : "format-justify-left"
                    checked: parent.currentItemsAlignment === alignment
                    checkable: true

                    property int alignment: panelIsVertical ? LatteCore.types.Top : LatteCore.types.Left

                    onClicked: {
                        parent.applyItemsAlignment(alignment)
                        checked = Qt.binding(function() { return parent.currentItemsAlignment === alignment })
                    }
                }

                LatteComponents.Button {
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: i18nc("center items alignment", "Center")
                    icon.name: panelIsVertical ? "format-align-vertical-center" : "format-justify-center"
                    checked: parent.currentItemsAlignment === alignment
                    checkable: true

                    property int alignment: LatteCore.types.Center

                    onClicked: {
                        parent.applyItemsAlignment(alignment)
                        checked = Qt.binding(function() { return parent.currentItemsAlignment === alignment })
                    }
                }

                LatteComponents.Button {
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: panelIsVertical ? i18nc("bottom items alignment", "Bottom") : i18nc("right items alignment", "Right")
                    icon.name: panelIsVertical ? "format-align-vertical-bottom" : "format-justify-right"
                    checked: parent.currentItemsAlignment === alignment
                    checkable: true

                    property int alignment: panelIsVertical ? LatteCore.types.Bottom : LatteCore.types.Right

                    onClicked: {
                        parent.applyItemsAlignment(alignment)
                        checked = Qt.binding(function() { return parent.currentItemsAlignment === alignment })
                    }
                }
            }
        }
        //! END: Items Alignment

        //! BEGIN: Visibility
        ColumnLayout {
            Layout.fillWidth: true
            spacing: units.smallSpacing

            LatteComponents.Header {
                text: i18n("Visibility")
            }

            GridLayout {
                id: visibilityModeGrid
                Layout.fillWidth: true
                rowSpacing: 1
                columnSpacing: 2
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2

                columns: 2

                readonly property int selectedMode: page.latteView.visibility.mode
                readonly property int buttonSize: (page.dialog.optionsWidth - (columnSpacing)) / 2

                function applyMode(mode) {
                    if (page.latteView.visibility.mode !== mode) {
                        page.latteView.visibility.mode = mode;
                    }
                }

                LatteComponents.Button {
                    id:alwaysVisibleBtn
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: i18n("Always Visible")
                    checked: visibilityModeGrid.selectedMode === alwaysVisibleBtn.mode
                    checkable: true

                    property int mode: LatteCore.types.AlwaysVisible

                    onClicked: {
                        visibilityModeGrid.applyMode(alwaysVisibleBtn.mode)
                    }
                }
                LatteComponents.Button {
                    id: autoHideBtn
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: i18n("Auto Hide")
                    checked: visibilityModeGrid.selectedMode === autoHideBtn.mode
                    checkable: true

                    property int mode: LatteCore.types.AutoHide

                    onClicked: {
                        visibilityModeGrid.applyMode(autoHideBtn.mode)
                    }
                }
                LatteComponents.Button {
                    id: dodgeActiveBtn
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    text: i18n("Dodge Active")
                    checked: visibilityModeGrid.selectedMode === dodgeActiveBtn.mode
                    checkable: true

                    property int mode: LatteCore.types.DodgeActive

                    onClicked: {
                        visibilityModeGrid.applyMode(dodgeActiveBtn.mode)
                    }
                }

                LatteExtraControls.CustomVisibilityModeButton {
                    id: dodgeModeBtn
                    latteView: page.latteView
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    implicitWidth: alwaysVisibleBtn.implicitWidth
                    implicitHeight: alwaysVisibleBtn.implicitHeight

                    checked: containsActiveMode

                    mode: plasmoid.configuration.lastDodgeVisibilityMode
                    modes: [
                        {
                            pluginId: LatteCore.types.DodgeMaximized,
                            name: i18n("Dodge Maximized"),
                            tooltip: ""
                        },
                        {
                            pluginId: LatteCore.types.DodgeAllWindows,
                            name: i18n("Dodge All Windows"),
                            tooltip: ""
                        }
                    ]

                    onViewRelevantVisibilityModeChanged: plasmoid.configuration.lastDodgeVisibilityMode = page.latteView.visibility.mode;
                }

                LatteExtraControls.CustomVisibilityModeButton {
                    id: windowsModeBtn
                    latteView: page.latteView
                    Layout.minimumWidth: parent.buttonSize
                    Layout.maximumWidth: Layout.minimumWidth
                    implicitWidth: alwaysVisibleBtn.implicitWidth
                    implicitHeight: alwaysVisibleBtn.implicitHeight

                    checked: containsActiveMode

                    mode: plasmoid.configuration.lastWindowsVisibilityMode
                    modes: [
                        {
                            pluginId: LatteCore.types.WindowsGoBelow,
                            name: i18n("Windows Go Below"),
                            tooltip: ""
                        },
                        {
                            pluginId: LatteCore.types.WindowsCanCover,
                            name: i18n("Windows Can Cover"),
                            tooltip: ""
                        },
                        {
                            pluginId: LatteCore.types.WindowsAlwaysCover,
                            name: i18n("Windows Always Cover"),
                            tooltip: ""
                        }
                    ]

                    onViewRelevantVisibilityModeChanged: plasmoid.configuration.lastWindowsVisibilityMode = page.latteView.visibility.mode;
                }

            }
        }
        //! END: Visibility

        //! BEGIN: Delay
        ColumnLayout {
            Layout.fillWidth: true
            spacing: units.smallSpacing

            LatteComponents.Header {
                text: i18n("Delay")
            }

            Flow {
                Layout.minimumWidth: page.dialog.optionsWidth
                Layout.preferredWidth: page.dialog.optionsWidth
                Layout.maximumWidth: page.dialog.optionsWidth
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2
                Layout.topMargin: units.smallSpacing

                spacing: 2

                readonly property bool overlap: showContainer.overlap || hideContainer.overlap

                Item {
                    id: showContainer
                    width: parent.overlap ? page.dialog.optionsWidth : oneLineWidth
                    height: childrenRect.height
                    implicitWidth: width
                    implicitHeight: height

                    readonly property bool overlap: oneLineWidth > alwaysVisibleBtn.width
                    readonly property int oneLineWidth: Math.max(alwaysVisibleBtn.width, showTimerRow.width)

                    RowLayout{
                        id: showTimerRow
                        anchors.horizontalCenter: parent.horizontalCenter
                        PlasmaComponents.Label {
                            Layout.leftMargin: Qt.application.layoutDirection === Qt.RightToLeft ? units.smallSpacing : 0
                            Layout.rightMargin: Qt.application.layoutDirection === Qt.RightToLeft ? 0 : units.smallSpacing
                            text: i18n("Show ")
                        }

                        LatteComponents.TextField {
                            Layout.preferredWidth: implicitWidth
                            text: page.latteView.visibility.timerShow

                            onValueChanged: {
                                page.latteView.visibility.timerShow = value
                            }
                        }
                    }
                }

                Item {
                    id: hideContainer
                    width: parent.overlap ? page.dialog.optionsWidth : oneLineWidth
                    height: childrenRect.height
                    implicitWidth: width
                    implicitHeight: height

                    readonly property bool overlap: oneLineWidth > alwaysVisibleBtn.width
                    readonly property int oneLineWidth: Math.max(alwaysVisibleBtn.width, hideTimerRow.width)

                    RowLayout {
                        id: hideTimerRow
                        anchors.horizontalCenter: parent.horizontalCenter

                        PlasmaComponents.Label {
                            Layout.leftMargin: Qt.application.layoutDirection === Qt.RightToLeft ? units.smallSpacing : 0
                            Layout.rightMargin: Qt.application.layoutDirection === Qt.RightToLeft ? 0 : units.smallSpacing
                            text: i18n("Hide")
                        }

                        LatteComponents.TextField{
                            Layout.preferredWidth: implicitWidth
                            text: page.latteView.visibility.timerHide
                            maxValue: 5000

                            onValueChanged: {
                                page.latteView.visibility.timerHide = value
                            }
                        }
                    }
                }
            }
        }
        //! END: Delay

        //! BEGIN: Actions
        ColumnLayout {
            spacing: units.smallSpacing
            visible: page.dialog.advancedLevel

            LatteComponents.Header {
                text: i18n("Actions")
            }

            ColumnLayout {
                id: actionsPropertiesColumn
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2
                spacing: 0

                readonly property int maxLabelWidth: Math.max(trackActiveLbl.implicitWidth,
                                                              mouseWheelLbl.implicitWidth,
                                                              leftBtnLbl.implicitWidth,
                                                              midBtnLbl.implicitWidth)

                ColumnLayout {
                    RowLayout {
                        Layout.topMargin: units.smallSpacing

                        PlasmaComponents.Label {
                            id: trackActiveLbl
                            Layout.minimumWidth: actionsPropertiesColumn.maxLabelWidth
                            Layout.maximumWidth: actionsPropertiesColumn.maxLabelWidth
                            text: i18nc("track active window","Track")
                        }

                        LatteComponents.ComboBox {
                            id: activeWindowFilterCmb
                            Layout.fillWidth: true
                            model: [i18nc("track from current screen", "Active Window From Current Screen"),
                                i18nc("track from all screens", "Active Window From All Screens")]

                            currentIndex: plasmoid.configuration.activeWindowFilter

                            onCurrentIndexChanged: {
                                switch(currentIndex) {
                                case LatteContainment.types.ActiveInCurrentScreen:
                                    plasmoid.configuration.activeWindowFilter = LatteContainment.types.ActiveInCurrentScreen;
                                    break;
                                case LatteContainment.types.ActiveFromAllScreens:
                                    plasmoid.configuration.activeWindowFilter = LatteContainment.types.ActiveFromAllScreens;
                                    break;
                                }
                            }
                        }
                    }
                }

                ColumnLayout {
                    Layout.topMargin: units.smallSpacing
                    RowLayout {
                        PlasmaComponents.Label {
                            id: leftBtnLbl
                            Layout.minimumWidth: actionsPropertiesColumn.maxLabelWidth
                            Layout.maximumWidth: actionsPropertiesColumn.maxLabelWidth
                            text: i18n("Left Button")
                        }

                        LatteComponents.Button {
                            Layout.fillWidth: true
                            text: i18n("Drag Active Window")
                            tooltip: i18n("The user can use left mouse button to drag and maximized/restore last active window from empty areas")
                            checkable: true
                            icon.name: "transform-move"

                            readonly property int dragActiveWindowEnabled: plasmoid.configuration.dragActiveWindowEnabled

                            onDragActiveWindowEnabledChanged: checked = dragActiveWindowEnabled

                            onClicked: {
                                plasmoid.configuration.dragActiveWindowEnabled = checked;
                            }
                        }
                    }

                    RowLayout {
                        PlasmaComponents.Label {
                            id: midBtnLbl
                            Layout.minimumWidth: actionsPropertiesColumn.maxLabelWidth
                            Layout.maximumWidth: actionsPropertiesColumn.maxLabelWidth
                            text: i18n("Middle Button")
                        }

                        LatteComponents.Button {
                            Layout.fillWidth: true
                            text: i18n("Close Active Window")
                            tooltip: i18n("The user can use middle mouse button to close last active window from empty areas")
                            checkable: true
                            icon.name: "window-close"

                            readonly property int closeActiveWindowEnabled: plasmoid.configuration.closeActiveWindowEnabled

                            onCloseActiveWindowEnabledChanged: checked = closeActiveWindowEnabled;

                            onClicked: {
                                plasmoid.configuration.closeActiveWindowEnabled = checked;
                            }
                        }
                    }

                    RowLayout {
                       // Layout.topMargin: units.smallSpacing

                        PlasmaComponents.Label {
                            id: mouseWheelLbl
                            Layout.minimumWidth: actionsPropertiesColumn.maxLabelWidth
                            Layout.maximumWidth: actionsPropertiesColumn.maxLabelWidth
                            text: i18n("Mouse wheel")
                        }

                        LatteComponents.ComboBox {
                            id: scrollAction
                            Layout.fillWidth: true
                            model: [i18nc("none scroll actions", "No Action"),
                                i18n("Cycle Through Desktops"),
                                i18n("Cycle Through Activities"),
                                i18n("Cycle Through Tasks"),
                                i18n("Cycle And Minimize Tasks")]

                            currentIndex: plasmoid.configuration.scrollAction

                            onActivated: {
                                if (plasmoid.configuration.scrollAction !== currentIndex) {
                                    plasmoid.configuration.scrollAction = currentIndex;
                                }
                            }
                        }
                    }
                }

                LatteComponents.SubHeader {
                    text: i18n("Items")
                }

                LatteComponents.CheckBoxesColumn {
                    LatteComponents.CheckBox {
                        id: titleTooltipsChk
                        Layout.maximumWidth: page.dialog.optionsWidth
                        text: i18n("Thin title tooltips on hovering")
                        tooltip: i18n("Show narrow tooltips produced by Latte for items.\nThese tooltips are not drawn when applets zoom effect is disabled");
                        value: plasmoid.configuration.titleTooltips

                        onClicked: {
                            plasmoid.configuration.titleTooltips = !plasmoid.configuration.titleTooltips;
                        }
                    }

                    LatteComponents.CheckBox {
                        id: appletsZoomChk
                        Layout.maximumWidth: page.dialog.optionsWidth
                        text: i18n("Zoom widgets on hovering")
                        tooltip: i18n("Enlarge external widgets (applets) when hovering them. When disabled, widgets keep their original size so their icons stay sharp, while task icons and launchers still zoom")
                        value: plasmoid.configuration.appletsZoomEnabled

                        onClicked: {
                            plasmoid.configuration.appletsZoomEnabled = !plasmoid.configuration.appletsZoomEnabled;
                        }
                    }

                    LatteComponents.CheckBox {
                        id: mouseWheelChk
                        Layout.maximumWidth: page.dialog.optionsWidth
                        text: i18n("Expand popup through mouse wheel")
                        tooltip: i18n("Show or Hide applet popup through mouse wheel action")
                        value: plasmoid.configuration.mouseWheelActions
                        visible: page.dialog.advancedLevel

                        onClicked: {
                            plasmoid.configuration.mouseWheelActions = !plasmoid.configuration.mouseWheelActions;
                        }
                    }

                    LatteComponents.CheckBox {
                        id: autoSizeChk
                        Layout.maximumWidth: page.dialog.optionsWidth
                        text: i18n("Adjust size automatically when needed")
                        tooltip: i18n("Items decrease their size when exceed maximum length and increase it when they can fit in")
                        value: plasmoid.configuration.autoSizeEnabled
                        visible: page.dialog.advancedLevel

                        onClicked: {
                            plasmoid.configuration.autoSizeEnabled = !plasmoid.configuration.autoSizeEnabled;
                        }
                    }

                    LatteComponents.CheckBox {
                        Layout.maximumWidth: page.dialog.optionsWidth
                       // Layout.maximumHeight: mouseWheelChk.height
                        text: i18n("Activate based on position global shortcuts")
                        tooltip: i18n("This view is used for based on position global shortcuts. Take note that only one view can have that option enabled for each layout")
                        value: page.latteView.isPreferredForShortcuts || (!page.latteView.layout.preferredForShortcutsTouched && page.latteView.isHighestPriorityView())

                        onClicked: {
                            page.latteView.isPreferredForShortcuts = checked;
                            if (!page.latteView.layout.preferredForShortcutsTouched) {
                                page.latteView.layout.preferredForShortcutsTouched = true;
                            }
                        }
                    }
                }
            }

            LatteComponents.SubHeader {
                id: floatingSubCategory
                text: i18n("Floating")
            }

            LatteComponents.CheckBoxesColumn {
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2

                LatteComponents.CheckBoxesColumn {
                    LatteComponents.CheckBox {
                        Layout.maximumWidth: page.dialog.optionsWidth
                        text: i18n("Always use floating gap for user interaction")
                        tooltip: i18n("Floating gap is always used for applets and window interaction")
                        value: plasmoid.configuration.floatingInternalGapIsForced
                        enabled: plasmoid.configuration.zoomLevel === 0

                        onClicked: {
                            plasmoid.configuration.floatingInternalGapIsForced = !plasmoid.configuration.floatingInternalGapIsForced;
                        }
                    }

                    LatteComponents.CheckBox {
                        Layout.maximumWidth: page.dialog.optionsWidth
                        text: i18n("Hide floating gap for maximized windows")
                        tooltip: i18n("Floating gap is disabled when there are maximized windows")
                        value: plasmoid.configuration.hideFloatingGapForMaximized

                        onClicked: {
                            plasmoid.configuration.hideFloatingGapForMaximized = !plasmoid.configuration.hideFloatingGapForMaximized;
                        }
                    }

                    LatteComponents.CheckBox {
                        Layout.maximumWidth: page.dialog.optionsWidth
                        enabled: plasmoid.configuration.hideFloatingGapForMaximized
                        text: i18n("Delay floating gap hiding until mouse leaves")
                        tooltip: i18n("to avoid clicking on adjacent items accidentally in some cases")
                        value: plasmoid.configuration.floatingGapHidingWaitsMouse

                        onClicked: {
                            plasmoid.configuration.floatingGapHidingWaitsMouse = !plasmoid.configuration.floatingGapHidingWaitsMouse;
                        }
                    }

                    LatteComponents.CheckBox {
                        Layout.maximumWidth: page.dialog.optionsWidth
                        enabled: page.latteView.visibility.mode === LatteCore.types.AlwaysVisible
                        text: i18n("Mirror floating gap when it is shown")
                        tooltip: i18n("Floating gap is mirrored when it is shown in Always Visible mode")
                        value: plasmoid.configuration.floatingGapIsMirrored

                        onClicked: {
                            plasmoid.configuration.floatingGapIsMirrored = !plasmoid.configuration.floatingGapIsMirrored;
                        }
                    }
                }
            }
        }
        //! END: Actions

        //! BEGIN: Adjust
        ColumnLayout {
            spacing: units.smallSpacing

            visible: page.dialog.advancedLevel

            LatteComponents.Header {
                text: i18n("Environment")
            }

            LatteComponents.CheckBoxesColumn {
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2

                LatteComponents.CheckBox {
                    Layout.maximumWidth: page.dialog.optionsWidth
                    text: i18n("Raise on desktop change")
                    value: page.latteView.visibility.raiseOnDesktop

                    onClicked: {
                        page.latteView.visibility.raiseOnDesktop = !page.latteView.visibility.raiseOnDesktop;
                    }
                }
            }
        }
        //! END: Adjust

    }
}
