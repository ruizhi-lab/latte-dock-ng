/*
    SPDX-FileCopyrightText: 2016 Smith AR <audoban@openmailbox.org>
    SPDX-FileCopyrightText: 2016 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import QtQuick.Window

import org.kde.plasma.core as PlasmaCore

import org.kde.latte.core as LatteCore

Item{
    id: manager
    anchors.fill: parent

    property QtObject window

    property bool isFloatingInClientSide: screenEdgeMarginEnabled
                                          && !root.floatingInternalGapIsForced
                                          && !inSlidingIn
                                          && !inSlidingOut

    property int animationSpeed: LatteCore.WindowSystem.compositingActive ?
                                     (root.editMode ? 400 : animations.speedFactor.current * 1.62 * animations.duration.large) : 0

    property bool inClientSideScreenEdgeSliding: hideThickScreenGap
    property bool inNormalState: false  // computed imperatively below
    property bool inRelocationAnimation: latteView && latteView.positioner && latteView.positioner.inRelocationAnimation

    property bool inSlidingIn: false //necessary because of its init structure
    property alias inSlidingOut: slidingAnimationAutoHiddenOut.running
    property bool inRelocationHiding: false

    readonly property bool isSinkedEventEnabled: !(parabolic.isEnabled && (animations.needBothAxis.count>0 || animations.needLength.count>0))
                                                 && myView.isShownFully

    property int length: root.isVertical ?  Screen.height : Screen.width   //screenGeometry.height : screenGeometry.width

    property int slidingOutToPos: {
        var topOrLeftEdge = ((plasmoid.location===PlasmaCore.Types.LeftEdge)||(plasmoid.location===PlasmaCore.Types.TopEdge));
        return (topOrLeftEdge ? -metrics.mask.thickness.normal : metrics.mask.thickness.normal);
    }

    property Item layouts: null

    property bool updateIsEnabled: autosize.inCalculatedIconSize && !inSlidingIn && !inSlidingOut && !inRelocationHiding

    Connections{
        target: background.totals
        function onVisualLengthChanged() { updateMaskArea(); }
        function onVisualThicknessChanged() { updateMaskArea(); }
    }

    Connections{
        target: background.shadows
        function onHeadThicknessChanged() { updateMaskArea(); }
    }

    Connections{
        target: latteView ? latteView : null
        function onXChanged() { updateMaskArea(); }
        function onYChanged() { updateMaskArea() }
        function onWidthChanged() { updateMaskArea(); }
        function onHeightChanged() { updateMaskArea(); }
    }

    function recomputeInNormalState() {
        var wasNormal = inNormalState;
        // The view may outlive its visibility object briefly during teardown;
        // queued animation count changes must not dereference that cleared state.
        inNormalState = ((animations.needBothAxis.count === 0) && (animations.needLength.count === 0))
                     || (latteView && latteView.visibility && latteView.visibility.isHidden && !latteView.visibility.containsMouse && animations.needThickness.count === 0);
        if (inNormalState && !wasNormal) {
            updateMaskArea();
        }
    }

    Connections{
        target: animations.needBothAxis
        function onCountChanged() { recomputeInNormalState(); }
    }

    Connections{
        target: animations.needLength
        function onCountChanged() { recomputeInNormalState(); }
    }

    Connections{
        target: animations.needThickness
        function onCountChanged() { recomputeInNormalState(); }
    }

    Connections{
        target: layoutsManager
        function onCurrentLayoutIsSwitching(layoutName) {
            if (LatteCore.WindowSystem.compositingActive
                && latteView && latteView.layout
                && layoutName !== undefined
                && latteView.layout.name === layoutName) {
                parabolic.sglClearZoom();
            }
        }
    }

    Connections {
        target: metrics.mask.thickness
        function onMaxZoomedChanged() { updateMaskArea() }
    }

    Connections {
        target: root.myView
        function onInRelocationAnimationChanged() {
            if (!root.myView.inRelocationAnimation) {
                manager.updateMaskArea();
            }
        }
    }

    Connections {
        target: latteView ? latteView.effects : null
        function onRectChanged() { manager.updateMaskArea() }
    }

    Connections{
        target: themeExtended ? themeExtended : null
        function onThemeChanged() { latteView.effects.forceMaskRedraw(); }
    }

    Connections {
        target: LatteCore.WindowSystem
        function onCompositingActiveChanged() {
            manager.updateMaskArea();
        }
    }

    onIsFloatingInClientSideChanged: updateMaskArea();

    Component.onCompleted: recomputeInNormalState()

    onInSlidingInChanged: {
        if (latteView && !inSlidingIn && latteView.positioner.inRelocationShowing) {
            latteView.positioner.inRelocationShowing = false;
        }
    }

    onUpdateIsEnabledChanged: {
        if (updateIsEnabled) {
            updateMaskArea();
        }
    }

    function slotContainsMouseChanged() {
        if (!latteView || !latteView.visibility) {
            return;
        }

        if(latteView.visibility.containsMouse && latteView.visibility.mode !== LatteCore.types.SidebarOnDemand) {
            updateMaskArea();

            if (slidingAnimationAutoHiddenOut.running && !inRelocationHiding) {
                slotMustBeShown();
            }
        }
    }

    function slotMustBeShown() {
        if (root.inStartup) {
            slidingAnimationAutoHiddenIn.init();
            return;
        }

        var visibility = latteView ? latteView.visibility : null;
        if (!visibility) {
            return;
        }

        var positioner = latteView.positioner ? latteView.positioner : null;

        //! WindowsCanCover case
        if (visibility.mode === LatteCore.types.WindowsCanCover) {
            visibility.setViewOnFrontLayer();
        }

        if (positioner && !visibility.isHidden && positioner.inSlideAnimation) {
            // Do not update when Positioner mid-slide animation takes place, for example:
            // 1. Latte panel is hiding its floating gap for maximized window
            // 2. the user clicks on an applet popup.
            // 3. Applet popups showing/hiding are triggering hidingIsBlockedChanged() signals.
            // 4. hidingIsBlockedChanged() signals create mustBeShown events when visibility::hidingIsBlocked() is not enabled.
            return;
        }

        //! Normal Dodge/AutoHide case
        if (!slidingAnimationAutoHiddenIn.running
                && !inRelocationHiding
                && (visibility.isHidden || slidingAnimationAutoHiddenOut.running /*it is not already shown or is trying to hide*/)){
            slidingAnimationAutoHiddenIn.init();
        }
    }

    function slotMustBeHide() {
        if (root.inStartup) {
            slidingAnimationAutoHiddenOut.init();
            return;
        }

        var visibility = latteView ? latteView.visibility : null;
        if (!visibility) {
            return;
        }

        if (inSlidingIn && !inRelocationHiding) {
            /*consider hiding after sliding in has finished*/
            return;
        }

        if (visibility.mode === LatteCore.types.WindowsCanCover) {
            visibility.setViewOnBackLayer();
            return;
        }

        //! Normal Dodge/AutoHide case
        if (!slidingAnimationAutoHiddenOut.running
                && !visibility.blockHiding
                && (!visibility.containsMouse || visibility.mode === LatteCore.types.SidebarOnDemand /*for SidebarOnDemand mouse should be ignored on hiding*/)
                && (!visibility.isHidden || slidingAnimationAutoHiddenIn.running /*it is not already hidden or is trying to show*/)) {
            slidingAnimationAutoHiddenOut.init();
        }
    }

    //! functions used for sliding out/in during location/screen changes
    function slotHideDockDuringLocationChange() {
        inRelocationHiding = true;

        if(!slidingAnimationAutoHiddenOut.running) {
            slidingAnimationAutoHiddenOut.init();
        }
    }

    function slotShowDockAfterLocationChange() {
        slidingAnimationAutoHiddenIn.init();
    }

    function sendHideDockDuringLocationChangeFinished(){
        if (latteView && latteView.positioner) {
            latteView.positioner.hidingForRelocationFinished();
        }
    }

    function sendSlidingOutAnimationEnded() {
        if (!latteView || !latteView.visibility) {
            return;
        }

        latteView.visibility.hide();
        latteView.visibility.isHidden = true;

        if (debug.maskEnabled) {
            console.log("hiding animation ended...");
        }

        sendHideDockDuringLocationChangeFinished();
    }

    ///test maskArea
    function updateMaskArea() {
        if (!latteView || !root.viewIsAvailable) {
            return;
        }

        // debug maskArea criteria
        if (debug.maskEnabled) {
            console.log(animations.needBothAxis.count + ", " + animations.needLength.count + ", " +
                        animations.needThickness.count + ", " + latteView.visibility.isHidden);
        }

        //console.log("reached updating geometry ::: "+dock.maskArea);


        if (!latteView.visibility.isHidden && updateIsEnabled && inNormalState) {
            //! Important: Local Geometry must not be updated when view ISHIDDEN
            //! because it breaks Dodge(s) modes in such case

            var localGeometry = Qt.rect(0, 0, root.width, root.height);

            //the shadows size must be removed from the maskArea
            //before updating the localDockGeometry
            var cleanThickness = metrics.totals.thickness;
            var edgeMargin = metrics.mask.screenEdge;

            if (plasmoid.location === PlasmaCore.Types.TopEdge) {
                localGeometry.x = latteView.effects.rect.x; // from effects area
                localGeometry.width = latteView.effects.rect.width; // from effects area

                localGeometry.y = edgeMargin;
                localGeometry.height = cleanThickness;
            } else if (plasmoid.location === PlasmaCore.Types.BottomEdge) {
                localGeometry.x = latteView.effects.rect.x; // from effects area
                localGeometry.width = latteView.effects.rect.width; // from effects area

                localGeometry.y = root.height - cleanThickness - edgeMargin;
                localGeometry.height = cleanThickness;
            } else if (plasmoid.location === PlasmaCore.Types.LeftEdge) {
                localGeometry.y = latteView.effects.rect.y; // from effects area
                localGeometry.height = latteView.effects.rect.height; // from effects area

                localGeometry.x = edgeMargin;
                localGeometry.width = cleanThickness;
            } else if (plasmoid.location === PlasmaCore.Types.RightEdge) {
                localGeometry.y = latteView.effects.rect.y; // from effects area
                localGeometry.height = latteView.effects.rect.height; // from effects area

                localGeometry.x = root.width - cleanThickness - edgeMargin;
                localGeometry.width = cleanThickness;
            }

            //set the boundaries for latteView local geometry
            //qBound = qMax(min, qMin(value, max)).

            localGeometry.x = Math.max(0, Math.min(localGeometry.x, latteView.width));
            localGeometry.y = Math.max(0, Math.min(localGeometry.y, latteView.height));
            localGeometry.width = Math.min(localGeometry.width, latteView.width);
            localGeometry.height = Math.min(localGeometry.height, latteView.height);

            //console.log("update geometry ::: "+localGeometry);
            latteView.localGeometry = localGeometry;
        }

        //! Input Mask
        if (updateIsEnabled) {
            updateInputGeometry();
        }
    }

    function updateInputGeometry() {
        if (!latteView || !latteView.effects || !latteView.visibility) {
            return;
        }

        // VisibilityManager.qml tries to workaround faulty onEntered() signals from ParabolicMouseArea
        // by specifying inputThickness when ParabolicEffect is applied. (inputThickness->animated scenario)
        var animated = (animations.needBothAxis.count>0);

        if (!LatteCore.WindowSystem.compositingActive) {
            //! clear input mask
            latteView.effects.inputMask = Qt.rect(0, 0, -1, -1);
        } else {
            var inputThickness;

            if (latteView.visibility.isHidden) {
                inputThickness = metrics.mask.thickness.hidden;
            } else if (root.hasFloatingGapInputEventsDisabled) {
                inputThickness = animated ? metrics.mask.thickness.zoomedForItems - metrics.margins.screenEdge : metrics.totals.thickness;
            } else {
                inputThickness = animated ? metrics.mask.thickness.zoomedForItems : metrics.mask.screenEdge + metrics.totals.thickness;
            }

            var subtractedScreenEdge = root.hasFloatingGapInputEventsDisabled && !latteView.visibility.isHidden ? metrics.mask.screenEdge : 0;

            var inputGeometry = Qt.rect(0, 0, root.width, root.height);

            //!use view.localGeometry for length properties
            if (plasmoid.location === PlasmaCore.Types.TopEdge) {
                if (!animated) {
                    inputGeometry.x = latteView.localGeometry.x;
                    inputGeometry.width = latteView.localGeometry.width;
                }

                inputGeometry.y = subtractedScreenEdge;
                inputGeometry.height = inputThickness;
            } else if (plasmoid.location === PlasmaCore.Types.BottomEdge) {
                if (!animated) {
                    inputGeometry.x = latteView.localGeometry.x;
                    inputGeometry.width = latteView.localGeometry.width;
                }

                inputGeometry.y = root.height - inputThickness - subtractedScreenEdge;
                inputGeometry.height = inputThickness;
            } else if (plasmoid.location === PlasmaCore.Types.LeftEdge) {
                if (!animated) {
                    inputGeometry.y = latteView.localGeometry.y;
                    inputGeometry.height = latteView.localGeometry.height;
                }

                inputGeometry.x = subtractedScreenEdge;
                inputGeometry.width = inputThickness;
            } else if (plasmoid.location === PlasmaCore.Types.RightEdge) {
                if (!animated) {
                    inputGeometry.y = latteView.localGeometry.y;
                    inputGeometry.height = latteView.localGeometry.height;
                }

                inputGeometry.x = root.width - inputThickness - subtractedScreenEdge;
                inputGeometry.width = inputThickness;
            }

            //set the boundaries for latteView local geometry
            //qBound = qMax(min, qMin(value, max)).

            inputGeometry.x = Math.max(0, Math.min(inputGeometry.x, latteView.width));
            inputGeometry.y = Math.max(0, Math.min(inputGeometry.y, latteView.height));
            inputGeometry.width = Math.min(inputGeometry.width, latteView.width);
            inputGeometry.height = Math.min(inputGeometry.height, latteView.height);

            if (latteView.visibility.isSidebar && latteView.visibility.isHidden) {
                //! this way we make sure than no input is accepted anywhere
                inputGeometry = Qt.rect(-1, -1, 1, 1);
            }

            latteView.effects.inputMask = inputGeometry;
        }
    }

    Loader{
        anchors.fill: parent
        active: debug.graphicsEnabled

        sourceComponent: Item{
            anchors.fill:parent

            Rectangle{
                id: windowBackground
                anchors.fill: parent
                border.color: "red"
                border.width: 1
                color: "transparent"
            }

            Rectangle{
                x: latteView ? latteView.effects.mask.x : -1
                y: latteView ? latteView.effects.mask.y : -1
                height: latteView ? latteView.effects.mask.height : 0
                width: latteView ? latteView.effects.mask.width : 0

                border.color: "green"
                border.width: 1
                color: "transparent"
            }
        }
    }

    /***Hiding/Showing Animations*****/

    //////////////// Animations - Slide In - Out
    SequentialAnimation{
        id: slidingAnimationAutoHiddenOut

        PropertyAnimation {
            target: layoutsContainer
            property: root.isVertical ? "x" : "y"
            to: {
                if (LatteCore.WindowSystem.compositingActive) {
                    return manager.slidingOutToPos;
                } else {
                    if ((plasmoid.location===PlasmaCore.Types.LeftEdge)||(plasmoid.location===PlasmaCore.Types.TopEdge)) {
                        return manager.slidingOutToPos + 1;
                    } else {
                        return manager.slidingOutToPos - 1;
                    }
                }
            }
            duration: manager.animationSpeed
            easing.type: Easing.InQuad
        }

        ScriptAction{
            script: {
                if (!latteView || !latteView.visibility) {
                    return;
                }

                latteView.visibility.isHidden = true;
            }
        }

        onStarted: {
            if (debug.maskEnabled) {
                console.log("hiding animation started...");
            }
        }

        onStopped: {
            //! Trying to move the ending part of the signals at the end of editing animation
            if (!manager.inRelocationHiding) {
                manager.updateMaskArea();
            } else {
                if (!root.editMode) {
                    manager.sendSlidingOutAnimationEnded();
                }
            }

            if (latteView && latteView.visibility) {
                latteView.visibility.slideOutFinished();
            }
            manager.updateInputGeometry();

            if (root.inStartup) {
                //! when view is first created slide-outs when that animation ends then
                //! it flags that startup has ended and first slide-in can be started
                //! this is important because if it is removed then some views
                //! wont slide-in after startup.
                root.inStartup = false;
            }
        }

        function init() {
            if (manager.inRelocationAnimation || root.inStartup/*used from recreating views*/ || !latteView.visibility.blockHiding) {
                start();
            }
        }
    }

    SequentialAnimation{
        id: slidingAnimationAutoHiddenIn

        PauseAnimation{
            duration: manager.inRelocationHiding && slidingAnimationAutoHiddenIn.animations.active ? 500 : 0
        }

        PropertyAnimation {
            target: layoutsContainer
            property: root.isVertical ? "x" : "y"
            to: 0
            duration: manager.animationSpeed
            easing.type: Easing.OutQuad
        }

        onStarted: {
            latteView.visibility.show();
            manager.updateInputGeometry();

            if (debug.maskEnabled) {
                console.log("showing animation started...");
            }
        }

        onStopped: {
            manager.inSlidingIn = false;

            manager.inRelocationHiding = false;
            autosize.updateIconSize();

            if (debug.maskEnabled) {
                console.log("showing animation ended...");
            }

            latteView.visibility.slideInFinished();

            //! this is needed in order to update dock absolute geometry correctly in the end AND
            //! when a floating dock is sliding-in through masking techniques
            updateMaskArea();
        }

        function init() {
            if (!root.viewIsAvailable) {
                return;
            }

            manager.inSlidingIn = true;

            if (slidingAnimationAutoHiddenOut.running) {
                slidingAnimationAutoHiddenOut.stop();
            }

            latteView.visibility.isHidden = false;
            updateMaskArea();

            start();
        }
    }

}
