/*
    SPDX-FileCopyrightText: 2016 Smith AR <audoban@openmailbox.org>
    SPDX-FileCopyrightText: 2016 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import QtQuick.Layouts

import QtQuick.Effects

import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents
import org.kde.plasma.core as PlasmaCore
import org.kde.ksvg as KSvg
import org.kde.plasma.plasmoid
import org.kde.plasma.private.mpris as Mpris

import org.kde.taskmanager as TaskManager
import org.kde.latte.compat.taskmanager as TaskManagerApplet

import org.kde.latte.core as LatteCore
import org.kde.latte.components as LatteComponents

import org.kde.latte.private.tasks as LatteTasks

import "task" as Task
import "taskslayout" as TasksLayout
import "../code/tools.js" as TaskTools
import "../code/activitiesTools.js" as ActivitiesTools
import "../code/ColorizerTools.js" as ColorizerTools

PlasmoidItem {
    id:root
    readonly property var containmentRootReference: root

    // Match the containment-level Kirigami override so audio badges
    // and other symbolic icons use the same Window color set on
    // every dock (original and clone) regardless of per-window palette.
    Kirigami.Theme.inherit: false
    Kirigami.Theme.colorSet: Kirigami.Theme.Window

    readonly property var theme: Kirigami.Theme
    readonly property var units: Kirigami.Units
    readonly property bool supportsLaunchers: true

    Layout.fillWidth: scrollingEnabled && !root.vertical
    Layout.fillHeight: scrollingEnabled && root.vertical

    Layout.minimumWidth: root.isHorizontal ? minimumLength : -1
    Layout.minimumHeight: root.isHorizontal ? -1 : minimumLength
    Layout.preferredWidth: root.isHorizontal ? taskLayoutLengthHint : taskLayoutThicknessHint
    Layout.preferredHeight: root.isHorizontal ? taskLayoutThicknessHint : taskLayoutLengthHint
    Layout.maximumWidth: -1
    Layout.maximumHeight: -1

    LayoutMirroring.enabled: Qt.application.layoutDirection === Qt.RightToLeft && !root.vertical
    LayoutMirroring.childrenInherit: true

    property bool disableRestoreZoom: false //blocks restore animation in rightClick
    property bool disableAllWindowsFunctionality: plasmoid.configuration.hideAllTasks
    property bool inActivityChange: false
    property bool inDraggingPhase: false
    property bool initializationStep: false //true
    property bool isHovered: false
    property bool showBarLine: plasmoid.configuration.showBarLine
    property bool useThemePanel: plasmoid.configuration.useThemePanel
    property bool taskInAnimation: noTasksInAnimation > 0 ? true : false
    property bool transparentPanel: plasmoid.configuration.transparentPanel
    // Derive task orientation primarily from edge location so relocation does not
    // transiently collapse task geometry when formFactor lags behind.
    property bool vertical: (root.location === PlasmaCore.Types.LeftEdge
                             || root.location === PlasmaCore.Types.RightEdge)
    property bool isHorizontal: !vertical

    property bool hasTaskDemandingAttention: false

    property int clearWidth
    property int clearHeight

    property int newDroppedPosition: -1
    property int noTasksInAnimation: 0
    property int themePanelSize: plasmoid.configuration.panelSize

    property int location : {
        if (plasmoid.location === PlasmaCore.Types.LeftEdge
                || plasmoid.location === PlasmaCore.Types.RightEdge
                || plasmoid.location === PlasmaCore.Types.TopEdge) {
            return plasmoid.location;
        }

        return PlasmaCore.Types.BottomEdge;
    }

    ///Don't use Math.floor it adds one pixel in animations and creates glitches
    property int widthMargins: root.vertical ? appletAbilities.metrics.totals.thicknessEdges : appletAbilities.metrics.totals.lengthEdges
    property int heightMargins: !root.vertical ? appletAbilities.metrics.totals.thicknessEdges : appletAbilities.metrics.totals.lengthEdges

    property int internalWidthMargins: root.vertical ? appletAbilities.metrics.totals.thicknessEdges : appletAbilities.metrics.totals.lengthPaddings
    property int internalHeightMargins: !root.vertical ? appletAbilities.metrics.totals.thicknessEdges : appletAbilities.metrics.totals.lengthPaddings

    readonly property int minimumLength: Math.round(taskLayoutLengthHint)

    property real textColorBrightness: ColorizerTools.colorBrightness(themeTextColor)

    property color themeTextColor: theme.textColor
    property color themeBackgroundColor: theme.backgroundColor

    property color lightTextColor: textColorBrightness > 127.5 ? themeTextColor : themeBackgroundColor

    //a small badgers record (id,value)
    //in order to track badgers when there are changes
    //in launcher reference from libtaskmanager
    property var badgers:[]
    property var launchersOnActivities: []

    //global plasmoid reference to the context menu
    property QtObject contextMenu: null
    property QtObject contextMenuComponent: Qt.createComponent("ContextMenu.qml", Component.PreferSynchronous);
    property Item dragSource: null

    property Item tasksExtendedManager: _tasksExtendedManager
    readonly property alias appletAbilities: _appletAbilities

    readonly property alias containsDrag: mouseHandler.containsDrag
    property string pendingTaskLayoutRefreshReason: ""
    property int pendingTaskLayoutRefreshPass: 0

    //! Animations
    readonly property bool launcherBouncingEnabled: appletAbilities.animations.active && plasmoid.configuration.animationLauncherBouncing
    readonly property bool newWindowSlidingEnabled: appletAbilities.animations.active && plasmoid.configuration.animationNewWindowSliding
    readonly property bool windowInAttentionEnabled: appletAbilities.animations.active && plasmoid.configuration.animationWindowInAttention
    readonly property bool windowAddedInGroupEnabled: appletAbilities.animations.active && plasmoid.configuration.animationWindowAddedInGroup
    readonly property bool windowRemovedFromGroupEnabled: appletAbilities.animations.active && plasmoid.configuration.animationWindowRemovedFromGroup

    readonly property bool hasHighThicknessAnimation: launcherBouncingEnabled || windowInAttentionEnabled || windowAddedInGroupEnabled

    //BEGIN properties
    property bool groupTasksByDefault: plasmoid.configuration.groupTasksByDefault
    property bool highlightWindows: hoverAction === LatteTasks.types.HighlightWindows || hoverAction === LatteTasks.types.PreviewAndHighlightWindows

    property bool scrollingEnabled: plasmoid.configuration.scrollTasksEnabled
    property bool autoScrollTasksEnabled: scrollingEnabled && plasmoid.configuration.autoScrollTasksEnabled
    property bool manualScrollTasksEnabled: scrollingEnabled &&  manualScrollTasksType !== LatteTasks.types.ManualScrollDisabled
    property int manualScrollTasksType: plasmoid.configuration.manualScrollTasksType

    property bool showInfoBadge: plasmoid.configuration.showInfoBadge
    property bool showProgressBadge: plasmoid.configuration.showProgressBadge
    property bool showAudioBadge: plasmoid.configuration.showAudioBadge
    property bool infoBadgeProminentColorEnabled: plasmoid.configuration.infoBadgeProminentColorEnabled
    property bool audioBadgeActionsEnabled: plasmoid.configuration.audioBadgeActionsEnabled
    property bool showOnlyCurrentScreen: plasmoid.configuration.showOnlyCurrentScreen
    property bool showOnlyCurrentDesktop: plasmoid.configuration.showOnlyCurrentDesktop
    property bool showOnlyCurrentActivity: plasmoid.configuration.showOnlyCurrentActivity
    // Activity id used only for filter enablement.
    // Keep this empty when runtime activities are unavailable to avoid
    // accidental over-filtering to a stale persisted activity id.
    property string tasksModelActivityId: {
        if (!root.showOnlyCurrentActivity) {
            return "";
        }

        // When KActivities is not available, ActivityInfo cannot provide a valid
        // runtime activity id. In that case filtering by a stale persisted id can
        // hide all runtime windows, so disable activity filtering.
        if (activityInfo.numberOfRunningActivities <= 0) {
            return "";
        }

        const currentActivityId = activityInfo.currentActivity;

        if (root.isFilterableActivityId(currentActivityId)) {
            return String(currentActivityId);
        }

        return "";
    }
    property bool shouldFilterByActivity: root.showOnlyCurrentActivity && root.tasksModelActivityId.length > 0
    // Keep the preview scene unloaded while Wayland popup sizing and capture
    // responsiveness are unverified. The saved hover choice alone must not
    // reactivate the experimental path; title tooltips and highlighting remain
    // independent. Re-enable only after a runtime responsiveness retest.
    readonly property bool showPreviews: false
    readonly property alias isolatedPreview: isolatedPreviewProcess
    // TaskItem is a local delegate component rather than a named type in this
    // root. Keep the selected delegate dynamic so its preview methods and
    // removal state remain accessible; its teardown handlers clear this
    // reference before a stale frame callback can reach a destroyed object.
    property var isolatedPreviewTask: null
    readonly property bool isolatedPreviewsEnabled: isolatedPreview.enabled
        && (hoverAction === LatteTasks.types.PreviewWindows || hoverAction === LatteTasks.types.PreviewAndHighlightWindows)

    LatteTasks.PreviewProcess {
        id: isolatedPreviewProcess
        onActivateRequested: (uuid) => {
            if (root.isolatedPreviewTask) {
                root.isolatedPreviewTask.activatePreviewUuid(uuid);
            }
            root.isolatedPreviewTask = null;
        }
        onCloseRequested: (uuid) => {
            if (root.isolatedPreviewTask) {
                root.isolatedPreviewTask.closePreviewUuid(uuid);
            }
        }
    }

    // Only metadata crosses the process boundary. The legacy preview Loader
    // stays inactive even when the isolated experimental helper is enabled.
    Timer {
        id: isolatedPreviewPoll
        interval: 100
        repeat: true
        running: root.isolatedPreviewTask !== null
        property int outsideTicks: 0
        onRunningChanged: outsideTicks = 0
        onTriggered: {
            var task = root.isolatedPreviewTask;
            if (!root.isolatedPreviewsEnabled || root.contextMenu || root.inEditMode
                    || !task || !task.visible || task.isLauncher || task.inRemoveStage) {
                // Clearing the task triggers the hide in
                // onIsolatedPreviewTaskChanged; do not hide twice.
                root.isolatedPreviewTask = null;
                return;
            }
            outsideTicks = (task.visualContainsMouse || isolatedPreview.hovered) ? 0 : outsideTicks + 1;
            if (outsideTicks >= 4) {
                root.isolatedPreviewTask = null;
                isolatedPreview.hide();
                return;
            }
            task.updateIsolatedPreview();
        }
    }
    onIsolatedPreviewTaskChanged: {
        // Only an empty selection tears the surface down. Switching to another
        // task is handled by an in-place show() update so the preview follows
        // the pointer without a hide/show flicker.
        if (!isolatedPreviewTask) {
            isolatedPreview.hide();
        }
    }
    // Reposition the visible preview on every rendered frame so it stays glued
    // to the icon during the parabolic zoom animation, like the thin tooltip.
    // The 100 ms poll above only refreshes the window list; geometry travels as
    // a lightweight move message here.
    FrameAnimation {
        running: root.isolatedPreviewTask !== null
        onTriggered: {
            var task = root.isolatedPreviewTask;
            if (!root.isolatedPreviewsEnabled || !task || task.inRemoveStage) {
                root.isolatedPreviewTask = null;
                return;
            }
            task.moveIsolatedPreview();
        }
    }
    // The preview delegate pulls in thumbnail and MPRIS components.  Keep it
    // out of the task scene until previews are actually enabled.
    property var toolTipDelegate: toolTipDelegateLoader.item
    property bool showWindowActions: plasmoid.configuration.showWindowActions && !disableAllWindowsFunctionality
    property bool showWindowsOnlyFromLaunchers: plasmoid.configuration.showWindowsOnlyFromLaunchers && !disableAllWindowsFunctionality

    property alias windowPreviewIsShown: windowsPreviewDlg.visible

    property int leftClickAction: plasmoid.configuration.leftClickAction
    property int middleClickAction: plasmoid.configuration.middleClickAction
    property int hoverAction: plasmoid.configuration.hoverAction
    property int modifier: plasmoid.configuration.modifier
    property int modifierClickAction: plasmoid.configuration.modifierClickAction
    property int modifierClick: plasmoid.configuration.modifierClick
    property int modifierQt:{
        if (modifier === LatteTasks.types.Shift)
            return Qt.ShiftModifier;
        else if (modifier === LatteTasks.types.Ctrl)
            return Qt.ControlModifier;
        else if (modifier === LatteTasks.types.Alt)
            return Qt.AltModifier;
        else if (modifier === LatteTasks.types.Meta)
            return Qt.MetaModifier;
        else return -1;
    }
    property int taskScrollAction: plasmoid.configuration.taskScrollAction

    onTaskScrollActionChanged: {
        if (taskScrollAction > LatteTasks.types.ScrollToggleMinimized) {
            //! migrating scroll action to LatteTasks.types.ScrollAction
            plasmoid.configuration.taskScrollAction = plasmoid.configuration.taskScrollAction-LatteTasks.types.ScrollToggleMinimized;
        }
    }

    //! Real properties are need in order for parabolic effect to be 1px precise perfect.
    //! This way moving from Tasks to Applets and vice versa is pretty stable when hovering with parabolic effect.
    readonly property real taskLayoutLengthHint: {
        var contentLength = root.vertical ? icList.contentHeight : icList.contentWidth;

        if (!(contentLength > 0)) {
            contentLength = root.vertical ? icList.height : icList.width;
        }

        if (!(contentLength > 0)) {
            contentLength = root.vertical ? mouseHandler.height : mouseHandler.width;
        }

        return Math.max(appletAbilities.metrics.iconSize, contentLength);
    }

    readonly property real taskLayoutThicknessHint: {
        var thickness = appletAbilities.metrics.mask.thickness.normal;

        if (!(thickness > 0)) {
            thickness = appletAbilities.metrics.totals.thickness;
        }

        return Math.max(appletAbilities.metrics.iconSize, thickness);
    }

    property real tasksHeight: root.isHorizontal ? taskLayoutThicknessHint : taskLayoutLengthHint
    property real tasksWidth: root.isHorizontal ? taskLayoutLengthHint : taskLayoutThicknessHint
    property real tasksLength: taskLayoutLengthHint

    readonly property int alignment: appletAbilities.containment.alignment

    property alias tasksCount: tasksModel.count

    //END Latte Dock Panel properties

    // The containment writes this property from its editMode handler. Its QML
    // change notification feeds the authoritative edit-mode binding below;
    // the containment keeps its own compatibility poll for Plasma's source state.
    property bool containmentEditing: false

    readonly property bool inEditMode: latteInEditMode || plasmoid.userConfiguring || containmentEditing

    //BEGIN Latte Dock Communicator
    property QtObject latteBridge: null

    // Bridge attachment can be transient during startup in Qt6. When this plasmoid
    // is persisted as part of a Latte layout, isInLatteDock keeps behavior stable.
    readonly property bool inLatteDockEnvironment: (latteBridge !== null) || plasmoid.configuration.isInLatteDock
    readonly property bool inPlasma: !inLatteDockEnvironment
    readonly property bool inPlasmaDesktop: inPlasma && !inPlasmaPanel
    readonly property bool inPlasmaPanel: inPlasma && (plasmoid.location === PlasmaCore.Types.LeftEdge
                                                       || plasmoid.location === PlasmaCore.Types.RightEdge
                                                       || plasmoid.location === PlasmaCore.Types.BottomEdge
                                                       || plasmoid.location === PlasmaCore.Types.TopEdge)
    readonly property bool latteInEditMode: latteBridge && latteBridge.inEditMode
    //END  Latte Dock Communicator

    preferredRepresentation: fullRepresentation
    Plasmoid.backgroundHints: inPlasmaDesktop ? PlasmaCore.Types.StandardBackground : PlasmaCore.Types.NoBackground

    signal draggingFinished();
    signal hiddenTasksUpdated();
    signal activateWindowView(variant winIds);
    signal requestLayout;
    signal signalPreviewsShown();
    //signal signalDraggingState(bool value);
    signal showPreviewForTasks(QtObject group);
    //trigger updating scaling of neighbour delegates of zoomed delegate
    signal updateScale(int delegateIndex, real newScale, real step)
    signal publishTasksGeometries();
    signal windowsHovered(variant winIds, bool hovered)

    function cancelHighlightWindows() {
        windowEffectsBackend.cancelHighlightWindows();
    }

    onWindowsHovered: function(winIds, hovered) {
        windowEffectsBackend.setHighlightedWindows(winIds, hovered);
    }


    onScrollingEnabledChanged: {
        updateListViewParent();
    }

    Connections {
        target: root.plasmoid
        function onLocationChanged() {
            iconGeometryTimer.start();
            refreshTaskLayoutAfterEdgeChange("locationChanged");
        }

        function onFormFactorChanged() {
            iconGeometryTimer.start();
            refreshTaskLayoutAfterEdgeChange("formFactorChanged");
        }
    }

    Connections {
        target: root.plasmoid.configuration

        // onLaunchersChanged: tasksModel.launcherList = plasmoid.configuration.launchers
        function onGroupingAppIdBlacklistChanged() { tasksModel.groupingAppIdBlacklist = root.plasmoid.configuration.groupingAppIdBlacklist; }
        function onGroupingLauncherUrlBlacklistChanged() { tasksModel.groupingLauncherUrlBlacklist = root.plasmoid.configuration.groupingLauncherUrlBlacklist; }
    }


    Connections {
        target: root.appletAbilities.myView
        function onIsHiddenChanged() {
            if (root.appletAbilities.myView.isHidden) {
                windowsPreviewDlg.hide("3.3");
            }
        }

        function onIsReadyChanged() {
            if (root.appletAbilities.myView.isReady) {
                // Plasma 6 dropped JS plasmoid.action(); use internalAction()
                // and tolerate older builds that may not expose it yet.
                var configureAction = null;
                if (typeof Plasmoid !== "undefined" && Plasmoid) {
                    if (typeof Plasmoid.internalAction === "function") {
                        configureAction = Plasmoid.internalAction("configure");
                    } else if (typeof Plasmoid.action === "function") {
                        configureAction = Plasmoid.action("configure");
                    }
                }
                if (configureAction) {
                    configureAction.visible = false;
                }
                root.plasmoid.configuration.isInLatteDock = true;
            }
        }
    }

    Binding {
        target: root.plasmoid
        property: "status"
        value: {
            var hastaskinattention = root.hasTaskDemandingAttention && tasksModel.anyTaskDemandsAttentionInValidTime;
            return (hastaskinattention || root.dragSource) ? PlasmaCore.Types.NeedsAttentionStatus : PlasmaCore.Types.PassiveStatus;
        }
    }

    Binding {
        target: root
        property: "hasTaskDemandingAttention"
        when: root.appletAbilities.indexer.isReady
        value: {
            for (var i=0; i<root.appletAbilities.indexer.layout.children.length; ++i){
                var item = root.appletAbilities.indexer.layout.children[i];
                if (item && item.isDemandingAttention) {
                    return true;
                }
            }

            return false;
        }
    }

    ///UPDATE
    function updateListViewParent() {
        if (scrollingEnabled) {
            icList.parent = listViewBase;
        } else {
            icList.parent = barLine;
        }
    }

    function launcherExists(url) {
        return (ActivitiesTools.getIndex(url, tasksModel.launcherList)>=0);
    }

    function taskExists(url) {
        var tasks = icList.contentItem.children;
        for(var i=0; i<tasks.length; ++i){
            var task = tasks[i];

            if (task.launcherUrl===url && task.isWindow) {
                return true;
            }
        }
        return false;
    }

    function isFilterableActivityId(activityId) {
        if (activityId === undefined || activityId === null) {
            return false;
        }

        const normalizedId = String(activityId);

        if (normalizedId.length === 0) {
            return false;
        }

        return normalizedId !== "{0}"
                && normalizedId !== "{free-activities}"
                && normalizedId !== "{current-activity}"
                && normalizedId !== "00000000-0000-0000-0000-000000000000";
    }


    function forcePreviewsHiding(debug) {
        // console.log(" org.kde.latte   Tasks: Force hide previews event called: "+debug);
        windowsPreviewDlg.activeItem = null;
        windowsPreviewDlg.visible = false;
    }

    function hidePreview(){
        windowsPreviewDlg.hide(11);
    }

    onDragSourceChanged: {
        if (dragSource == null) {
            root.draggingFinished();
            tasksModel.syncLaunchers();

            // Force indexer bindings to re-evaluate after being frozen
            // (updateIsBlocked=true) during drag.  The QML engine may not
            // detect property changes that happened inside loop bodies while
            // the binding was deactivated.
            _appletAbilities.indexer.reorderToken++;

            restoreDraggingPhaseTimer.start();
        } else {
            inDraggingPhase = true;
        }
    }

    /////Window previews///////////

    Loader {
        id: toolTipDelegateLoader
        active: root.showPreviews
        source: "previews/ToolTipDelegate2.qml"
    }

    ////BEGIN interfaces

    LatteCore.Dialog{
        id: windowsPreviewDlg
        type: root.plasmoid.configuration.previewWindowAsPopup ? PlasmaCore.Dialog.PopupMenu : PlasmaCore.Dialog.Tooltip
        flags: root.plasmoid.configuration.previewWindowAsPopup ? Qt.WindowStaysOnTopHint | Qt.WindowDoesNotAcceptFocus | Qt.Popup :
                                                             Qt.WindowStaysOnTopHint | Qt.WindowDoesNotAcceptFocus | Qt.ToolTip
        location: root.location
        edge: root.location
        mainItem: root.toolTipDelegate
        visible: false

        property bool signalSent: false
        property Item activeItem: null

        Component.onCompleted: {
            if (mainItem) {
                mainItem.visible = true;
            }
        }

        onContainsMouseChanged: {
            //! Orchestrate restore zoom and previews window hiding. Both should be
            //! triggered together.
            if (containsMouse) {
                hidePreviewWinTimer.stop();
                root.appletAbilities.parabolic.setDirectRenderingEnabled(false);
            } else {
                hide(7.3);
            }
        }

        function hide(debug){
            //console.log("   Tasks: hide previews event called: "+debug);
            if (containsMouse || !root.visible) {
                return;
            }

            if (root.appletAbilities.myView.isReady && signalSent) {
                //it is used to unblock dock hiding
                signalSent = false;
            }

            if (!root.contextMenu) {
                root.disableRestoreZoom = false;
            }

            hidePreviewWinTimer.start();
        }

        function show(taskItem){
            if (root.disableAllWindowsFunctionality) {
                return;
            }

            if (!root.toolTipDelegate) {
                return;
            }

            hidePreviewWinTimer.stop();

            // console.log("preview show called...");
            if ((!activeItem || (activeItem !== taskItem)) && !root.contextMenu) {
                //console.log("preview show called: accepted...");

                //this can be used from others to hide their appearance
                //e.g but applets from the dock to hide themselves
                if (!root.visible) {
                    root.signalPreviewsShown();
                }

                activeItem = taskItem;
                root.toolTipDelegate.parentTask = taskItem;

                if (root.appletAbilities.myView.isReady && !signalSent) {
                    //it is used to block dock hiding
                    signalSent = true;
                }

                //! Workaround in order to update properly the previews thumbnails
                //! when switching between single thumbnail to another single thumbnail
                //! maybe is not needed any more, let's disable it
                //mainItem.visible = false;
                root.visible = true;
                //mainItem.visible = true;
            }
        }
    }

    //! Delay windows previews hiding
    Timer {
        id: hidePreviewWinTimer
        interval: 300
        onTriggered: {
            //! Orchestrate restore zoom and previews window hiding. Both should be
            //! triggered together.
            var contains = (windowsPreviewDlg.containsMouse
                            || (windowsPreviewDlg.activeItem && windowsPreviewDlg.activeItem.containsMouse) /*main task*/
                            || (windowsPreviewDlg.activeItem /*dragging file(s) from outside*/
                                && mouseHandler.hoveredItem
                                && !root.dragSource
                                && mouseHandler.hoveredItem === windowsPreviewDlg.activeItem));

            if (!contains) {
                root.forcePreviewsHiding(9.9);
            }
        }
    }

    //! Timer to fix #811, rare cases that both a window preview and context menu are
    //! shown. It is mostly used under wayland in order to avoid crashes. When the context
    //! menu will be shown there is a chance that previews window has already appeared in that
    //! case the previews window must become hidden
    Timer {
        id: windowsPreviewCheckerToNotShowTimer
        interval: 250

        onTriggered: {
            if (windowsPreviewDlg.visible && root.contextMenu) {
                windowsPreviewDlg.hide("8.2");
            }
        }
    }

    //! Timer to delay the removal of the window through the context menu in case the
    //! the window is zoomed
    Timer{
        id: delayWindowRemovalTimer
        //this is the animation time needed in order for tasks to restore their zoom first
        interval: 7 * (root.appletAbilities.animations.speedFactor.current * root.appletAbilities.animations.duration.small)

        property var modelIndex

        onTriggered: {
            tasksModel.requestClose(delayWindowRemovalTimer.modelIndex)

            if (root.appletAbilities.debug.timersEnabled) {
                console.log("plasmoid timer: delayWindowRemovalTimer called...");
            }
        }
    }

    Timer {
        id: activityChangeDelayer
        interval: 150
        onTriggered: {
            root.inActivityChange = false;
            root.publishTasksGeometries();
            activityInfo.previousActivity = activityInfo.currentActivity;

            if (root.appletAbilities.debug.timersEnabled) {
                console.log("plasmoid timer: activityChangeDelayer called...");
            }
        }
    }

    /////Window Previews/////////


    TaskManager.TasksModel {
        id: tasksModel

        virtualDesktop: virtualDesktopInfo.currentDesktop
        screenGeometry: root.appletAbilities.myView.screenGeometry
        activity: root.tasksModelActivityId

        filterByVirtualDesktop: root.showOnlyCurrentDesktop
        filterByScreen: root.showOnlyCurrentScreen
        filterByActivity: root.shouldFilterByActivity

        // Match Plasma Icons-Only Task Manager semantics:
        // a running app should replace its launcher representation.
        hideActivatedLaunchers: true
        launchInPlace: true
        separateLaunchers: true
        groupInline: false

        groupMode: root.groupTasksByDefault ? TaskManager.TasksModel.GroupApplications : TaskManager.TasksModel.GroupDisabled
        sortMode: TaskManager.TasksModel.SortManual
        taskReorderingEnabled: true

        property bool anyTaskDemandsAttentionInValidTime: false

        onActivityChanged: {
            ActivitiesTools.currentActivity = String(activity);
        }

        onGroupingAppIdBlacklistChanged: {
            root.plasmoid.configuration.groupingAppIdBlacklist = groupingAppIdBlacklist;
        }

        onGroupingLauncherUrlBlacklistChanged: {
            root.plasmoid.configuration.groupingLauncherUrlBlacklist = groupingLauncherUrlBlacklist;
        }

        onAnyTaskDemandsAttentionChanged: {
            anyTaskDemandsAttentionInValidTime = anyTaskDemandsAttention;

            if (anyTaskDemandsAttention){
                attentionTimer.start();
            } else {
                attentionTimer.stop();
            }
        }

        Component.onCompleted: {
            ActivitiesTools.launchersOnActivities = root.launchersOnActivities
            ActivitiesTools.currentActivity = String(activityInfo.currentActivity);
            ActivitiesTools.plasmoid = root.plasmoid;

            //var loadedLaunchers = ActivitiesTools.restoreLaunchers();
            ActivitiesTools.importLaunchersToNewArchitecture();

            root.appletAbilities.launchers.importLauncherListInModel();

            groupingAppIdBlacklist = root.plasmoid.configuration.groupingAppIdBlacklist;
            groupingLauncherUrlBlacklist = root.plasmoid.configuration.groupingLauncherUrlBlacklist;

            groupingWindowTasksThreshold = -1;
        }
    }

    // Wheel task cycling support: taskList Repeater mirrors the visual ordering
    Item {
        id: taskList
        Repeater {
            model: tasksModel
            Item {
                readonly property var m: model
                function modelIndex() { return tasksModel.makeModelIndex(index); }
            }
        }
    }

    // Called from containment's wheel handler to activate next/prev task in correct visual order
    function activateWheelTask(next) {
        TaskTools.activateNextPrevTask(next);
    }

    // Called from containment's wheel bridge with raw containment-local
    // coordinates and the containment root item.  Uses mapFromItem to
    // transform into plasmoid-local, then into badge-local for hit testing.
    // Returns true if volume was adjusted, false otherwise.
    function adjustVolumeForAudioBadge(containmentX, containmentY, delta, containmentItem) {
        // Transform containment-local → plasmoid-root-local
        var plasmoidLocal = mapFromItem(containmentItem, containmentX, containmentY);

        var tasks = icList.contentItem.children;
        for (var i = 0; i < tasks.length; ++i) {
            var task = tasks[i];
            if (!task || !task.visible || !task.hasAudioStream) {
                continue;
            }

            var badge = findAudioStreamFromItem(task);
            if (!badge || !badge.visible) {
                continue;
            }

            // Transform plasmoid-root-local → badge-local for hit test
            var pos = badge.mapFromItem(root, plasmoidLocal.x, plasmoidLocal.y);
            if (pos.x >= -badge.hitPadding && pos.x <= badge.width + badge.hitPadding
                    && pos.y >= -badge.hitPadding && pos.y <= badge.height + badge.hitPadding) {
                if (delta > 0) {
                    task.increaseVolume();
                } else {
                    task.decreaseVolume();
                }
                // Flash the volume level indicator on the badge
                badge.flashVolumeLevel();
                return true;
            }
        }
        return false;
    }

    // Recursively search an item's subtree for an AudioStream badge (matched by objectName).
    function findAudioStreamFromItem(item) {
        if (!item) {
            return null;
        }

        if (item.objectName === "audioStreamBadge") {
            return item;
        }

        var children = item.children;
        if (!children) {
            return null;
        }

        for (var i = 0; i < children.length; ++i) {
            var found = findAudioStreamFromItem(children[i]);
            if (found) {
                return found;
            }
        }

        return null;
    }

    //! TaskManagerBackend required a groupDialog setting otherwise it crashes. This patch
    //! sets one just in order not to crash TaskManagerBackend
    PlasmaCore.Dialog {
        //ghost group Dialog to not crash TaskManagerBackend
        id: groupDialogGhost
        visible: false

        type: PlasmaCore.Dialog.PopupMenu
        flags: Qt.WindowStaysOnTopHint
        hideOnWindowDeactivate: true
        location: root.location
    }


    TaskManagerApplet.Backend {
        id: backend
        taskManagerItem: root
        highlightWindows: root.highlightWindows

        onAddLauncher: function(url) {
            tasksModel.requestAddLauncher(url);
        }

        Component.onCompleted: {
            groupDialog = groupDialogGhost;
        }
    }

    // Latte owns highlighting instead of delegating it to Plasma's private
    // task-manager backend. That backend differs across Plasma versions and
    // its legacy implementation does not understand Wayland window UUIDs.
    LatteTasks.WindowViewBackend {
        id: windowEffectsBackend
    }

    Item {
        id: dragHelper
        width: 1
        height: 1

        Drag.dragType: Drag.Automatic
        Drag.supportedActions: Qt.CopyAction | Qt.MoveAction | Qt.LinkAction
        Drag.onDragFinished: root.dragSource = null;
    }

    TaskManager.VirtualDesktopInfo {
        id: virtualDesktopInfo
    }

    TaskManager.ActivityInfo {
        id: activityInfo

        property string previousActivity: ""
        onCurrentActivityChanged: {
            root.inActivityChange = true;
            activityChangeDelayer.start();
        }

        Component.onCompleted: previousActivity = currentActivity;
    }

    Mpris.Mpris2Model {
        id: mpris2Source
    }

    Loader {
        id: pulseAudio
        source: "PulseAudio.qml"
        active: root.showAudioBadge
    }

    TasksExtendedManager {
        id: _tasksExtendedManager
    }

    AppletAbilities {
        id: _appletAbilities
        bridge: root.latteBridge
        layout: icList.contentItem
        tasksModel: tasksModel

        animations.local.speedFactor.current: root.plasmoid.configuration.durationTime
        animations.local.requirements.zoomFactor: root.hasHighThicknessAnimation && LatteCore.WindowSystem.compositingActive ? 1.65 : 1.0

        // override by Connections for inDraggingPhase (binding not reliable here)
        indexer.updateIsBlocked: root.inActivityChange

        // Keep a temporary fallback when latteBridge attachment is delayed.
        // Once bridge is ready in Latte, use bridge indicators only to avoid
        // duplicate indicator layers that can interfere with task interaction.
        indicators.local.isEnabled: !root.plasmoid.configuration.isInLatteDock || root.latteBridge === null

        launchers.group: root.plasmoid.configuration.launchersGroup
        launchers.isStealingDroppedLaunchers: root.plasmoid.configuration.isPreferredForDroppedLaunchers
        launchers.syncer.isBlocked: root.inDraggingPhase

        metrics.local.iconSize: root.inPlasmaDesktop ? maxIconSizeInPlasma : (root.inPlasmaPanel ? Math.max(16, panelThickness - metrics.margin.tailThickness - metrics.margin.headThickness) : maxIconSizeInPlasma)
        metrics.local.backgroundThickness: metrics.totals.thickness
        metrics.local.margin.length: 0.1 * metrics.iconSize
        metrics.local.margin.tailThickness: root.inPlasmaDesktop ? 0.16 * metrics.iconSize : Math.max(2, (panelThickness - maxIconSizeInPlasma) / 2)
        metrics.local.margin.headThickness: metrics.local.margin.tailThickness
        metrics.local.padding.length: 0.04 * metrics.iconSize

        myView.local.isHidingBlocked: root.contextMenu || root.windowPreviewIsShown
        myView.local.itemShadow.size: Math.ceil(0.12*root.appletAbilities.metrics.iconSize)

        // Avoid self-referential bindings between parabolic.isEnabled and
        // parabolic.local.factor.zoom that can keep zoom disabled after startup.
        readonly property real localParabolicZoom: 1 + (root.plasmoid.configuration.zoomLevel / 20)
        readonly property bool localParabolicEnabled: (!root.inPlasma || root.inPlasmaDesktop) && localParabolicZoom > 1.0
        parabolic.local.isEnabled: localParabolicEnabled
        parabolic.local.factor.zoom: localParabolicEnabled ? localParabolicZoom : 1.0
        parabolic.local.factor.maxZoom: localParabolicEnabled ? Math.max(parabolic.local.factor.zoom, 1.6) : 1.0
        parabolic.local.restoreZoomIsBlocked: root.contextMenu || windowsPreviewDlg.containsMouse || isolatedPreview.hovered

        shortcuts.isStealingGlobalPositionShortcuts: root.plasmoid.configuration.isPreferredForPositionShortcuts

        requires.activeIndicatorEnabled: false
        requires.lengthMarginsEnabled: false
        requires.latteSideColoringEnabled: false
        requires.screenEdgeMarginSupported: true

        thinTooltip.local.showIsBlocked: root.contextMenu || root.windowPreviewIsShown
    }

    // Signal handlers always fire reliably (unlike bindings on root.* properties
    // inside AppletAbilities which miss changes).  Keep updateIsBlocked in sync
    // with inDraggingPhase via imperative assignment.
    // Freeze the indexer during drag to prevent binding loops while items
    // are being reordered.  When drag ends, inDraggingPhase becomes false
    // and updateIsBlocked returns to the binding value (inActivityChange only).
    // launchersInPausedStateCount is intentionally NOT included — it stays >0
    // for minutes after launcher animations and would freeze the indexer long
    // after drag completes.
    Connections {
        target: root
        function onInDraggingPhaseChanged() {
            _appletAbilities.indexer.updateIsBlocked =
                root.inDraggingPhase || root.inActivityChange;
        }
    }

    Timer{
        id: attentionTimer
        interval:8500
        onTriggered: {
            tasksModel.anyTaskDemandsAttentionInValidTime = false;

            if (root.appletAbilities.debug.timersEnabled) {
                console.log("plasmoid timer: attentionTimer called...");
            }
        }
    }

    //this timer restores the draggingPhase flag to false
    //after a dragging has finished... This delay is needed
    //in order to not animate any tasks are added after a
    //dragging
    Timer {
        id: restoreDraggingPhaseTimer
        interval: 150
        onTriggered: root.inDraggingPhase = false;
    }

    ///Red Liner!!! show the upper needed limit for animations
    Rectangle{
        anchors.horizontalCenter: !root.vertical ? parent.horizontalCenter : undefined
        anchors.verticalCenter: root.vertical ? parent.verticalCenter : undefined

        width: root.vertical ? 1 : 2 * root.appletAbilities.metrics.iconSize
        height: root.vertical ? 2 * root.appletAbilities.metrics.iconSize : 1
        color: "red"
        x: (root.location === PlasmaCore.Types.LeftEdge) ? neededSpace : parent.width - neededSpace
        y: (root.location === PlasmaCore.Types.TopEdge) ? neededSpace : parent.height - neededSpace

        visible: root.plasmoid.configuration.zoomHelper

        property int neededSpace: root.appletAbilities.parabolic.factor.zoom*root.appletAbilities.metrics.totals.length
    }

    Item{
        id:barLine
        anchors.bottom: (root.location === PlasmaCore.Types.BottomEdge) ? parent.bottom : undefined
        anchors.top: (root.location === PlasmaCore.Types.TopEdge) ? parent.top : undefined
        anchors.left: (root.location === PlasmaCore.Types.LeftEdge) ? parent.left : undefined
        anchors.right: (root.location === PlasmaCore.Types.RightEdge) ? parent.right : undefined

        anchors.horizontalCenter: !root.vertical ? parent.horizontalCenter : undefined
        anchors.verticalCenter: root.vertical ? parent.verticalCenter : undefined

        // For vertical docks the panel thickness should follow task thickness,
        // not a fixed tiny fallback size.
        width: (icList.orientation === Qt.Horizontal)
               ? icList.width + spacing
               : Math.max(icList.width + spacing, scrollableList.thickness, smallSize)
        height: (icList.orientation === Qt.Vertical)
                ? icList.height + spacing
                : Math.max(icList.height + spacing, scrollableList.thickness, smallSize)

        property int spacing: root.latteBridge ? 0 : root.appletAbilities.metrics.iconSize / 2
        property int smallSize: Math.max(0.10 * root.appletAbilities.metrics.iconSize, 16)

        Behavior on opacity{
            NumberAnimation { duration: root.appletAbilities.animations.speedFactor.current * root.appletAbilities.animations.duration.large }
        }

        /// plasmoid's default panel
        BorderImage{
            anchors.fill:parent
            source: "../images/panel-west.png"
            border { left:8; right:8; top:8; bottom:8 }

            opacity: (root.plasmoid.configuration.showBarLine && !root.plasmoid.configuration.useThemePanel && root.inPlasma) ? 1 : 0

            visible: (opacity == 0) ? false : true

            horizontalTileMode: BorderImage.Stretch
            verticalTileMode: BorderImage.Stretch

            Behavior on opacity{
                NumberAnimation { duration: root.appletAbilities.animations.speedFactor.current * root.appletAbilities.animations.duration.large }
            }
        }


        /// item which is used as anchors for the plasma's theme
        Item{
            id:belower

            width: (root.location === PlasmaCore.Types.LeftEdge) ? shadowsSvgItem.margins.left : shadowsSvgItem.margins.right
            height: (root.location === PlasmaCore.Types.BottomEdge)? shadowsSvgItem.margins.bottom : shadowsSvgItem.margins.top

            anchors.top: (root.location === PlasmaCore.Types.BottomEdge) ? parent.bottom : undefined
            anchors.bottom: (root.location === PlasmaCore.Types.TopEdge) ? parent.top : undefined
            anchors.right: (root.location === PlasmaCore.Types.LeftEdge) ? parent.left : undefined
            anchors.left: (root.location === PlasmaCore.Types.RightEdge) ? parent.right : undefined
        }


        /// the current theme's panel
        KSvg.FrameSvgItem{
            id: shadowsSvgItem

            anchors.bottom: (root.location === PlasmaCore.Types.BottomEdge) ? belower.bottom : undefined
            anchors.top: (root.location === PlasmaCore.Types.TopEdge) ? belower.top : undefined
            anchors.left: (root.location === PlasmaCore.Types.LeftEdge) ? belower.left : undefined
            anchors.right: (root.location === PlasmaCore.Types.RightEdge) ? belower.right : undefined

            anchors.horizontalCenter: !root.vertical ? parent.horizontalCenter : undefined
            anchors.verticalCenter: root.vertical ? parent.verticalCenter : undefined

            width: root.vertical ? panelSize + margins.left + margins.right: parent.width
            height: root.vertical ? parent.height : panelSize + margins.top + margins.bottom

            imagePath: "translucent/widgets/panel-background"
            prefix:"shadow"

            opacity: (root.plasmoid.configuration.showBarLine && root.plasmoid.configuration.useThemePanel && root.inPlasma) ? 1 : 0
            visible: (opacity == 0) ? false : true

            property int panelSize: ((root.location === PlasmaCore.Types.BottomEdge) ||
                                     (root.location === PlasmaCore.Types.TopEdge)) ?
                                        root.plasmoid.configuration.panelSize + belower.height:
                                        root.plasmoid.configuration.panelSize + belower.width

            Behavior on opacity{
                NumberAnimation { duration: root.appletAbilities.animations.speedFactor.current * root.appletAbilities.animations.duration.large }
            }


            KSvg.FrameSvgItem{
                anchors.margins: belower.width-1
                anchors.fill:parent
                imagePath: root.plasmoid.configuration.transparentPanel ? "translucent/widgets/panel-background" :
                                                                     "widgets/panel-background"
            }
        }


        TasksLayout.MouseHandler {
            id: mouseHandler
            anchors.bottom: (root.location === PlasmaCore.Types.BottomEdge) ? scrollableList.bottom : undefined
            anchors.top: (root.location === PlasmaCore.Types.TopEdge) ? scrollableList.top : undefined
            anchors.left: (root.location === PlasmaCore.Types.LeftEdge) ? scrollableList.left : undefined
            anchors.right: (root.location === PlasmaCore.Types.RightEdge) ? scrollableList.right : undefined

            anchors.horizontalCenter: !root.vertical ? scrollableList.horizontalCenter : undefined
            anchors.verticalCenter: root.vertical ? scrollableList.verticalCenter : undefined

            width: root.vertical ? maxThickness : icList.width
            height: root.vertical ? icList.height : maxThickness

            target: icList

            property int maxThickness: ((root.appletAbilities.parabolic.isEnabled && root.appletAbilities.parabolic.isHovered)
                                        || (root.appletAbilities.parabolic.isEnabled && root.windowPreviewIsShown)
                                        || root.appletAbilities.animations.hasThicknessAnimation) ?
                                           root.appletAbilities.metrics.mask.thickness.maxZoomedForItems : // dont clip bouncing tasks when zoom=1
                                           root.appletAbilities.metrics.mask.thickness.normalForItems

            function onlyLaunchersInDroppedList(list){
                return list.every(function (item) {
                    return backend.isApplication(item)
                });
            }

            onUrlsDropped: (urls) => {
                //! inform synced docks for new dropped launchers
                if (onlyLaunchersInDroppedList(urls)) {
                    root.appletAbilities.launchers.addDroppedLaunchers(urls);
                    return;
                }

                //! if the list does not contain only launchers then just open the corresponding
                //! urls with the relevant app

                if (!hoveredItem) {
                    return;
                }

                // DeclarativeMimeData urls is a QJsonArray but requestOpenUrls expects a proper QList<QUrl>.
                var urlsList = backend.jsonArrayToUrlList(urls);

                // Otherwise we'll just start a new instance of the application with the URLs as argument,
                // as you probably don't expect some of your files to open in the app and others to spawn launchers.
                tasksModel.requestOpenUrls(hoveredItem.modelIndex(), urlsList);
            }
        }

        /* Rectangle {
            anchors.fill: scrollableList
            color: "transparent"
            border.width: 1
            border.color: "blue"
        } */

        TasksLayout.ScrollableList {
            id: scrollableList
            width: !root.vertical ? length : thickness
            height: root.vertical ? length : thickness
            contentWidth: icList.width
            contentHeight: icList.height

            //onCurrentPosChanged: console.log("CP :: "+ currentPos + " icW:"+icList.width + " rw: "+root.width + " w:" +width);

            layer.enabled: contentsExceed && root.scrollingEnabled
            layer.effect: MultiEffect {
                maskEnabled: true
                maskSource: TasksLayout.ScrollOpacityMask{
                    width: scrollableList.width
                    height: scrollableList.height
                }
            }

            Binding {
                target: scrollableList
                property: "thickness"
                value: {
                    if (root.appletAbilities.myView.isReady) {
                        return root.appletAbilities.animations.hasThicknessAnimation ? root.appletAbilities.metrics.mask.thickness.zoomed : root.appletAbilities.metrics.mask.thickness.normal;
                    }

                    return root.appletAbilities.metrics.totals.thickness * root.appletAbilities.parabolic.factor.zoom;
                }
            }

            Binding {
                target: scrollableList
                property: "length"
                value: {
                    var contentLength = Math.max(1, root.tasksLength);
                    var edgeLength = root.vertical ? root.height : root.width;

                    // During edge relocation the host can briefly report 0 or tiny
                    // dimensions; in that phase keep content-driven length.
                    if (edgeLength <= 1) {
                        return contentLength;
                    }

                    return Math.min(edgeLength, contentLength);
                }
            }

            TasksLayout.ScrollPositioner {
                id: listViewBase

                ListView {
                    id:icList
                    model: tasksModel
                    orientation: root.vertical ? ListView.Vertical : ListView.Horizontal
                    delegate: Task.TaskItem{
                        abilities: appletAbilities
                    }

                    property int currentSpot : -1000
                    property int previousCount : 0

                    property int tasksCount: tasksModel.count

                    //the duration of this animation should be as small as possible
                    //it fixes a small issue with the dragging an item to change it's
                    //position, if the duration is too big there is a point in the
                    //list that an item is going back and forth too fast

                    //more of a trouble
                    moveDisplaced: Transition {
                        NumberAnimation { properties: "x,y"; duration: root.appletAbilities.animations.speedFactor.current * root.appletAbilities.animations.duration.large; easing.type: Easing.Linear }
                    }

                    ///this transition can not be used with dragging !!!! I breaks
                    ///the lists indexes !!!!!
                    ///move: Transition {
                    ///    NumberAnimation { properties: "x,y"; duration: 400; easing.type: Easing.Linear }
                    ///}

                    function childAtPos(x, y, ignoredItem){
                        var tasks = icList.contentItem.children;
                        var bestTask = null;
                        var bestDistance = Number.POSITIVE_INFINITY;

                        for(var i=0; i<tasks.length; ++i){
                            var task = tasks[i];

                            if (task.objectName !== "TaskItem") {
                                continue;
                            }

                            if (ignoredItem && task === ignoredItem) {
                                continue;
                            }

                            var choords = mapFromItem(task,0, 0);

                            if ((x>=choords.x) && (x<=choords.x+task.width)
                                    && (y>=choords.y) && (y<=choords.y+task.height)) {
                                // In parabolic mode, task delegates can overlap. Pick the
                                // closest center to the pointer to get stable reorder target.
                                var centerX = choords.x + (task.width / 2);
                                var centerY = choords.y + (task.height / 2);
                                var distance = root.vertical ? Math.abs(y - centerY) : Math.abs(x - centerX);

                                if (distance < bestDistance) {
                                    bestDistance = distance;
                                    bestTask = task;
                                }
                            }
                        }

                        return bestTask;
                    }

                    function childAtIndex(position) {
                        var tasks = icList.contentItem.children;

                        if (position < 0)
                            return;

                        for(var i=0; i<tasks.length; ++i){
                            var task = tasks[i];

                            if (task.lastValidIndex === position
                                    || (task.lastValidIndex === -1 && task.itemIndex === position )) {
                                return task;
                            }
                        }

                        return undefined;
                    }
                }
            } // ScrollPositioner
        } // ScrollableList

        TasksLayout.ScrollEdgeShadows {
            id: scrollShadows
            width: !root.vertical ? scrollableList.width : thickness
            height: !root.vertical ? thickness : scrollableList.height
            visible: scrollableList.contentsExceed

            flickable: scrollableList
        } // ScrollEdgeShadows

        LatteComponents.AddingArea {
            id: newDroppedLauncherVisual
            width: root.vertical ? root.appletAbilities.metrics.totals.thickness : scrollableList.length
            height: root.vertical ? scrollableList.length : root.appletAbilities.metrics.totals.thickness

            visible: backgroundOpacity > 0
            radius: root.appletAbilities.metrics.iconSize/10
            backgroundOpacity: mouseHandler.isDroppingOnlyLaunchers || root.appletAbilities.launchers.isShowingAddLaunchersMessage ? 0.75 : 0
            duration: root.appletAbilities.animations.speedFactor.current
            iconSize: root.appletAbilities.metrics.iconSize
            z: 99

            title: i18n("Tasks Area")

            states: [
                ///Bottom Edge
                State {
                    name: "left"
                    when: root.location===PlasmaCore.Types.LeftEdge

                    AnchorChanges {
                        target: newDroppedLauncherVisual
                        anchors{ top:undefined; bottom:undefined; left:scrollableList.left; right:undefined;
                            horizontalCenter:undefined; verticalCenter:scrollableList.verticalCenter}
                    }

                    PropertyChanges {
                        newDroppedLauncherVisual.anchors.topMargin: 0; newDroppedLauncherVisual.anchors.bottomMargin: 0;
                        newDroppedLauncherVisual.anchors.leftMargin: appletAbilities.metrics.margin.screenEdge; newDroppedLauncherVisual.anchors.rightMargin: 0;
                    }
                },
                State {
                    name: "right"
                    when: root.location===PlasmaCore.Types.RightEdge

                    AnchorChanges {
                        target: newDroppedLauncherVisual
                        anchors{ top:undefined; bottom:undefined; left:undefined; right:scrollableList.right;
                            horizontalCenter:undefined; verticalCenter:scrollableList.verticalCenter}
                    }

                    PropertyChanges {
                        newDroppedLauncherVisual.anchors.topMargin: 0; newDroppedLauncherVisual.anchors.bottomMargin: 0;
                        newDroppedLauncherVisual.anchors.leftMargin: 0; newDroppedLauncherVisual.anchors.rightMargin: appletAbilities.metrics.margin.screenEdge;
                    }
                },
                State {
                    name: "top"
                    when: root.location===PlasmaCore.Types.TopEdge

                    AnchorChanges {
                        target: newDroppedLauncherVisual
                        anchors{ top:scrollableList.top; bottom:undefined; left:undefined; right:undefined;
                            horizontalCenter:scrollableList.horizontalCenter; verticalCenter:undefined}
                    }

                    PropertyChanges {
                        newDroppedLauncherVisual.anchors.topMargin: appletAbilities.metrics.margin.screenEdge; newDroppedLauncherVisual.anchors.bottomMargin: 0;
                        newDroppedLauncherVisual.anchors.leftMargin: 0; newDroppedLauncherVisual.anchors.rightMargin: 0;
                    }
                },
                State {
                    name: "bottom"
                    when: root.location!==PlasmaCore.Types.TopEdge
                          && root.location !== PlasmaCore.Types.LeftEdge
                          && root.location !== PlasmaCore.Types.RightEdge

                    AnchorChanges {
                        target: newDroppedLauncherVisual
                        anchors{ top:undefined; bottom:scrollableList.bottom; left:undefined; right:undefined;
                            horizontalCenter:scrollableList.horizontalCenter; verticalCenter:undefined}
                    }

                    PropertyChanges {
                        newDroppedLauncherVisual.anchors.topMargin: 0; newDroppedLauncherVisual.anchors.bottomMargin: appletAbilities.metrics.margin.screenEdge;
                        newDroppedLauncherVisual.anchors.leftMargin: 0; newDroppedLauncherVisual.anchors.rightMargin: 0;
                    }
                }
            ]
        }
    }

    //// helpers

    Timer {
        id: iconGeometryTimer
        // INVESTIGATE: such big interval but unfortunately it does not work otherwise
        interval: 500
        repeat: false

        onTriggered: {
            root.publishTasksGeometries();

            if (root.appletAbilities.debug.timersEnabled) {
                console.log("plasmoid timer: iconGeometryTimer called...");
            }
        }
    }

    Timer {
        id: taskLayoutRefreshTimer
        interval: 120
        repeat: true

        onTriggered: {
            root.pendingTaskLayoutRefreshPass = root.pendingTaskLayoutRefreshPass + 1;
            refreshTaskLayoutPass(root.pendingTaskLayoutRefreshReason, root.pendingTaskLayoutRefreshPass);

            if (root.pendingTaskLayoutRefreshPass >= 8) {
                stop();
            }
        }
    }


    //// functions
    function refreshTaskLayoutAfterEdgeChange(reason) {
        pendingTaskLayoutRefreshReason = reason;
        pendingTaskLayoutRefreshPass = 0;
        refreshTaskLayoutPass(reason, 0);
        taskLayoutRefreshTimer.restart();
    }

    function refreshTaskLayoutPass(reason, pass) {
        if (!scrollableList || !icList) {
            return;
        }

        scrollableList.contentX = 0;
        scrollableList.contentY = 0;
        icList.forceLayout();
        root.publishTasksGeometries();
    }

    function activateTaskAtIndex(index) {
        // This is called with Meta+number shortcuts by plasmashell when Tasks are in a plasma panel.
        appletAbilities.shortcuts.sglActivateEntryAtIndex(index);
    }

    function newInstanceForTaskAtIndex(index) {
        // This is called with Meta+Alt+number shortcuts by plasmashell when Tasks are in a plasma panel.
        appletAbilities.shortcuts.sglNewInstanceForEntryAtIndex(index);
    }

    function getBadger(identifier) {
        var ident1 = identifier;
        var n = ident1.lastIndexOf('/');

        var result = n>=0 ? ident1.substring(n + 1) : identifier;

        for(var i=0; i<badgers.length; ++i) {
            if (result.indexOf(badgers[i].id) >= 0) {
                return badgers[i];
            }
        }
    }

    function updateBadge(identifier, value) {
        var tasks = icList.contentItem.children;
        var identifierF = identifier.concat(".desktop");

        for(var i=0; i<tasks.length; ++i){
            var task = tasks[i];

            if (task && task.launcherUrl && task.launcherUrl.indexOf(identifierF) >= 0) {
                task.badgeIndicator = value === "" ? 0 : Number(value);
                var badge = getBadger(identifierF);
                if (badge) {
                    badge.value = value;
                } else {
                    badgers.push({id: identifierF, value: value});
                }
            }
        }
    }

    function getLauncherList() {
        return plasmoid.configuration.launchers59;
    }

    function hasLauncher(url) {
        return appletAbilities.launchers.hasLauncher(url);
    }

    function addLauncher(url) {
        appletAbilities.launchers.addLauncher(url);
    }

    function removeLauncher(url) {
        appletAbilities.launchers.removeLauncher(url);
    }

    function previewContainsMouse() {
        return windowsPreviewDlg.containsMouse;
    }

    function containsMouse(){
        //console.log("s1...");
        if (disableRestoreZoom && (root.contextMenu || windowsPreviewDlg.visible)) {
            return;
        } else {
            disableRestoreZoom = false;
        }

        //if (previewContainsMouse())
        //  windowsPreviewDlg.hide(4);

        if (previewContainsMouse())
            return true;

        //console.log("s3...");
        var tasks = icList.contentItem.children;

        for(var i=0; i<tasks.length; ++i){
            var task = tasks[i];

            if(task && task.containsMouse){
                // console.log("Checking "+i+" - "+task.index+" - "+task.containsMouse);
                return true;
            }
        }

        return false;
    }

    function createContextMenu(rootTask, modelIndex, args) {
        var initialArgs = args || {}
        initialArgs.visualParent = rootTask;
        initialArgs.modelIndex = modelIndex;
        initialArgs.root = root;
        initialArgs.plasmoid = plasmoid;
        initialArgs.tasksModel = tasksModel;
        initialArgs.virtualDesktopInfo = virtualDesktopInfo;
        initialArgs.activityInfo = activityInfo;
        initialArgs.mpris2Source = mpris2Source;
        initialArgs.backend = backend;

        if (!root.contextMenuComponent || root.contextMenuComponent.status === Component.Error) {
            if (root.contextMenuComponent && root.contextMenuComponent.status === Component.Error) {
                console.warn("ContextMenu component load error:", root.contextMenuComponent.errorString());
            }
            root.contextMenuComponent = Qt.createComponent("ContextMenu.qml", Component.PreferSynchronous);
        }

        if (root.contextMenuComponent.status !== Component.Ready) {
            console.warn("ContextMenu component is not ready:", root.contextMenuComponent.errorString());
            return null;
        }

        root.contextMenu = root.contextMenuComponent.createObject(rootTask, initialArgs);

        if (!root.contextMenu) {
            console.warn("ContextMenu object creation failed:", root.contextMenuComponent.errorString());
        }

        return root.contextMenu;
    }

    Component.onCompleted:  {
        root.activateWindowView.connect(backend.activateWindowView);
        updateListViewParent();

        if (root.contextMenuComponent.status === Component.Error) {
            console.warn("ContextMenu component load error:", root.contextMenuComponent.errorString());
        }
    }

    Component.onDestruction: {
        root.activateWindowView.disconnect(backend.activateWindowView);
        root.cancelHighlightWindows();
    }

    //BEGIN states
    // Alignments
    // 0-Center, 1-Left, 2-Right, 3-Top, 4-Bottom
    states: [
        ///Bottom Edge
        State {
            name: "bottomCenter"
            when: (root.location===PlasmaCore.Types.BottomEdge && root.alignment===LatteCore.types.Center)

            AnchorChanges {
                target: barLine
                anchors{ top:undefined; bottom:parent.bottom; left:undefined; right:undefined; horizontalCenter:parent.horizontalCenter; verticalCenter:undefined}
            }
        },
        State {
            name: "bottomLeft"
            when: (root.location===PlasmaCore.Types.BottomEdge && root.alignment===LatteCore.types.Left)

            AnchorChanges {
                target: barLine
                anchors{ top:undefined; bottom:parent.bottom; left:parent.left; right:undefined; horizontalCenter:undefined; verticalCenter:undefined}
            }
        },
        State {
            name: "bottomRight"
            when: (root.location===PlasmaCore.Types.BottomEdge && root.alignment===LatteCore.types.Right)

            AnchorChanges {
                target: barLine
                anchors{ top:undefined; bottom:parent.bottom; left:undefined; right:parent.right; horizontalCenter:undefined; verticalCenter:undefined}
            }
        },
        ///Top Edge
        State {
            name: "topCenter"
            when: (root.location===PlasmaCore.Types.TopEdge && root.alignment===LatteCore.types.Center)

            AnchorChanges {
                target: barLine
                anchors{ top:parent.top; bottom:undefined; left:undefined; right:undefined; horizontalCenter:parent.horizontalCenter; verticalCenter:undefined}
            }
        },
        State {
            name: "topLeft"
            when: (root.location===PlasmaCore.Types.TopEdge && root.alignment===LatteCore.types.Left)

            AnchorChanges {
                target: barLine
                anchors{ top:parent.top; bottom:undefined; left:parent.left; right:undefined; horizontalCenter:undefined; verticalCenter:undefined}
            }
        },
        State {
            name: "topRight"
            when: (root.location===PlasmaCore.Types.TopEdge && root.alignment===LatteCore.types.Right)

            AnchorChanges {
                target: barLine
                anchors{ top:parent.top; bottom:undefined; left:undefined; right:parent.right; horizontalCenter:undefined; verticalCenter:undefined}
            }
        },
        ////Left Edge
        State {
            name: "leftCenter"
            when: (root.location===PlasmaCore.Types.LeftEdge && root.alignment===LatteCore.types.Center)

            AnchorChanges {
                target: barLine
                anchors{ top:undefined; bottom:undefined; left:parent.left; right:undefined; horizontalCenter:undefined; verticalCenter:parent.verticalCenter}
            }
        },
        State {
            name: "leftTop"
            when: (root.location===PlasmaCore.Types.LeftEdge && root.alignment===LatteCore.types.Top)

            AnchorChanges {
                target: barLine
                anchors{ top:parent.top; bottom:undefined; left:parent.left; right:undefined; horizontalCenter:undefined; verticalCenter:undefined}
            }
        },
        State {
            name: "leftBottom"
            when: (root.location===PlasmaCore.Types.LeftEdge && root.alignment===LatteCore.types.Bottom)

            AnchorChanges {
                target: barLine
                anchors{ top:undefined; bottom:parent.bottom; left:parent.left; right:undefined; horizontalCenter:undefined; verticalCenter:undefined}
            }
        },
        ///Right Edge
        State {
            name: "rightCenter"
            when: (root.location===PlasmaCore.Types.RightEdge && root.alignment===LatteCore.types.Center)

            AnchorChanges {
                target: barLine
                anchors{ top:undefined; bottom:undefined; left:undefined; right:parent.right; horizontalCenter:undefined; verticalCenter:parent.verticalCenter}
            }
        },
        State {
            name: "rightTop"
            when: (root.location===PlasmaCore.Types.RightEdge && root.alignment===LatteCore.types.Top)

            AnchorChanges {
                target: barLine
                anchors{ top:parent.top; bottom:undefined; left:undefined; right:parent.right; horizontalCenter:undefined; verticalCenter:undefined}
            }
        },
        State {
            name: "rightBottom"
            when: (root.location===PlasmaCore.Types.RightEdge && root.alignment===LatteCore.types.Bottom)

            AnchorChanges {
                target: barLine
                anchors{ top:undefined; bottom:parent.bottom; left:undefined; right:parent.right; horizontalCenter:undefined; verticalCenter:undefined}
            }
        }

    ]
    //END states

}
