/*
    SPDX-FileCopyrightText: 2016 Smith AR <audoban@openmailbox.org>
    SPDX-FileCopyrightText: 2016 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import QtQml.Models

//trying to do a very simple thing to count how many windows does
//a task instance has...
//Workaround the mess with launchers, startups, windows etc.

Item{
    id: windowsContainer
    property int windowsCount: {
        if (isLauncher || isStartup) {
            return 0;
        }

        if (isGroupParent) {
            var childs = windowsLocalModel.items;
            var count = 0;

            for (var i = 0; i < childs.count; ++i) {
                if (childs.get(i).model.IsWindow === true) {
                    count++;
                }
            }

            return count;
        }

        return 1;
    }

    property int windowsMinimized: 0

    property bool isLauncher: IsLauncher ? true : false
    property bool isStartup: IsStartup ? true : false
    property bool isWindow: IsWindow ? true : false

    property int lastActiveWinInGroup: -1

    //states that exist in windows in a Group of windows
    property bool hasMinimized: false;
    property bool hasShown: false;
    property bool hasActive: false;
    property int activeWindowIndex: -1;
    property var windowsMinimizedList: [];

    Repeater{
        id: windowsRepeater
        model:DelegateModel {
            id: windowsLocalModel
            model: tasksModel

            delegate: Item{
                readonly property string title: display !== undefined ? display : ""
                readonly property bool isMinimized: IsMinimized === true ? true : false
                readonly property bool isActive: IsActive === true ? true : false

                onIsMinimizedChanged: windowsContainer.updateStates();
                onIsActiveChanged:  {
                    if (isActive) {
                        var winIdList = WinIdList;
                        var activeWinId = 0;

                        if (winIdList !== undefined && winIdList.length > 0) {
                            var parsedWinId = Number(winIdList[0]);
                            activeWinId = isNaN(parsedWinId) ? 0 : parsedWinId;
                        }

                        windowsContainer.lastActiveWinInGroup = activeWinId;
                    }
                    windowsContainer.updateStates();
                }
            }

            Component.onCompleted: {
                rootIndex = taskItem.modelIndex();
            }
        }
    }

    Connections{
        target: taskItem
        function onItemIndexChanged() { windowsContainer.updateStates(); }
    }

    Connections{
        target: windowsRepeater
        function onCountChanged() { windowsContainer.updateStates(); }
    }

    Connections{
        target: root
        function onInDraggingPhaseChanged() { windowsContainer.updateStates(); }
    }

    //! try to give the time to the model to update its states in order to
    //! avoid any suspicious crashes during dragging grouped tasks that
    //! are synced between multiple panels/docks. At the same time in updateStates()
    //! function we block any DelegateModel updates when the user is dragging
    //! a task because this could create crashes
    Timer{
        id: initializeStatesTimer
        interval: 200
        onTriggered: windowsContainer.initializeStates();
    }

    function updateStates() {
        if (!root.inDraggingPhase) {
            initializeStatesTimer.start();
        }
    }

    function initializeStates(){
        windowsLocalModel.rootIndex = taskItem.modelIndex();

        hasMinimized = false;
        hasShown = false;
        hasActive = false;
        activeWindowIndex = -1;
        windowsMinimizedList = [];

        if(IsGroupParent){
            checkInternalStates();
        } else {
            var minimized = 0;
            var minList = [];

            if(taskItem.isActive){
                hasActive = true;
                activeWindowIndex = 0;
            }

            if(taskItem.isMinimized){
                hasMinimized = true;
                minimized = minimized + 1;
                minList.push(true);
            } else {
                minList.push(false);
                if (taskItem.isWindow) {
                    hasShown = true;
                }
            }

            windowsMinimized = minimized;
            windowsMinimizedList = minList;
        }
    }

    function checkInternalStates(){
        var childs = windowsLocalModel.items;

        var minimized = 0;
        var activeIndex = -1;
        var minList = [];

        var windowIndex = -1;

        for(var i=0; i<childs.count; ++i){
            var kid = childs.get(i);

            if (kid.model.IsWindow !== true) {
                continue;
            }

            windowIndex++;

            if (kid.model.IsActive){
                hasActive = true;
                activeIndex = windowIndex;
            }

            if(kid.model.IsMinimized) {
                hasMinimized = true;
                minimized = minimized + 1;
                minList.push(true);
            } else {
                minList.push(false);
                if (kid.model.IsWindow) {
                    hasShown = true;
                }
            }
        }

        windowsMinimized = minimized;
        activeWindowIndex = activeIndex;
        windowsMinimizedList = minList;
    }

    function windowsTitles() {
        windowsLocalModel.rootIndex = taskItem.modelIndex();
        var result = new Array;
        var childs = windowsLocalModel.items;

        for(var i=0; i<childs.count; ++i){
            var kid = childs.get(i);
            var title = kid.model.display

            result.push(title);
        }

        return result;
    }

    //! Skip "phantom" group entries (e.g. ghostty's headless daemon
    //! registers an xdg_toplevel with no real surface; activating it is a
    //! no-op which makes the task icon feel frozen).
    //!
    //! IsHidden is true for "phantoms" AND for minimized windows
    //! A real minimized window still has a WinIdList and IsMinimized === true
    //! Only reject group entries that are hidden without being minimized
    function isActivatableChild(kid) {
        if (!kid || !kid.model) {
            return false;
        }
        var winIdList = kid.model.WinIdList;
        if (winIdList === undefined || winIdList.length === 0) {
            return false;
        }
        if (kid.model.IsHidden === true && kid.model.IsMinimized !== true) {
            return false;
        }
        return true;
    }

    function previewWindows() {
        windowsLocalModel.rootIndex = taskItem.modelIndex();
        var windows = [];
        for (var i = 0; i < windowsLocalModel.items.count; ++i) {
            var kid = windowsLocalModel.items.get(i);
            if (isActivatableChild(kid)) {
                windows.push({uuid: String(kid.model.WinIdList[0]),
                    appName: String(kid.model.AppName || ""),
                    title: String(kid.model.display || ""),
                    launcherUrl: String(kid.model.LauncherUrlWithoutIcon || kid.model.LauncherUrl || ""),
                    appPid: Number(kid.model.AppPid || 0),
                    minimized: kid.model.IsMinimized === true});
            }
        }
        return windows;
    }
    function activatePreviewUuid(uuid) {
        windowsLocalModel.rootIndex = taskItem.modelIndex();
        // Resolve the UUID again at click time: model indices can change while
        // the separate preview process is displaying the previous selection.
        for (var i = 0; i < windowsLocalModel.items.count; ++i) {
            var kid = windowsLocalModel.items.get(i);
            if (isActivatableChild(kid) && String(kid.model.WinIdList[0]) === uuid) {
                activateChild(i);
                return;
            }
        }
    }

    function closePreviewUuid(uuid) {
        windowsLocalModel.rootIndex = taskItem.modelIndex();
        // Resolve the model index at click time because closing another group
        // member can reorder the remaining delegates while the preview stays
        // open.
        for (var i = 0; i < windowsLocalModel.items.count; ++i) {
            var kid = windowsLocalModel.items.get(i);
            if (isActivatableChild(kid) && String(kid.model.WinIdList[0]) === uuid) {
                tasksModel.requestClose(tasksModel.makeModelIndex(index, i));
                return;
            }
        }
    }

    function presentableWindowIds() {
        windowsLocalModel.rootIndex = taskItem.modelIndex();
        var ids = [];
        var childs = windowsLocalModel.items;
        for (var i = 0; i < childs.count; ++i) {
            var kid = childs.get(i);
            // Use the same eligibility as cycling: hidden daemon toplevels
            // must not turn a single real window into a presentation group.
            // Minimized real windows remain eligible for both operations.
            if (isActivatableChild(kid)) {
                for (var j = 0; j < kid.model.WinIdList.length; ++j) {
                    var id = kid.model.WinIdList[j];
                    if (ids.indexOf(id) === -1) {
                        ids.push(id);
                    }
                }
            }
        }
        return ids;
    }

    //! Activate child by subIndex
    //! Restore it first, if minimized
    //! In plasma 6 requestActivate() does not unminimize windows by itself,
    //! so minimized group members would be skipped if they aren't unminimized first
    function activateChild(subIndex) {
        var mi = tasksModel.makeModelIndex(index, subIndex);
        var kid = windowsLocalModel.items.get(subIndex);

        if (kid && kid.model.IsMinimized === true) {
            tasksModel.requestToggleMinimized(mi);
        }

        tasksModel.requestActivate(mi);
    }

    //! function which is used to cycle activation into
    //! a group of windows
    function activateNextTask() {
        windowsLocalModel.rootIndex = taskItem.modelIndex();

        if (!taskItem.isGroupParent) {
            return;
        }

        var childs = windowsLocalModel.items;
        var activeIdx = -1;

        for(var i=0; i<childs.count; ++i){
            var kid = childs.get(i);
            if (kid.model.IsActive === true) {
                activeIdx = i;
                break;
            }
        }

        // Pick the next activatable sibling, wrapping around. Skip phantom
        // children (no surface) so a single click reliably reaches a real
        // window.
        var nextAvailableWindow = -1;
        for(var step=1; step<=childs.count; ++step) {
            var probe = ((activeIdx === -1 ? -1 : activeIdx) + step + childs.count) % childs.count;
            if (isActivatableChild(childs.get(probe))) {
                nextAvailableWindow = probe;
                break;
            }
        }

        if (nextAvailableWindow === -1 && lastActiveWinInGroup !==-1){
            for(var i=0; i<childs.count; ++i){
                var kid = childs.get(i);
                var winIdList = kid.model.WinIdList;
                var kidId = (winIdList !== undefined ? winIdList[0] : 0);

                if (kidId === lastActiveWinInGroup && isActivatableChild(kid)) {
                    nextAvailableWindow = i;
                    break;
                }
            }
        }

        if (nextAvailableWindow === -1)
            nextAvailableWindow = 0;

        activateChild(nextAvailableWindow);
    }

    //! function which is used to cycle activation into
    //! a group of windows backwise
    function activatePreviousTask() {
        windowsLocalModel.rootIndex = taskItem.modelIndex();

        if (!taskItem.isGroupParent) {
            return;
        }

        var childs = windowsLocalModel.items;
        var activeIdx = -1;

        for(var i=childs.count-1; i>=0; --i){
            var kid = childs.get(i);
            if (kid.model.IsActive === true) {
                activeIdx = i;
                break;
            }
        }

        // Pick the previous activatable sibling, wrapping around. Skip
        // phantom children (no surface) so backwards cycling also reliably
        // reaches a real window, mirroring activateNextTask().
        var prevAvailableWindow = -1;
        for(var step=1; step<=childs.count; ++step) {
            var probe = ((activeIdx === -1 ? childs.count : activeIdx) - step + 2*childs.count) % childs.count;
            if (isActivatableChild(childs.get(probe))) {
                prevAvailableWindow = probe;
                break;
            }
        }

        if (prevAvailableWindow === -1 && lastActiveWinInGroup !==-1){
            for(var i=childs.count-1; i>=0; --i){
                var kid = childs.get(i);
                var winIdList = kid.model.WinIdList;
                var kidId = (winIdList !== undefined ? winIdList[0] : 0);

                if (kidId === lastActiveWinInGroup && isActivatableChild(kid)) {
                    prevAvailableWindow = i;
                    break;
                }
            }
        }

        //no window was found
        if (prevAvailableWindow === -1)
            prevAvailableWindow = 0;

        activateChild(prevAvailableWindow);
    }

    //! function which is used to cycle activation into
    //! a group of windows backwise
    function minimizeTask() {
        windowsLocalModel.rootIndex = taskItem.modelIndex();

        if (!taskItem.isGroupParent) {
            return;
        }

        var childs = windowsLocalModel.items;

        //indicates than nothing was found
        var availableWindow = -1;

        for(var i=childs.count-1; i>=0; --i){
            var kid = childs.get(i);
            if (kid.model.IsActive === true) {
                availableWindow = i;
                break;
            }
        }

        if (availableWindow === -1 && lastActiveWinInGroup !==-1){
            for(var i=childs.count-1; i>=0; --i){
                var kid = childs.get(i);
                var firstTask = kid.model.WinIdList[0];
                var isMinimized = kid.model.IsMinimized === true;

                if (firstTask === lastActiveWinInGroup && !isMinimized) {
                    availableWindow = i;
                    break;
                }
            }
        }

        //no window was found
        if (availableWindow === -1) {
            for(var i=childs.count-1; i>=0; --i){
                var kid = childs.get(i);
                if (kid.model.IsMinimized !== true) {
                    availableWindow = i;
                    break;
                }
            }
        }

        if (availableWindow !== -1) {
            tasksModel.requestToggleMinimized(tasksModel.makeModelIndex(index,availableWindow));
        }
    }

    Component.onCompleted: {
        taskItem.checkWindowsStates.connect(initializeStates);
    }

    Component.onDestruction: {
        taskItem.checkWindowsStates.disconnect(initializeStates);
    }
}
