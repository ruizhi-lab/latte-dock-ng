/*
    SPDX-FileCopyrightText: 2020 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import org.kde.plasma.core as PlasmaCore

Item{
    id: totalsItem
    property int visualThickness: 0
    property int visualLength: 0
    property int visualMaxThickness: 0

    readonly property bool edgeIsVertical: plasmoid.location === PlasmaCore.Types.LeftEdge
                                           || plasmoid.location === PlasmaCore.Types.RightEdge
    readonly property bool edgeIsHorizontal: plasmoid.location === PlasmaCore.Types.TopEdge
                                             || plasmoid.location === PlasmaCore.Types.BottomEdge
    readonly property bool isHorizontal: edgeIsHorizontal ? true
                                      : (edgeIsVertical ? false : (plasmoid.formFactor === PlasmaCore.Types.Horizontal))

    readonly property int shadowsLength: {
        if (isHorizontal) {
            return shadows.left+shadows.right;
        } else {
            return shadows.top+shadows.bottom;
        }
    }

    readonly property int shadowsThickness: {
        if (isHorizontal) {
            return shadows.top+shadows.bottom;
        } else {
            return shadows.left+shadows.right;
        }
    }

    readonly property int paddingsLength: {
        if (isHorizontal) {
            return paddings.left+paddings.right;
        } else {
            return paddings.top+paddings.bottom;
        }
    }

    /*updated through binding in order to not change its value when hiding screen gaps for maximized windows*/
    property int minThickness: 0

    Binding {
        target: totalsItem
        property: "minThickness"
        when: !(hideThickScreenGap || hideLengthScreenGaps)
        value: (paddings.headThickness + paddings.tailThickness)
    }
}
