/*
    SPDX-FileCopyrightText: 2018 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import org.kde.plasma.core as PlasmaCore
import org.kde.ksvg as KSvg

Item{
    id: main
    clip: !kirigamiRect.active

    property int borderWidth: 0
    property int roundness: 0
    property int shadowSize: 0

    property real backgroundOpacity: 1.0

    property color backgroundColor: "black"
    property color borderColor: "transparent"
    property color shadowColor: "black"

    property bool topBorder: false
    property bool leftBorder: false
    property bool bottomBorder: false
    property bool rightBorder: false

    property bool onlyHorizontalBorders: !leftBorder && !rightBorder
    property bool onlyVerticalBorders: !topBorder && !bottomBorder

    property int noOfBorders: {
        if (allBorders) {
            return 4;
        }

        var i = 0;

        if (topBorder) {
            i = i + 1;
        }
        if (leftBorder) {
            i = i + 1;
        }
        if (rightBorder) {
            i = i + 1;
        }
        if (bottomBorder) {
            i = i + 1;
        }

        return i;
    }

    readonly property bool allBorders: (latteView && latteView.effects && (latteView.effects.enabledBorders === KSvg.FrameSvg.AllBorders))

    readonly property bool bothVerticals: (leftBorder && rightBorder)
    readonly property bool bothHorizontals: (bottomBorder && topBorder)

    readonly property bool drawWithoutRoundness: onlyHorizontalBorders || onlyVerticalBorders
    readonly property bool edgeIsVertical: plasmoid.location === PlasmaCore.Types.LeftEdge
                                           || plasmoid.location === PlasmaCore.Types.RightEdge
    readonly property bool edgeIsHorizontal: plasmoid.location === PlasmaCore.Types.TopEdge
                                             || plasmoid.location === PlasmaCore.Types.BottomEdge
    readonly property bool isHorizontal: edgeIsHorizontal ? true
                                      : (edgeIsVertical ? false : (plasmoid.formFactor === PlasmaCore.Types.Horizontal))

    readonly property Item painterRectangle: painter

    Binding{
        target: main
        property: "topBorder"
        when: latteView
        value: {
            return (latteView && latteView.effects && ((latteView.effects.enabledBorders & KSvg.FrameSvg.TopBorder)) > 0) || allBorders;
        }
    }

    Binding{
        target: main
        property: "leftBorder"
        when: latteView
        value: {
            return (latteView && latteView.effects && ((latteView.effects.enabledBorders & KSvg.FrameSvg.LeftBorder)) > 0) || allBorders;
        }
    }

    Binding{
        target: main
        property: "bottomBorder"
        when: latteView
        value: {
            return (latteView && latteView.effects && ((latteView.effects.enabledBorders & KSvg.FrameSvg.BottomBorder)) > 0) || allBorders;
        }
    }

    Binding{
        target: main
        property: "rightBorder"
        when: latteView
        value: {
            return (latteView && latteView.effects && ((latteView.effects.enabledBorders & KSvg.FrameSvg.RightBorder)) > 0) || allBorders;
        }
    }

    Loader {
        id: kirigamiRect
        anchors.fill: painter
        active: root.kirigamiLibraryIsFound && main.shadowSize>0
        //! The loader stays inactive when Kirigami is unavailable or no shadow
        //! is requested; selecting NormalRectangle does not activate it.
        source: root.kirigamiLibraryIsFound ? "KirigamiShadowedRectangle.qml" : "NormalRectangle.qml"
    }

    Rectangle{
        id: painter
        anchors.verticalCenter: parent.verticalCenter
        anchors.horizontalCenter: parent.horizontalCenter
        opacity: backgroundOpacity

        width: {
            if (main.isHorizontal) {
                if (drawWithoutRoundness) {
                    return parent.width + 2*borderWidth;
                } else if (noOfBorders === 2 || (noOfBorders === 3 && bothHorizontals)) {
                    return parent.width + Math.max(roundness, 2*borderWidth);
                } else if (noOfBorders === 3 && bothVerticals) {
                    return parent.width;
                }
            } else {
                if (drawWithoutRoundness) {
                    return parent.width + 2 * borderWidth;
                } else if ((noOfBorders === 2 && !bothVerticals) || (noOfBorders === 3 && bothHorizontals)) {
                    return parent.width + Math.max(roundness, 2 * borderWidth);
                }
            }

            return parent.width;
        }


        height: {
            if (main.isHorizontal) {
                if (drawWithoutRoundness) {
                    return parent.height + 2 * borderWidth;
                } else if ((noOfBorders === 2 && !bothHorizontals) || (noOfBorders === 3 && bothVerticals)) {
                    return parent.height + Math.max(roundness,2 * borderWidth);
                }
            } else {
                if (drawWithoutRoundness) {
                    return parent.height + 2*borderWidth;
                } else if (noOfBorders === 2 || (noOfBorders === 3 && bothVerticals)) {
                    return parent.height + Math.max(roundness, 2*borderWidth);
                } else if (noOfBorders === 3 && bothHorizontals) {
                    return parent.height;
                }
            }

            return parent.height;
        }

        radius: drawWithoutRoundness ? 0 : roundness
        color: main.backgroundColor
        border.width: main.borderWidth
        border.color: main.borderColor

        readonly property int centerStep: {
            if (allBorders) {
                return 0;
            }

            return Math.max(Math.ceil((drawWithoutRoundness ? 0 : roundness) / 2) , borderWidth)
        }

        states: [
            State {
                name: "horizontal"
                when: main.isHorizontal

                PropertyChanges{
                    target: painter
                    anchors.horizontalCenterOffset: {
                        if (drawWithoutRoundness || (noOfBorders === 3 && bothVerticals)) {
                            return 0;
                        } else if (noOfBorders === 2 || (noOfBorders === 3 && bothHorizontals)) {
                            if (leftBorder) {
                                return painter.centerStep;
                            } else if (rightBorder) {
                                return -painter.centerStep;
                            }
                        }

                        return 0;
                    }
                    anchors.verticalCenterOffset: {
                        if (allBorders || (noOfBorders>=2 && bothHorizontals)) {
                            return 0;
                        }

                        //bottom edge and top edge
                        return plasmoid.location === PlasmaCore.Types.TopEdge ? -painter.centerStep : painter.centerStep;
                    }
                }
            },
            State {
                name: "vertical"
                when: !main.isHorizontal

                PropertyChanges{
                    target: painter
                    anchors.verticalCenterOffset: {
                        if (drawWithoutRoundness || (noOfBorders === 3 && bothHorizontals)) {
                            return 0;
                        } else if (noOfBorders === 2 || (noOfBorders === 3 && bothVerticals)) {
                            if (bottomBorder) {
                                return -painter.centerStep;
                            } else if (topBorder) {
                                return painter.centerStep;
                            }
                        }

                        return 0;
                    }
                    anchors.horizontalCenterOffset: {
                        if (allBorders || (noOfBorders>=2 && bothVerticals)) {
                            return 0;
                        }

                        //left edge and right edge
                        return plasmoid.location === PlasmaCore.Types.LeftEdge ? -painter.centerStep : painter.centerStep;
                    }
                }
            }
        ]
    }

}
