pragma ComponentBehavior: Bound
/*
    SPDX-FileCopyrightText: 2018 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import QtQuick.Layouts
import QtQuick.Dialogs as QtDialogs
import QtQuick.Controls as QtQuickControls212

import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents

import org.kde.latte.components as LatteComponents
import org.kde.latte.private.containment as LatteContainment

import "../../controls" as LatteExtraControls

PlasmaComponents.Page {
    id: page
    required property var dialog
    required property var latteView
    required property var viewConfig
    readonly property var units: page.dialog.units
    width: content.width + content.Layout.leftMargin * 2
    height: content.height + units.smallSpacing

    ColumnLayout {
        id: content
        anchors.horizontalCenter: parent.horizontalCenter
        Layout.leftMargin: units.smallSpacing * 2
        width: (page.dialog.appliedWidth - units.smallSpacing * 2) - Layout.leftMargin * 2
        spacing: page.dialog.subGroupSpacing

        //! BEGIN: Shadows
        ColumnLayout {
            Layout.fillWidth: true
            Layout.topMargin: units.smallSpacing

            spacing: units.smallSpacing

            LatteComponents.HeaderSwitch {
                id: showAppletShadow
                Layout.fillWidth: true
                Layout.minimumHeight: implicitHeight
                Layout.topMargin: units.smallSpacing

                checked: plasmoid.configuration.appletShadowsEnabled
                text: i18n("Shadows")
                tooltip: i18n("Enable/disable applet shadows")

                onPressed: plasmoid.configuration.appletShadowsEnabled = !plasmoid.configuration.appletShadowsEnabled;
            }

            ColumnLayout {
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2
                spacing: 0

                RowLayout{
                    enabled: showAppletShadow.checked

                    PlasmaComponents.Label {
                        enabled: showAppletShadow.checked
                        text: i18n("Size")
                        horizontalAlignment: Text.AlignLeft
                    }

                    LatteComponents.Slider {
                        id: shadowSizeSlider
                        Layout.fillWidth: true
                        enabled: showAppletShadow.checked

                        value: plasmoid.configuration.shadowSize
                        from: 0
                        to: 100
                        stepSize: 5
                        wheelEnabled: false

                        function updateShadowSize() {
                            if (!pressed)
                                plasmoid.configuration.shadowSize = value;
                        }

                        onPressedChanged: {
                            updateShadowSize();
                        }

                        Component.onCompleted: {
                            valueChanged.connect(updateShadowSize);
                        }

                        Component.onDestruction: {
                            valueChanged.disconnect(updateShadowSize);
                        }
                    }

                    PlasmaComponents.Label {
                        enabled: showAppletShadow.checked
                        text: i18nc("number in percentage, e.g. 85 %","%1 %", shadowSizeSlider.value)
                        horizontalAlignment: Text.AlignRight
                        Layout.minimumWidth: Kirigami.Units.gridUnit * 4
                        Layout.maximumWidth: Kirigami.Units.gridUnit * 4
                    }
                }


                RowLayout{
                    enabled: showAppletShadow.checked

                    PlasmaComponents.Label {
                        enabled: showAppletShadow.checked
                        text: i18n("Opacity")
                        horizontalAlignment: Text.AlignLeft
                    }

                    LatteComponents.Slider {
                        id: shadowOpacitySlider
                        Layout.fillWidth: true

                        value: plasmoid.configuration.shadowOpacity
                        from: 0
                        to: 100
                        stepSize: 5
                        wheelEnabled: false

                        function updateShadowOpacity() {
                            if (!pressed)
                                plasmoid.configuration.shadowOpacity = value;
                        }

                        onPressedChanged: {
                            updateShadowOpacity();
                        }

                        Component.onCompleted: {
                            valueChanged.connect(updateShadowOpacity);
                        }

                        Component.onDestruction: {
                            valueChanged.disconnect(updateShadowOpacity);
                        }
                    }

                    PlasmaComponents.Label {
                        id: shadowOpacityLbl
                        enabled: showAppletShadow.checked
                        text: i18nc("number in percentage, e.g. 85 %","%1 %", shadowOpacitySlider.value)
                        horizontalAlignment: Text.AlignRight
                        Layout.minimumWidth: Kirigami.Units.gridUnit * 4
                        Layout.maximumWidth: Kirigami.Units.gridUnit * 4
                    }
                }

                RowLayout {
                    id: shadowColorRow
                    Layout.fillWidth: true
                    Layout.topMargin: units.smallSpacing
                    spacing: 2
                    enabled: showAppletShadow.checked

                    readonly property string defaultShadow: "080808"
                    readonly property string themeShadow: {
                        var strC = String(theme.textColor);

                        return strC.indexOf("#") === 0 ? strC.substr(1) : strC;
                    }

                    LatteComponents.Button {
                        id: defaultShadowBtn
                        Layout.fillWidth: true

                        text: i18nc("default shadow", "Default Color")
                        tooltip: i18n("Default shadow for applets")
                        checked: plasmoid.configuration.shadowColorType === type
                        checkable: true

                        readonly property int type: LatteContainment.types.DefaultColorShadow

                        onClicked: {
                            plasmoid.configuration.shadowColorType = type
                            checked = Qt.binding(function() { return plasmoid.configuration.shadowColorType === type })
                        }
                    }

                    LatteComponents.Button {
                        id: themeShadowBtn
                        Layout.fillWidth: true

                        text: i18nc("theme shadow", "Theme Color")
                        tooltip: i18n("Shadow from theme color palette")
                        checked: plasmoid.configuration.shadowColorType === type
                        checkable: true

                        readonly property int type: LatteContainment.types.ThemeColorShadow

                        onClicked: {
                            plasmoid.configuration.shadowColorType = type
                            checked = Qt.binding(function() { return plasmoid.configuration.shadowColorType === type })
                        }
                    }

                    //overlayed button
                    LatteComponents.Button {
                        id: userShadowBtn
                        Layout.fillWidth: true
                        Layout.minimumWidth: shadowOpacityLbl.width
                        Layout.fillHeight: true
                        text: " "
                        tooltip: i18n("Use set shadow color")

                        checkable: true
                        checked: plasmoid.configuration.shadowColorType === type

                        readonly property int type: LatteContainment.types.UserColorShadow

                        onClicked: {
                            plasmoid.configuration.shadowColorType = type
                            checked = Qt.binding(function() { return plasmoid.configuration.shadowColorType === type })
                        }

                        Rectangle{
                            anchors.fill: parent
                            anchors.margins: 1.5*units.smallSpacing

                            color: "#" + plasmoid.configuration.shadowColor;

                            opacity: shadowColorRow.enabled ? 1 : 0.6

                            Rectangle{
                                anchors.fill: parent
                                color: "transparent"
                                border.width: 1
                                border.color: theme.textColor
                                opacity: parent.opacity - 0.4
                            }

                            MouseArea{
                                anchors.fill: parent
                                onClicked: {
                                    plasmoid.configuration.shadowColorType = userShadowBtn.type;
                                    page.viewConfig.setSticker(true);
                                    colorDialogLoader.showDialog = true;
                                }
                            }
                        }

                        Loader{
                            id:colorDialogLoader
                            property bool showDialog: false
                            active: showDialog

                            sourceComponent: QtDialogs.ColorDialog {
                                title: i18n("Please choose shadow color")

                                onAccepted: {
                                    var strC = String(selectedColor);
                                    if (strC.indexOf("#") === 0) {
                                        plasmoid.configuration.shadowColor = strC.substr(1);
                                    }

                                    colorDialogLoader.showDialog = false;
                                    viewConfig.setSticker(false);
                                }
                                onRejected: {
                                    colorDialogLoader.showDialog = false;
                                    viewConfig.setSticker(false);
                                }
                                Component.onCompleted: {
                                    selectedColor = String("#" + plasmoid.configuration.shadowColor);
                                    open();
                                }
                            }
                        }
                    }
                }
            }
        }
        //! END: Shadows

        //! BEGIN: Animations
        ColumnLayout {
            Layout.fillWidth: true
            Layout.topMargin: units.smallSpacing
            spacing: units.smallSpacing

            LatteComponents.HeaderSwitch {
                id: animationsHeader
                Layout.fillWidth: true
                Layout.minimumHeight: implicitHeight
                Layout.topMargin: units.smallSpacing

                checked: plasmoid.configuration.animationsEnabled
                text: i18n("Animations")
                tooltip: i18n("Enable/disable all animations")

                onPressed: {
                    plasmoid.configuration.animationsEnabled = !plasmoid.configuration.animationsEnabled;
                }
            }

            ColumnLayout {
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2
                spacing: 0
                enabled: plasmoid.configuration.animationsEnabled

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 0

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 2

                        property int duration: plasmoid.configuration.durationTime

                        //! The x1/x2/x3 labels match the containment durationTime
                        //! enum values (1/2/3). The containment maps them to 1x/2x/3x
                        //! animation durations, so x1 = normal, x2 = slower, x3 = slowest.
                        LatteComponents.Button {
                            Layout.fillWidth: true
                            text: i18n("x1")
                            checked: parent.duration === duration
                            checkable: true

                            readonly property int duration: 1

                            onClicked: {
                                plasmoid.configuration.durationTime = duration
                                checked = Qt.binding(function() { return parent.duration === duration })
                            }
                        }
                        LatteComponents.Button {
                            Layout.fillWidth: true
                            text: i18n("x2")
                            checked: parent.duration === duration
                            checkable: true

                            readonly property int duration: 2

                            onClicked: {
                                plasmoid.configuration.durationTime = duration
                                checked = Qt.binding(function() { return parent.duration === duration })
                            }
                        }
                        LatteComponents.Button {
                            Layout.fillWidth: true
                            text: i18n("x3")
                            checked: parent.duration === duration
                            checkable: true

                            readonly property int duration: 3

                            onClicked: {
                                plasmoid.configuration.durationTime = duration
                                checked = Qt.binding(function() { return parent.duration === duration })
                            }
                        }
                    }
                }
            }
        }
        //! END: Animations

        //! BEGIN: Active Indicator General Settings
        ColumnLayout{
            spacing: units.smallSpacing

            LatteComponents.HeaderSwitch {
                id: indicatorsSwitch
                Layout.fillWidth: true
                Layout.minimumHeight: implicitHeight

                checked: page.latteView.indicator.enabled
                text: i18n("Indicators")
                tooltip: i18n("Enable/disable indicators")

                onPressed: {
                    page.latteView.indicator.enabled = !page.latteView.indicator.enabled;
                }
            }

            ColumnLayout {
                Layout.leftMargin: units.smallSpacing * 2
                Layout.rightMargin: units.smallSpacing * 2
                spacing: units.smallSpacing
                enabled: indicatorsSwitch.checked

                /*   LatteComponents.SubHeader {
                    text: i18n("Style")
                }*/

                Item {
                    Layout.fillWidth: true
                    Layout.minimumHeight: tabBar.height

                    PlasmaComponents.TabBar {
                        id: tabBar
                        width: parent.width

                        property string type: page.latteView.indicator.type

                        PlasmaComponents.TabButton {
                            id: latteBtn
                            text: i18nc("latte indicator style", "Latte")
                            readonly property string type: "org.kde.latte.default"

                            onClicked: {
                                page.latteView.indicator.type = type;
                            }
                        }
                        PlasmaComponents.TabButton {
                            id: customBtn
                            implicitWidth: customIndicator.implicitWidth
                            implicitHeight: customIndicator.implicitHeight

                            onClicked: {
                                customIndicator.onButtonIsPressed();
                            }

                            LatteExtraControls.CustomIndicatorButton {
                                latteView: page.latteView
                                viewConfig: page.viewConfig
                                id: customIndicator
                                anchors.fill: parent
                                implicitWidth: latteBtn.implicitWidth
                                implicitHeight: latteBtn.implicitHeight

                                checked: parent.checked
                                comboBoxMinimumPopUpWidth: 1.5 * customIndicator.width

                                onTypeChanged: {
                                    if (tabBar.type === type) {
                                        tabBar.selectTab(type);
                                    }
                                }
                            }
                        }

                        function selectTab(type) {
                            if (type === latteBtn.type) {
                                tabBar.currentIndex = 0;
                            } else if (type === customIndicator.type) {
                                tabBar.currentIndex = 1;
                            }
                        }

                        Connections {
                            target: indicatorsStackView
                            function onCurrentItemChanged() {
                                if (!indicatorsStackView.currentItem || !page.viewConfig.isReady) {
                                    return;
                                }

                                tabBar.selectTab(indicatorsStackView.currentItem.type);
                            }
                        }
                    }

                    Rectangle {
                        anchors.bottom: tabBar.bottom
                        anchors.left: tabBar.left
                        anchors.leftMargin: 2
                        width: tabBar.width - 2*2
                        height: 2
                        color: theme.textColor
                        opacity: 0.25
                    }
                }

                //! BEGIN: Indicator specific sub-options
                QtQuickControls212.StackView {
                    id: indicatorsStackView
                    Layout.fillWidth: true
                    Layout.maximumHeight: Layout.minimumHeight
                    enabled: page.latteView.indicator.enabled

                    property bool forwardSliding: true

                    readonly property int optionsWidth: page.dialog.optionsWidth
                    readonly property bool deprecatedOptionsAreHidden: true // @since 0.10.0

                    replaceEnter: Transition {
                        ParallelAnimation {
                            PropertyAnimation {
                                property: "x"
                                from: indicatorsStackView.forwardSliding ? -indicatorsStackView.width : indicatorsStackView.width
                                to: 0
                                duration: 350
                            }

                            PropertyAnimation {
                                property: "opacity"
                                from: 0
                                to: 1
                                duration: 350
                            }
                        }
                    }

                    replaceExit: Transition {
                        ParallelAnimation {
                            PropertyAnimation {
                                property: "x"
                                from: 0
                                to: indicatorsStackView.forwardSliding ? indicatorsStackView.width : -indicatorsStackView.width
                                duration: 350
                            }

                            PropertyAnimation {
                                property: "opacity"
                                from: 1
                                to: 0
                                duration: 350
                            }
                        }
                    }
                } //! END: Indicator specific sub-options
            } //! END: Active Indicator General Settings
        }
    } //! END of Dynamic content


    //! Manager / Handler of loading/showing/hiding indicator config uis
    LatteExtraControls.IndicatorConfigUiManager {
        id: indicatorUiManager
        visible: false
        dialog: page.dialog
        latteView: page.latteView
        viewConfig: page.viewConfig
        stackView: indicatorsStackView
    }

}
