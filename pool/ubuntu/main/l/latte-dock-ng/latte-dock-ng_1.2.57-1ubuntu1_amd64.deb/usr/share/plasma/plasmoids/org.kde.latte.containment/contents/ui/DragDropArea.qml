/*
    SPDX-FileCopyrightText: 2019 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import org.kde.draganddrop as DragDrop

DragDrop.DropArea {
    id: dragArea

    // Keep the public drag state name used by Latte's containment API.
    // qmllint disable property-override
    property bool containsDrag: false
    // qmllint enable property-override

    readonly property Item dragInfo: Item {
        readonly property bool entered: latteView && latteView.containsDrag
        property bool isTask: false
        property bool isPlasmoid: false
        property bool isSeparator: false
        property bool isLatteTasks: false
        property bool onlyLaunchers: false

        property bool computationsAreValid: false
    }

    Connections{
        target: root.dragInfo

        function onEnteredChanged() {
            if(!root.dragInfo.entered) {
                dragArea.clearInfo();
            }
        }
    }

    Connections{
        target: latteView

        function onContainsDragChanged() {
            if(!latteView.containsDrag) {
                dragArea.clearInfo();
            }
        }
    }

    function clearInfo() {
        clearInfoTimer.restart();
    }

    function isDroppingOnlyLaunchers(event) {
        if (!latteView) {
            return
        }

        if (event.mimeData.hasUrls || (event.mimeData.formats.indexOf("text/x-plasmoidservicename") !== 0)) {
            var onlyLaunchers = event.mimeData.urls.every(function (item) {
                return latteView.extendedInterface.isApplication(item);
            });

            return onlyLaunchers;
        }

        return false;
    }

    function isInternalTaskSource(event) {
        if (!event || !event.mimeData) {
            return false;
        }

        var source = event.mimeData.source;

        while (source) {
            if (source.objectName === "TaskItem") {
                return true;
            }

            source = source.parent;
        }

        return false;
    }

    function hasTaskMime(event) {
        if (!event || !event.mimeData || event.mimeData.formats === undefined) {
            return false;
        }

        var formats = event.mimeData.formats;

        for (var i = 0; i < formats.length; ++i) {
            var format = String(formats[i]);

            if (format === "application/x-orgkdeplasmataskmanager_taskbuttonitem"
                    || format.indexOf("plasmataskmanager") >= 0) {
                return true;
            }
        }

        return false;
    }

    //! Give the time when an applet is dropped to be positioned properly
    Timer {
        id: clearInfoTimer
        interval: 100

        onTriggered: {
            dragArea.dragInfo.computationsAreValid = false;

            dragArea.dragInfo.isTask = false;
            dragArea.dragInfo.isPlasmoid = false;
            dragArea.dragInfo.isSeparator = false;
            dragArea.dragInfo.isLatteTasks = false;
            dragArea.dragInfo.onlyLaunchers = false;

            dndSpacer.parent = root;
            dndSpacer.opacity = 0;
        }
    }

    // Qt6 handler-binding syntax — function form does not connect to
    // DragDrop.DropArea signals in Qt 6.
    onDragEnter: (event) => {
        containsDrag = true;
        clearInfoTimer.stop();
        var isTask = isInternalTaskSource(event) || hasTaskMime(event);

        var isSeparator = event !== undefined
                && event.mimeData !== undefined
                && ( latteView.mimeContainsPlasmoid(event.mimeData, "audoban.applet.separator")
                    || latteView.mimeContainsPlasmoid(event.mimeData, "org.kde.latte.separator") );

        var isLatteTasks = event !== undefined
                && event.mimeData !== undefined
                && latteView.mimeContainsPlasmoid(event.mimeData, "org.kde.latte.plasmoid");

        var isPlasmoid = event !== undefined
                && event.mimeData !== undefined
                && event.mimeData.formats !== undefined
                && !event.mimeData.hasUrls
                && event.mimeData.formats.indexOf("text/x-plasmoidservicename") === 0;

        dragInfo.isTask = isTask;
        dragInfo.isPlasmoid = isPlasmoid;
        dragInfo.isSeparator = isSeparator;
        dragInfo.isLatteTasks = isLatteTasks;
        dragInfo.onlyLaunchers = isDroppingOnlyLaunchers(event);
        dragInfo.computationsAreValid = true;

        if (dragInfo.isTask || plasmoid.immutable || !root.myView.isShownFully) {
            event.ignore();
            clearInfo();
            return;
        }

        //! Send signal AFTER the dragging is confirmed otherwise the restore mask signal from animations
        //! may not be triggered #408926
        animations.needLength.addEvent(dragArea);

        if (root.launchers.hasStealingApplet && dragInfo.onlyLaunchers) {
            root.launchers.showAddLaunchersMessageInStealingApplet();
            dndSpacer.opacity = 0;
            dndSpacer.parent = root;
            return;
        }

        fastLayoutManager.insertAtCoordinates(dndSpacer, event.x, event.y);
        dndSpacer.opacity = 1;
    }

    onDragMove: (event) => {
        containsDrag = true;
        clearInfoTimer.stop();
        if (dragInfo.isTask) {
            event.ignore();
            return;
        }

        if (root.launchers.hasStealingApplet && dragInfo.onlyLaunchers) {
            root.launchers.showAddLaunchersMessageInStealingApplet();
            dndSpacer.opacity = 0;
            dndSpacer.parent = root;
            return;
        }

        fastLayoutManager.insertAtCoordinates(dndSpacer, event.x, event.y);
        dndSpacer.opacity = 1;
    }

    onDragLeave: {
        containsDrag = false;
        animations.needLength.removeEvent(dragArea);

        if (root.launchers.hasStealingApplet) {
            root.launchers.hideAddLaunchersMessageInStealingApplet();
        }

        dndSpacer.opacity = 0;
        dndSpacer.parent = root;
    }

    onDrop: (event) => {
        containsDrag = false;
        animations.needLength.removeEvent(dragArea);

        if (root.launchers.hasStealingApplet) {
            root.launchers.hideAddLaunchersMessageInStealingApplet();
        }

        if (dragInfo.isTask || !root.myView.isShownFully) {
            return;
        }

        // Widget Explorer drops (text/x-plasmoidservicename) are handled
        // by the native C++ path (View::event() → handlePlasmoidDrop()).
        // Letting both C++ and QML paths process this mime creates two
        // applets per drop.  File/URL drops (text/uri-list) continue
        // through this QML path as before.
        if (event.mimeData.formats.indexOf("text/x-plasmoidservicename") >= 0) {
            return;
        }

        if (root.launchers.hasStealingApplet && dragInfo.onlyLaunchers) {
            root.launchers.addDroppedLaunchersInStealingApplet(event.mimeData.urls);
        } else {
            var dndindex = fastLayoutManager.dndSpacerIndex();
            var eventx = event.x;
            var eventy = event.y;

            if (dndindex >= 0) {
                var masquearadedIndexFromPoint = fastLayoutManager.indexToMasquearadedPoint(fastLayoutManager.dndSpacerIndex());
                eventx = masquearadedIndexFromPoint.x;
                eventy = masquearadedIndexFromPoint.y;
            }

            if (typeof root.processMimeData === "function") {
                latteView.extendedInterface.suppressNextAppletCreatedSignal();
                root.processMimeData(event.mimeData, eventx, eventy);
            }
            //! inform others what plasmoid was drag n' dropped to be added
            latteView.extendedInterface.appletDropped(event.mimeData, eventx, eventy);
            event.accept(event.proposedAction);
        }

        dndSpacer.opacity = 0;
    }
}
