/*
    SPDX-FileCopyrightText: 2019 Michail Vourlakos <mvourlakos@gmail.com>

    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import org.kde.latte.core as LatteCore

Rectangle {
    id: listViewBase
    x: {
        if (!root.vertical) {
            if (root.alignment === LatteCore.types.Center) {
                //! this way we get a perfectly centered offset value
                return (icList.width-1) / 2;
            } else if (root.alignment === LatteCore.types.Left){
                return 0;
            } else if (root.alignment === LatteCore.types.Right){
                //! this way we get a perfectly right aligned offset value
                return (icList.width-1);
            }
        }

        return 0;
    }

    y: {
        if (root.vertical) {
            if (root.alignment === LatteCore.types.Center) {
                //! this way we get a perfectly centered offset value
                return (icList.height-1) / 2;
            } else if (root.alignment === LatteCore.types.Top){
                return 0;
            } else if (root.alignment === LatteCore.types.Bottom){
                //! this way we get a perfectly bottom aligned offset value
                return (icList.height-1);
            }
        }

        return 0;
    }

    width: !root.vertical ? 1 : scrollableList.width
    height: !root.vertical ? scrollableList.height : 1

    color: "transparent"
    border.width: 1
    border.color: "transparent" //"purple"
}
