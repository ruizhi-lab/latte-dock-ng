/*
    SPDX-FileCopyrightText: 2020 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import "./privates" as Ability

Ability.LayouterPrivate {
    id: _layouter

    property bool appletsInParentChange: false

    readonly property bool inNormalFillCalculationsState: animations.needBothAxis.count === 0
                                                          && animations.needThickness.count === 0
                                                          && (animations.needLength.count === 0 || root.dragInfo.entered) /*update when the user drags a plasmoid on the view*/
                                                          && !appletsInParentChange
                                                        //  && (!dragOverlay || (dragOverlay && !dragOverlay.pressed)) /*do not update during moving/dragging applets*/

    readonly property bool maxMetricsInHigherPriority: root.minLength === root.maxLength

    function updateSizeForAppletsInFill() {
        if (!updateSizeForAppletsInFillTimer.running) {
            _layouter._updateSizeForAppletsInFill();
            updateSizeForAppletsInFillTimer.start();
        }
    }

    // Do NOT trigger fill recalculation on inNormalFillCalculationsState
    // transitions.  needLength is added on every contentsWidth change and
    // removed 300 ms later by delayUpdateMaskArea.  Calling
    // updateSizeForAppletsInFill on the removal changes fill sizes, which
    // changes contentsWidth, which adds needLength again — a permanent
    // oscillation feedback loop that manifests as visible icon jitter.
    //
    // Fill recalculation is already triggered by: onContentsLengthChanged,
    // onIconSizeChanged, onMaxLengthChanged, onFormFactorChanged,
    // visibilityManager.onInNormalStateChanged, and the 75 ms debounce timer.

    onMaxLengthChanged: {
        _layouter.updateSizeForAppletsInFill();
    }

    Connections {
        target: layouts
        function onContentsLengthChanged() { _layouter.updateSizeForAppletsInFill(); }
    }

    Connections {
        target: metrics
        function onIconSizeChanged() { _layouter.updateSizeForAppletsInFill(); }
    }

    Connections {
        target: plasmoid
        function onFormFactorChanged() { _layouter.updateSizeForAppletsInFill(); }
    }

    Connections {
        target: visibilityManager
        function onInNormalStateChanged() {
            if (visibilityManager.inNormalState) {
                _layouter.updateSizeForAppletsInFill();
            }
        }
    }

    //! This timer is needed in order to reduce the calls to heavy cpu function
    //! updateSizeForAppletsInFill()
    Timer{
        id: updateSizeForAppletsInFillTimer
        interval: 75
        onTriggered: _layouter._updateSizeForAppletsInFill();
    }
}
