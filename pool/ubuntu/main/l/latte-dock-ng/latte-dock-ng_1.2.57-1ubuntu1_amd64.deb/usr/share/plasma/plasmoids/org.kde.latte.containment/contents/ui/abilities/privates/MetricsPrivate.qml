/*
    SPDX-FileCopyrightText: 2020 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import org.kde.latte.abilities.host as AbilityHost

import "./metrics" as MetricsPrivateTypes

AbilityHost.Metrics {
    id: mets
    property Item animations: null
    required property Item autosize
    required property Item background
    required property Item indicators
    required property Item parabolic

    //! private properties to avoid too many not needed animation calculations
    readonly property int _iconSize: autosizeEnabled && autosize.iconSize > 0 ? Math.min(autosize.iconSize, maxIconSize) : maxIconSize
    readonly property int _maxIconSize: {
        //! round to nearest odd number
        var storedIconSize = 2 * Math.round(plasmoid.configuration.iconSize / 2)

        return portionIconSize!==-1 ? portionIconSize : storedIconSize;
    }

    //! Private Properties
    readonly property int portionIconSize: { //icon size based on screen height
        if ((plasmoid.configuration.proportionIconSize===-1) || !latteView)
            return -1;

        var basedOnScreenHeight = Math.max(16,Math.round(latteView.screenGeometry.height * plasmoid.configuration.proportionIconSize/100))

        //! round to nearest odd number
        return 2 * Math.round(basedOnScreenHeight/2);
    }

    readonly property bool autosizeEnabled: autosize !== undefined && autosize.isActive
    readonly property bool modernDockStyle: (typeof root !== "undefined") && root.isModernDockStyle

    readonly property MetricsPrivateTypes.Fraction fraction: MetricsPrivateTypes.Fraction{
        thicknessMargin: {
            var configured = Math.max(indicators.info.minThicknessPadding, plasmoid.configuration.thickMargin / 100);
            // kThicknessMarginModernFloor=0.19, kThicknessMarginTraditionalFloor=0.14
            // See declarativeimports/abilities/definition/metrics/Constants.qml
            return modernDockStyle ? Math.max(0.19, configured) : Math.max(0.14, configured);
        }
        lengthMargin: {
            var configured = plasmoid.configuration.lengthExtMargin / 100;
            // kLengthMarginModernFloor=0.04
            return modernDockStyle ? Math.max(0.04, configured) : configured;
        }
        lengthPadding: indicators.isEnabled ? indicators.padding : 0
        lengthAppletPadding: indicators.isEnabled ? indicators.info.appletLengthPadding : -1
    }

    //! based on background / plasma theme minimum thickness requirements; floating is a good scenario for this
    readonly property int marginMinThickness: Math.max(0, (background.totals.minThickness - _maxIconSize) / 2)

    readonly property int maxThicknessForView: Math.max(mask.maxScreenEdge + ((maxIconSize+2*margin.maxTailThickness)*2) + extraThicknessForZoomed,
                                                        384)

    //! Thickness Private Calculations

    readonly property int marginBetweenContentsAndEditRuler: 10
    readonly property int extraThicknessForNormal: Math.max(extraThicknessFromIndicators, extraThicknessFromShadows)
    readonly property int extraThicknessForZoomed: marginBetweenContentsAndEditRuler + extraThicknessForNormal

    readonly property int extraThicknessFromShadows: 0

    readonly property int extraThicknessFromIndicators: indicators.info.extraMaskThickness

    readonly property real mediumFactor: (1 + (0.65 * (parabolic.factor.maxZoom-1)))
    readonly property real mediumMarginsFactor: 1 + ((mediumFactor-1) * parabolic.factor.marginThicknessZoomInPercentage)
    readonly property real maxMarginsFactor: 1 + ((parabolic.factor.maxZoom-1) * parabolic.factor.marginThicknessZoomInPercentage)

    //! BEHAVIORS
    Behavior on iconSize {
        NumberAnimation {
            duration: 0.8 * animations.duration.proposed

            onRunningChanged: {
                if (!running) {
                    mets.iconSizeAnimationEnded();
                }
            }
        }
    }

    margin {
        Behavior on length {
            NumberAnimation {
                duration: 0.8 * animations.duration.proposed
                easing.type: Easing.OutCubic
            }
        }

        Behavior on screenEdge {
            NumberAnimation {
                duration: 0.8 * animations.duration.proposed
                easing.type: Easing.OutCubic
            }
        }

        Behavior on tailThickness {
            NumberAnimation {
                duration: 0.8 * animations.duration.proposed
                easing.type: Easing.OutCubic
            }
        }

        Behavior on headThickness {
            NumberAnimation {
                duration: 0.8 * animations.duration.proposed
                easing.type: Easing.OutCubic
            }
        }
    }

    padding {
        Behavior on length {
            NumberAnimation {
                duration: 0.8 * animations.duration.proposed
                easing.type: Easing.OutCubic
            }
        }
    }
}
