/*
    SPDX-FileCopyrightText: 2018 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick

import org.kde.kirigami as Kirigami
import org.kde.latte.private.app as LatteApp
import org.kde.latte.private.containment as LatteContainment

import "../../code/ColorizerTools.js" as ColorizerTools

Loader{
    id: manager
    readonly property var theme: Kirigami.Theme

    //! the loader loads the backgroundTracker component
    active: root.themeColors === LatteContainment.types.SmartThemeColors

    readonly property bool backgroundIsBusy: item ? item.isBusy : false

    readonly property real originalThemeTextColorBrightness: ColorizerTools.colorBrightness(theme.textColor)
    readonly property color originalLightTextColor: originalThemeTextColorBrightness > 127.5 ? theme.textColor : theme.backgroundColor

    readonly property real themeTextColorBrightness: ColorizerTools.colorBrightness(textColor)
    readonly property real backgroundColorBrightness: ColorizerTools.colorBrightness(backgroundColor)

    readonly property color focusGlowColor: Qt.hsva(buttonFocusColor.h, buttonFocusColor.s, 1.0, 1.0)

    readonly property color outlineColorBase: backgroundColor
    readonly property real outlineColorBaseBrightness: ColorizerTools.colorBrightness(outlineColorBase)
    readonly property color outlineColor: {
        if (!root.panelOutline) {
            return backgroundColor;
        }

        if (outlineColorBaseBrightness > 127.5) {
            return Qt.darker(outlineColorBase, 1.5);
        } else {
            return Qt.lighter(outlineColorBase, 2.2);
        }
    }

    readonly property bool mustBeShown: (applyTheme && applyTheme !== theme)

    readonly property real currentBackgroundBrightness: item ? item.currentBrightness : -1000

    readonly property bool applyingWindowColors: (root.windowColors === LatteContainment.types.ActiveWindowColors && latteView && latteView.windowsTracker
                                                  && selectedWindowsTracker.activeWindowScheme)
                                                 || (root.windowColors === LatteContainment.types.TouchingWindowColors && latteView && latteView.windowsTracker
                                                     && latteView.windowsTracker.currentScreen.touchingWindowScheme)

    property QtObject applyTheme: {
        if (!root.environment.isGraphicsSystemAccelerated) {
            return theme;
        }

        if (latteView && latteView.windowsTracker && !(root.plasmaBackgroundForPopups && root.hasExpandedApplet)) {
            if (root.windowColors === LatteContainment.types.ActiveWindowColors && selectedWindowsTracker.activeWindowScheme) {
                return selectedWindowsTracker.activeWindowScheme;
            }

            if (root.windowColors === LatteContainment.types.TouchingWindowColors && latteView.windowsTracker.currentScreen.touchingWindowScheme) {
                //! we must track touching windows and when they are not active
                //! the active window scheme is used for convenience
                if (latteView.windowsTracker.currentScreen.existsWindowTouching || latteView.windowsTracker.currentScreen.existsWindowTouchingEdge
                        && !(latteView.windowsTracker.currentScreen.activeWindowTouching || latteView.windowsTracker.currentScreen.activeWindowTouchingEdge)
                        && latteView.windowsTracker.currentScreen.activeWindowScheme) {
                    return latteView.windowsTracker.currentScreen.activeWindowScheme;
                }

                return latteView.windowsTracker.currentScreen.touchingWindowScheme;
            }
        }

        if (themeExtended) {
            if (root.userShowPanelBackground && root.plasmaBackgroundForPopups && root.hasExpandedApplet /*for expanded popups when it is enabled*/
                    || root.plasmaStyleBusyForTouchingBusyVerticalView
                    || (root.themeColors === LatteContainment.types.SmartThemeColors /*for Smart theming that Windows colors are not used and the user wants solidness at some cases*/
                        && root.windowColors === LatteContainment.types.NoneWindowColors
                        && root.forceSolidPanel) ) {
                /* plasma style*/
                return theme;
            }

            if (root.themeColors === LatteContainment.types.DarkThemeColors) {
                return themeExtended.darkTheme;
            } else if (root.themeColors === LatteContainment.types.LightThemeColors) {
                return themeExtended.lightTheme;
            } else if (root.themeColors === LatteContainment.types.ReverseThemeColors) {
                return themeExtended.isLightTheme ? themeExtended.darkTheme : themeExtended.lightTheme;
            } else if (root.themeColors === LatteContainment.types.LayoutThemeColors && latteView && latteView.layout && latteView.layout.scheme) {
                return latteView.layout.scheme;
            }

            if (root.themeColors === LatteContainment.types.SmartThemeColors) {
                //! Smart Colors Case
                if (!root.forcePanelForBusyBackground) {
                    //! simple case that not a busy background is applied
                    return currentBackgroundBrightness > 127.5 ? themeExtended.lightTheme : themeExtended.darkTheme;
                } else {
                    //! Smart + Busy background case
                    var themeContrastedTextColor = currentBackgroundBrightness > 127.5 ? themeExtended.lightTheme : themeExtended.darkTheme;
                    var themeContrastedBackground = currentBackgroundBrightness > 127.5 ? themeExtended.darkTheme : themeExtended.lightTheme;

                    if (root.myView.backgroundStoredOpacity < 0.35) {
                        //! textColor should be better to provide the needed contrast
                        return themeContrastedTextColor;
                    } else if (root.myView.backgroundStoredOpacity >= 0.35 && root.myView.backgroundStoredOpacity <= 0.70) {
                        //! provide a dark case scenario at all cases
                        return themeExtended.darkTheme;
                    } else {
                        //! default plasma theme should be better for panel transparency > 70
                        return theme;
                    }
                }
            }
        }

        return theme;
    }

    //! Always panel-aware palette: prefers the actual Plasma desktop theme's
    //! colors file (loaded by Latte via themeExtended), falling back to the
    //! global Plasma.Theme. This is independent of `applyTheme` (which is
    //! gated by user-selected coloring modes) and is intended for visual
    //! elements rendered ON the panel (e.g. running-task indicators) so they
    //! always contrast with the panel, not the window color scheme.
    readonly property QtObject panelPalette: themeExtended && themeExtended.defaultTheme ? themeExtended.defaultTheme : theme

    property color applyColor: textColor

    readonly property color backgroundColor:applyTheme.backgroundColor
    readonly property color textColor: applyTheme.textColor

    readonly property color inactiveBackgroundColor: applyTheme === theme ? theme.backgroundColor : applyTheme.inactiveBackgroundColor
    readonly property color inactiveTextColor: applyTheme === theme ? theme.textColor : applyTheme.inactiveTextColor

    readonly property color highlightColor: applyTheme.highlightColor
    readonly property color highlightedTextColor: applyTheme.highlightedTextColor
    readonly property color positiveTextColor: applyTheme.positiveTextColor
    readonly property color neutralTextColor: applyTheme.neutralTextColor
    readonly property color negativeTextColor: applyTheme.negativeTextColor

    readonly property color buttonTextColor: applyTheme && applyTheme.buttonTextColor !== undefined ? applyTheme.buttonTextColor : textColor
    readonly property color buttonBackgroundColor: applyTheme && applyTheme.buttonBackgroundColor !== undefined ? applyTheme.buttonBackgroundColor : backgroundColor
    readonly property color buttonHoverColor: applyTheme && applyTheme.buttonHoverColor !== undefined ? applyTheme.buttonHoverColor : highlightColor
    readonly property color buttonFocusColor: applyTheme && applyTheme.buttonFocusColor !== undefined ? applyTheme.buttonFocusColor : highlightColor

    readonly property string scheme: {
        if (applyTheme===theme || !mustBeShown) {
            if (themeExtended) {
                return themeExtended.defaultTheme.schemeFile;
            } else {
                return "kdeglobals";
            }
        }

        return applyTheme.schemeFile;
    }

    sourceComponent: LatteApp.BackgroundTracker {
        activity: root.myView.isReady ? root.myView.lastUsedActivity : ""
        location: plasmoid.location
        screenName: latteView && latteView.positioner ? latteView.positioner.currentScreenName : ""
    }
}
