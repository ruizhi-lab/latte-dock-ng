/*
    SPDX-FileCopyrightText: 2021 Michail Vourlakos <mvourlakos@gmail.com>
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami

Rectangle {
    id: _corner
    readonly property var theme: Kirigami.Theme
    readonly property color safeTextColor: (theme && theme.textColor !== undefined) ? theme.textColor : "white"
    readonly property color safeFocusColor: (theme && theme.buttonFocusColor !== undefined)
                                              ? theme.buttonFocusColor
                                              : ((theme && theme.focusColor !== undefined)
                                                   ? theme.focusColor
                                                   : ((theme && theme.highlightColor !== undefined) ? theme.highlightColor : safeTextColor))
    width: 22
    height: width
    anchors.horizontalCenter: parent.right
    anchors.verticalCenter: parent.top
    rotation: 45
    color: resizeWindowMouseArea.isActive ? safeFocusColor : safeTextColor
    opacity: resizeWindowMouseArea.isActive ? 1 : 0.2

    readonly property alias isActive: resizeWindowMouseArea.isActive

    MouseArea {
        id: resizeWindowMouseArea
        anchors.fill: parent
        hoverEnabled: true

        cursorShape: plasmoid.location === PlasmaCore.Types.LeftEdge ? Qt.SizeBDiagCursor : Qt.SizeFDiagCursor

        readonly property bool isActive: containsMouse || pressed

        property bool initialized: false
        property int initGlobalX: 0
        property int initGlobalY: 0
        property int initWidth: 100
        property int initHeight: 100
        property real initScaleWidth: 1
        property real initScaleHeight: 1

        property int curGlobalX: 0
        property int curGlobalY: 0

        onPressed: {
            if (pressed) {
                var scenePos = mapToGlobal(mouse.x, mouse.y);

                if (plasmoid.location !== PlasmaCore.Types.LeftEdge) {
                    initGlobalX = viewConfig.x + mouse.x;
                    initGlobalY = viewConfig.y + mouse.y;
                } else {
                    initGlobalX = viewConfig.x + mouse.x;
                    initGlobalY = viewConfig.y + mouse.y;
                }

                initWidth = dialog.width;
                initHeight = dialog.height;
                initScaleWidth = dialog.userScaleWidth;
                initScaleHeight = dialog.userScaleHeight;
                initialized = true;
            }
        }

        onPositionChanged: {
            if (pressed && initialized) {
                var scenePos = mapToGlobal(mouse.x, mouse.y);
                if (plasmoid.location !== PlasmaCore.Types.LeftEdge) {
                    curGlobalX = viewConfig.x + mouse.x;
                    curGlobalY = viewConfig.y + mouse.y;
                } else {
                    curGlobalX = viewConfig.x + mouse.x;
                    curGlobalY = viewConfig.y + mouse.y;
                }

                var differX = 0;

                if (plasmoid.location !== PlasmaCore.Types.LeftEdge) {
                    differX = initGlobalX - curGlobalX;
                } else {
                    differX = curGlobalX - initGlobalX;
                }

                // Horizontal docks center the editor on the screen's horizontal axis.
                var percentXMultiplier = plasmoid.formFactor === PlasmaCore.Types.Horizontal ? 2 : 1;

                var percentX = percentXMultiplier * (differX / initWidth);
                var newScaleWidth = Math.max(0.35, initScaleWidth + (percentX*initScaleWidth)).toFixed(3);

                var differY = plasmoid.location === PlasmaCore.Types.TopEdge
                    ? curGlobalY - initGlobalY : initGlobalY - curGlobalY;

                // Vertical docks center the editor on the screen's vertical axis.
                var percentYMultiplier = plasmoid.formFactor === PlasmaCore.Types.Vertical ? 2 : 1;
                var percentY = percentYMultiplier * (differY / initHeight);
                var newScaleHeight = Math.max(0.5, initScaleHeight + (percentY * initScaleHeight)).toFixed(3);

                universalSettings.setScreenScales(latteView.positioner.currentScreenName, newScaleWidth, newScaleHeight);
                dialog.userScaleWidth = newScaleWidth;
                dialog.userScaleHeight = newScaleHeight;
                viewConfig.syncGeometry();
            } else if (!pressed) {
                initialized = false;
            }
        }

        onReleased: {
            initialized = false;
        }

        onDoubleClicked: {
            dialog.userScaleWidth = 1;
            dialog.userScaleHeight = 1;
            universalSettings.setScreenScales(latteView.positioner.currentScreenName, 1, 1);
            viewConfig.syncGeometry();
        }
    }

    states:[
        State{
            name: "bottom"
            when: plasmoid.location === PlasmaCore.Types.BottomEdge

            AnchorChanges{
                target: _corner;
                anchors.horizontalCenter: parent.left; anchors.verticalCenter: parent.top;
            }
        },
        State{
            name: "top"
            when: plasmoid.location === PlasmaCore.Types.TopEdge

            AnchorChanges{
                target: _corner;
                anchors.horizontalCenter: parent.left; anchors.verticalCenter: parent.top;
            }
        },
        State{
            name: "left"
            when: plasmoid.location === PlasmaCore.Types.LeftEdge

            AnchorChanges{
                target: _corner;
                anchors.horizontalCenter: parent.right; anchors.verticalCenter: parent.top;
            }
        },
        State{
            name: "right"
            when: plasmoid.location === PlasmaCore.Types.RightEdge

            AnchorChanges{
                target: _corner;
                anchors.horizontalCenter: parent.left; anchors.verticalCenter: parent.top;
            }
        }
    ]
}
